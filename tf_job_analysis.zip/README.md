# IICS Grouped Taskflow Analyzer

🚀 **Comprehensive analysis tool for IICS job exports containing multiple taskflows**

## Overview

The IICS Grouped Taskflow Analyzer is a powerful Python-based tool that automatically analyzes **grouped IICS job exports** containing multiple taskflows and generates detailed technical documentation including:

- 📊 **Hierarchical analysis** grouped by taskflow with detailed breakdowns
- 🔗 **Cross-taskflow resource analysis** and dependency mapping  
- 📈 **Executive summaries** with complexity assessments and recommendations
- 🎨 **Visual charts** showing taskflow distribution and statistics

## Quick Start

### 1. Install Dependencies
```bash
pip install pandas networkx matplotlib
```

### 2. Analyze IICS Job Export
```bash
python analyze_grouped_taskflows.py your_job_export.zip [output_directory]
```

### 3. View Results
- **`job_analysis_report.md`** - Hierarchical analysis grouped by taskflow
- **`job_analysis.csv`** - Structured data export with taskflow grouping
- **`*_executive_summary.md`** - High-level business summary with recommendations
- **`job_taskflow_summary.png`** - Visual charts of taskflow distribution

## Key Features

### Grouped Analysis Capabilities
✅ **Multi-Taskflow Detection** - Automatically discovers all taskflows in job export  
✅ **Hierarchical Organization** - Analysis grouped by taskflow with detailed breakdowns  
✅ **Executive Summaries** - High-level insights with complexity assessments  
✅ **Resource Sharing Analysis** - Identify shared connections and dependencies  
✅ **Visual Dashboards** - Charts showing taskflow distribution and statistics  
✅ **Automated Recommendations** - Suggestions for optimization and review  
✅ **Command-Line Interface** - Perfect for automation and CI/CD pipelines  
✅ **Enterprise Ready** - Handles complex exports with 100+ taskflows

## Generated Analysis

### Hierarchical Job Report
- **Job Overview**: High-level statistics and metadata
- **Taskflow Summary**: Quick overview table of all taskflows
- **Detailed Analysis**: For each taskflow:
  - MTT task breakdowns with source/target details
  - Connection and template usage
  - Complexity assessment and recommendations
- **Cross-Taskflow Analysis**: Shared resources and dependencies

### Executive Summary
- **Statistics**: Object counts, taskflow complexity distribution
- **Resource Analysis**: Connection sharing patterns and efficiency
- **Recommendations**: 
  - Large taskflows that might benefit from modularization
  - Empty taskflows that may need review
  - Optimization opportunities

### Visual Reports
- Bar charts showing MTT tasks per taskflow
- Pie charts of taskflow distribution
- Complexity heat maps and trends

## Usage Examples

### Basic Analysis
```bash
# Analyze a grouped job export
python analyze_grouped_taskflows.py job_export.zip
```

### Organized Output
```bash
# Save reports to specific directory
python analyze_grouped_taskflows.py job_export.zip ./analysis_results
```

### Enterprise Workflow
```bash
# Analyze multiple job exports with timestamped output
for job in *.zip; do
    python analyze_grouped_taskflows.py "$job" "./analysis_$(date +%Y%m%d)_$(basename $job .zip)"
done
```

## Complexity Classifications

The analyzer automatically classifies taskflows based on MTT task count:

- **Empty**: 0 MTT tasks - May need review
- **Simple**: 1-5 MTT tasks - Low complexity
- **Moderate**: 6-25 MTT tasks - Standard complexity
- **Complex**: 26-50 MTT tasks - High complexity
- **Very Complex**: 50+ MTT tasks - Consider modularization

## Sample Analysis Results

Based on typical enterprise job exports:

### Multi-Project Analysis
- **ERP Hub Integration**: 143 MTT tasks (Very Complex)
- **Third-Party Data Processing**: 3-6 MTT tasks (Simple)
- **Outbound Data Delivery**: 10-15 MTT tasks (Moderate)

### Key Insights
- **Resource Efficiency**: Shared connections across taskflows
- **Optimization Opportunities**: Large taskflows for potential break-down
- **Quality Issues**: Empty or incomplete taskflows flagged for review

## Enterprise Use Cases

- **Architecture Documentation** - Generate technical specs for complex integrations
- **Impact Analysis** - Understand cross-taskflow dependencies before changes
- **Compliance Auditing** - Document multi-system data flows for regulatory requirements
- **Migration Planning** - Analyze existing job structures before system upgrades
- **Performance Optimization** - Identify resource sharing and bottlenecks

## Requirements

- **Python 3.7+** (3.8+ recommended)
- **Dependencies**: pandas, networkx, matplotlib
- **System**: Windows, macOS, or Linux
- **Memory**: 4GB+ RAM (8GB+ for very large job exports)

## Files in This Project

| File | Purpose |
|------|---------|
| **`analyze_grouped_taskflows.py`** | 🎯 **Main script** - Use this for grouped job exports |
| `iics_job_analyzer.py` | Enhanced job analysis engine |
| `iics_taskflow_analyzer.py` | Core taskflow analysis base class |
| `taskflows/` | Sample job export for testing |

## Getting Started

1. **Download** the project files
2. **Install** Python dependencies: `pip install pandas networkx matplotlib`
3. **Run** analysis: `python analyze_grouped_taskflows.py your_job_export.zip`
4. **Review** generated reports in markdown, CSV, and PNG formats

## Architecture

The analyzer uses a hierarchical approach:
1. **Job-level Analysis** - Extracts and categorizes all taskflows
2. **Taskflow-level Analysis** - Deep-dive into each taskflow's components
3. **Cross-analysis** - Identifies shared resources and dependencies
4. **Reporting** - Generates multiple output formats for different audiences

---

🎉 **Ready to analyze your IICS job exports?** Start by running the analyzer on your first grouped export!