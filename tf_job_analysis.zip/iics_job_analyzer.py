#!/usr/bin/env python3
"""
Enhanced IICS Job Analyzer - Handles job exports containing multiple taskflows
Supports hierarchical analysis and reporting grouped by taskflow
"""

import json
import xml.etree.ElementTree as ET
import zipfile
import os
import pandas as pd
from pathlib import Path
from typing import Dict, List, Tuple, Any, Optional
import re
from collections import defaultdict
import networkx as nx
import matplotlib.pyplot as plt
from iics_taskflow_analyzer import IICSTaskflowAnalyzer

class IICSJobAnalyzer(IICSTaskflowAnalyzer):
    """Enhanced analyzer for IICS job exports containing multiple taskflows"""
    
    def __init__(self, extracted_path: str):
        """Initialize the job analyzer"""
        super().__init__(extracted_path)
        self.job_structure = {}
        self.taskflows = {}  # Dictionary of taskflow name -> taskflow data
        self.job_metadata = {}
        self.taskflow_hierarchies = {}
        
    def analyze_job_structure(self):
        """Analyze the job export structure to identify multiple taskflows"""
        print("🔍 Analyzing job export structure...")
        
        # Look for job-level metadata
        job_metadata_files = list(self.extracted_path.glob("**/exportMetadata*.json"))
        if job_metadata_files:
            with open(job_metadata_files[0], 'r') as f:
                self.job_metadata = json.load(f)
                
        # Find all taskflow XML files
        taskflow_files = list(self.extracted_path.glob("**/*.TASKFLOW.xml"))
        
        print(f"Found {len(taskflow_files)} taskflows in job export:")
        
        for tf_file in taskflow_files:
            taskflow_name = tf_file.stem.replace('.TASKFLOW', '')
            print(f"  • {taskflow_name}")
            
            # Store taskflow location and metadata
            self.taskflows[taskflow_name] = {
                'xml_file': tf_file,
                'directory': tf_file.parent,
                'project_path': self._get_project_path(tf_file),
                'mtt_tasks': [],
                'connections': [],
                'dtemplates': [],
                'referenced_mtt_names': self._extract_referenced_mtt_tasks(tf_file)
            }
        
        # Group components by taskflow
        self._group_components_by_taskflow()
        
        print(f"Analyzed job structure with {len(self.taskflows)} taskflows")
        
    def _get_project_path(self, file_path: Path) -> str:
        """Extract the project path from a file location"""
        parts = file_path.parts
        # Find the project structure (typically starts after 'Explore' or similar)
        project_parts = []
        start_collecting = False
        
        for part in parts:
            if part in ['Explore', 'SYS', 'Projects']:
                start_collecting = True
            if start_collecting and part != file_path.name:
                project_parts.append(part)
                
        return '/'.join(project_parts) if project_parts else 'Unknown'
    
    def _extract_referenced_mtt_tasks(self, taskflow_xml_file: Path) -> List[str]:
        """Extract MTT task names referenced in the taskflow XML"""
        referenced_tasks = []
        
        try:
            # Use text-based parsing to avoid namespace issues
            with open(taskflow_xml_file, 'r', encoding='utf-8') as f:
                content = f.read()
                
            # Find all referenceTo values using regex
            import re
            pattern = r'<option name="referenceTo">([^<]+)</option>'
            matches = re.findall(pattern, content)
            
            for reference in matches:
                # Extract MTT task name from reference like "$po:mt-WD-JOB-PROFILES"
                if reference.startswith('$po:mt-') or reference.startswith('$po:MT-'):
                    # Convert from reference format to actual MTT file name
                    mtt_name = reference.replace('$po:mt-', '').replace('$po:MT-', '')
                    mtt_name = mtt_name.replace('-', '_')  # Convert hyphens to underscores
                    mtt_name = f"mt_{mtt_name}"
                    referenced_tasks.append(mtt_name)
                        
        except Exception as e:
            print(f"⚠️ Error parsing taskflow XML {taskflow_xml_file.name}: {e}")
            
        return list(set(referenced_tasks))  # Remove duplicates
    
    def _group_components_by_taskflow(self):
        """Group MTT tasks, connections, and templates by their associated taskflows"""
        
        # Find all components
        all_mtt_files = list(self.extracted_path.glob("**/*.MTT.zip"))
        all_dtemplate_files = list(self.extracted_path.glob("**/*.DTEMPLATE.zip"))
        all_connection_files = list(self.extracted_path.glob("**/*.Connection.zip"))
        
        # Group by directory proximity and name-based matching
        for taskflow_name, taskflow_info in self.taskflows.items():
            taskflow_dir = taskflow_info['directory']
            
            # Find MTT tasks using enhanced logic
            for mtt_file in all_mtt_files:
                if self._is_related_to_taskflow_enhanced(mtt_file, taskflow_name, taskflow_dir):
                    self.taskflows[taskflow_name]['mtt_tasks'].append(mtt_file)
            
            # Find data templates using enhanced logic
            for dt_file in all_dtemplate_files:
                if self._is_related_to_taskflow_enhanced(dt_file, taskflow_name, taskflow_dir):
                    self.taskflows[taskflow_name]['dtemplates'].append(dt_file)
            
            # Find connections (these are typically shared across taskflows)
            for conn_file in all_connection_files:
                if self._is_related_to_taskflow(conn_file, taskflow_dir, allow_sys=True):
                    self.taskflows[taskflow_name]['connections'].append(conn_file)
    
    def _is_related_to_taskflow(self, component_file: Path, taskflow_dir: Path, allow_sys: bool = False) -> bool:
        """Determine if a component file is related to a specific taskflow"""
        component_dir = component_file.parent
        
        # Check if in same directory
        if component_dir == taskflow_dir:
            return True
            
        # Check if in parent/child relationship
        try:
            component_dir.relative_to(taskflow_dir)
            return True
        except ValueError:
            pass
            
        try:
            taskflow_dir.relative_to(component_dir)
            return True
        except ValueError:
            pass
        
        # Allow SYS connections to be associated with all taskflows
        if allow_sys and 'SYS' in str(component_file):
            return True
            
        return False
    
    def _is_related_to_taskflow_enhanced(self, component_file: Path, taskflow_name: str, taskflow_dir: Path, allow_sys: bool = False) -> bool:
        """Enhanced logic to determine if a component file is related to a specific taskflow"""
        component_dir = component_file.parent
        component_name = component_file.stem.replace('.MTT', '').replace('.DTEMPLATE', '').replace('.Connection', '')
        
        # Original directory-based logic
        if self._is_related_to_taskflow(component_file, taskflow_dir, allow_sys):
            return True
        
        # Check if this MTT task is explicitly referenced in the taskflow XML
        if taskflow_name in self.taskflows and component_file.suffix == '.zip' and '.MTT.' in component_file.name:
            referenced_mtt_names = self.taskflows[taskflow_name].get('referenced_mtt_names', [])
            if component_name in referenced_mtt_names:
                return True
        
        # Enhanced name-based matching
        # Remove common prefixes/suffixes for comparison
        taskflow_clean = taskflow_name.replace('tf_', '').replace('_', '').lower()
        component_clean = component_name.replace('mt_', '').replace('m_', '').replace('_', '').lower()
        
        # Check for name overlap/similarity
        if taskflow_clean in component_clean or component_clean in taskflow_clean:
            return True
            
        # Check for common patterns in sibling directories within same project
        if taskflow_dir.parent and component_dir.parent:
            # If both are under the same parent project directory
            try:
                taskflow_project = taskflow_dir.relative_to(taskflow_dir.parent.parent)
                component_project = component_dir.relative_to(component_dir.parent.parent)
                
                # Check if they're in the same project structure (e.g., ERP Hub)
                taskflow_project_parts = taskflow_project.parts
                component_project_parts = component_project.parts
                
                # If they share the same first two directory levels (e.g., Explore/ERP Hub)
                if (len(taskflow_project_parts) >= 2 and len(component_project_parts) >= 2 and
                    taskflow_project_parts[:2] == component_project_parts[:2]):
                    
                    # Check for name-based association within the same project
                    if taskflow_clean in component_clean or component_clean in taskflow_clean:
                        return True
                        
                    # Special case: Check for common Workday patterns
                    if ('wd' in taskflow_clean and 'wd' in component_clean) or \
                       ('workday' in taskflow_clean and 'workday' in component_clean):
                        return True
                        
            except ValueError:
                pass
        
        return False
    
    def analyze_taskflow_details(self, taskflow_name: str) -> Dict:
        """Analyze detailed information for a specific taskflow"""
        if taskflow_name not in self.taskflows:
            return {}
            
        taskflow_info = self.taskflows[taskflow_name]
        details = {
            'name': taskflow_name,
            'project_path': taskflow_info['project_path'],
            'xml_file': str(taskflow_info['xml_file']),
            'mtt_tasks': {},
            'connections': {},
            'dtemplates': {},
            'execution_order': [],
            'summary': {}
        }
        
        # Analyze taskflow XML for execution order
        try:
            tree = ET.parse(taskflow_info['xml_file'])
            root = tree.getroot()
            details['execution_order'] = self._extract_execution_order(root)
        except Exception as e:
            print(f"⚠️  Could not analyze taskflow XML for {taskflow_name}: {e}")
        
        # Analyze MTT tasks for this taskflow
        for mtt_file in taskflow_info['mtt_tasks']:
            task_name = mtt_file.stem.replace('.MTT', '')
            mtt_details = self._analyze_single_mtt(mtt_file)
            if mtt_details:
                details['mtt_tasks'][task_name] = mtt_details
        
        # Analyze connections
        for conn_file in taskflow_info['connections']:
            conn_name = conn_file.stem.replace('.Connection', '')
            details['connections'][conn_name] = {'file': str(conn_file)}
        
        # Analyze data templates
        for dt_file in taskflow_info['dtemplates']:
            dt_name = dt_file.stem.replace('.DTEMPLATE', '')
            details['dtemplates'][dt_name] = {'file': str(dt_file)}
        
        # Generate summary statistics
        details['summary'] = {
            'total_mtt_tasks': len(details['mtt_tasks']),
            'total_connections': len(details['connections']),
            'total_dtemplates': len(details['dtemplates']),
            'has_execution_order': len(details['execution_order']) > 0
        }
        
        return details
    
    def _extract_execution_order(self, xml_root) -> List[str]:
        """Extract task execution order from taskflow XML"""
        execution_order = []
        
        # Look for service elements that represent task executions
        services = xml_root.findall(".//service")
        for service in services:
            title_elem = service.find("title")
            if title_elem is not None and title_elem.text:
                execution_order.append(title_elem.text)
        
        return execution_order
    
    def _analyze_single_mtt(self, mtt_file: Path) -> Optional[Dict]:
        """Analyze a single MTT file and return detailed information"""
        try:
            with zipfile.ZipFile(mtt_file, 'r') as zip_ref:
                # Look for mtTask.json
                if 'mtTask.json' in zip_ref.namelist():
                    with zip_ref.open('mtTask.json') as json_file:
                        mtt_data = json.load(json_file)
                        
                        # Handle list format
                        if isinstance(mtt_data, list) and len(mtt_data) > 0:
                            mtt_data = mtt_data[0]
                        
                        return self._extract_transformation_details(mtt_data)
        except Exception as e:
            print(f"⚠️  Error analyzing MTT {mtt_file.name}: {e}")
        
        return None
    
    def generate_hierarchical_report(self, output_file: str = "job_analysis_report.md"):
        """Generate a hierarchical report grouped by taskflow"""
        
        # Analyze all taskflows in the job
        taskflow_analyses = {}
        for taskflow_name in self.taskflows:
            taskflow_analyses[taskflow_name] = self.analyze_taskflow_details(taskflow_name)
        
        # Generate markdown content
        md_content = self._generate_job_markdown_content(taskflow_analyses)
        
        # Write to file
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(md_content)
            
        print(f"Generated hierarchical job report: {output_file}")
        
        # Generate visualization
        self._generate_taskflow_visualization(taskflow_analyses)
    
    def _generate_taskflow_visualization(self, taskflow_analyses: Dict):
        """Generate a visual summary of taskflows"""
        try:
            import matplotlib.pyplot as plt
            import numpy as np
            
            # Prepare data for visualization
            taskflow_names = list(taskflow_analyses.keys())
            mtt_counts = [analysis['summary']['total_mtt_tasks'] for analysis in taskflow_analyses.values()]
            
            if not taskflow_names:
                return
            
            # Create visualization
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
            
            # Bar chart of MTT tasks per taskflow
            colors = plt.cm.Set3(np.linspace(0, 1, len(taskflow_names)))
            bars = ax1.bar(range(len(taskflow_names)), mtt_counts, color=colors)
            ax1.set_xlabel('Taskflows')
            ax1.set_ylabel('Number of MTT Tasks')
            ax1.set_title('MTT Tasks per Taskflow')
            ax1.set_xticks(range(len(taskflow_names)))
            ax1.set_xticklabels([name[:15] + '...' if len(name) > 15 else name 
                                for name in taskflow_names], rotation=45, ha='right')
            
            # Add value labels on bars
            for bar, count in zip(bars, mtt_counts):
                if count > 0:
                    ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.5,
                            str(count), ha='center', va='bottom')
            
            # Pie chart of taskflow distribution
            non_zero_indices = [i for i, count in enumerate(mtt_counts) if count > 0]
            if non_zero_indices:
                non_zero_counts = [mtt_counts[i] for i in non_zero_indices]
                non_zero_names = [taskflow_names[i] for i in non_zero_indices]
                
                ax2.pie(non_zero_counts, labels=[name[:15] + '...' if len(name) > 15 else name 
                                               for name in non_zero_names], 
                       autopct='%1.1f%%', startangle=90)
                ax2.set_title('Distribution of MTT Tasks')
            else:
                ax2.text(0.5, 0.5, 'No MTT Tasks Found', ha='center', va='center', 
                        transform=ax2.transAxes, fontsize=12)
                ax2.set_title('Distribution of MTT Tasks')
            
            plt.tight_layout()
            plt.savefig('job_taskflow_summary.png', dpi=300, bbox_inches='tight')
            plt.close()
            
            print("Generated taskflow visualization: job_taskflow_summary.png")
            
        except ImportError:
            print("Matplotlib not available, skipping visualization")
        except Exception as e:
            print(f"Error generating visualization: {e}")
    
    def _generate_job_markdown_content(self, taskflow_analyses: Dict) -> str:
        """Generate markdown content for the job analysis report"""
        
        md = []
        md.append("# IICS Job Analysis Report - Multi-Taskflow Export")
        md.append("")
        md.append("## Job Overview")
        md.append("")
        
        # Job-level information
        if self.job_metadata:
            md.append(f"- **Job Export Name**: {self.job_metadata.get('name', 'Unknown')}")
            md.append(f"- **Source Organization**: {self.job_metadata.get('sourceOrgName', 'Unknown')}")
            md.append(f"- **Total Objects**: {len(self.job_metadata.get('exportedObjects', []))}")
        
        md.append(f"- **Total Taskflows**: {len(self.taskflows)}")
        md.append(f"- **Analysis Date**: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}")
        md.append("")
        
        # Job-level summary
        total_mtt_tasks = sum(len(tf_info['mtt_tasks']) for tf_info in self.taskflows.values())
        total_connections = len(set(str(conn) for tf_info in self.taskflows.values() for conn in tf_info['connections']))
        total_dtemplates = sum(len(tf_info['dtemplates']) for tf_info in self.taskflows.values())
        
        md.append("## Job Summary Statistics")
        md.append("")
        md.append(f"- **Total MTT Tasks**: {total_mtt_tasks}")
        md.append(f"- **Unique Connections**: {total_connections}")
        md.append(f"- **Total Data Templates**: {total_dtemplates}")
        md.append("")
        
        # Taskflow overview table
        md.append("## Taskflow Overview")
        md.append("")
        md.append("| Taskflow Name | Project Path | MTT Tasks | Connections | Templates |")
        md.append("|---|---|---|---|---|")
        
        for taskflow_name, analysis in taskflow_analyses.items():
            summary = analysis['summary']
            md.append(f"| {taskflow_name} | {analysis['project_path']} | {summary['total_mtt_tasks']} | {summary['total_connections']} | {summary['total_dtemplates']} |")
        
        md.append("")
        
        # Detailed analysis for each taskflow
        md.append("## Detailed Taskflow Analysis")
        md.append("")
        
        for taskflow_name, analysis in taskflow_analyses.items():
            md.append(f"### Taskflow: {taskflow_name}")
            md.append("")
            md.append(f"**Project Path**: `{analysis['project_path']}`")
            md.append("")
            
            # Execution order if available
            if analysis['execution_order']:
                md.append("#### Task Execution Order")
                md.append("")
                for i, task in enumerate(analysis['execution_order'], 1):
                    md.append(f"{i}. {task}")
                md.append("")
            
            # MTT Tasks analysis
            if analysis['mtt_tasks']:
                md.append("#### Mapping Tasks (MTT)")
                md.append("")
                
                for task_name, task_details in analysis['mtt_tasks'].items():
                    md.append(f"##### {task_name}")
                    md.append("")
                    
                    # Basic information
                    md.append("**Basic Information:**")
                    md.append(f"- **Task Name**: {task_details.get('task_name', task_name)}")
                    md.append(f"- **Mapping Reference**: {task_details.get('mapping_name', 'N/A')}")
                    operation_types = task_details.get('operation_types', set())
                    md.append(f"- **Operation Types**: {', '.join(operation_types) if operation_types else 'N/A'}")
                    md.append("")
                    
                    # Sources
                    sources = task_details.get('sources', [])
                    if sources:
                        md.append("**Sources:**")
                        for i, source in enumerate(sources, 1):
                            md.append(f"- **Source {i}**: {source.get('name', 'Unknown')}")
                            md.append(f"  - Connection: {source.get('connection_id', 'N/A')}")
                            md.append(f"  - Object: {source.get('object_name', 'N/A')}")
                            md.append(f"  - Schema: {source.get('schema', 'N/A')}")
                            if source.get('filter'):
                                md.append(f"  - Filter: `{source['filter']}`")
                        md.append("")
                    
                    # Targets
                    targets = task_details.get('targets', [])
                    if targets:
                        md.append("**Targets:**")
                        for i, target in enumerate(targets, 1):
                            md.append(f"- **Target {i}**: {target.get('name', 'Unknown')}")
                            md.append(f"  - Connection: {target.get('connection_id', 'N/A')}")
                            md.append(f"  - Object: {target.get('object_name', 'N/A')}")
                            md.append(f"  - Operation: {target.get('operation_type', 'N/A')}")
                        md.append("")
                    
                    # Lookups
                    lookups = task_details.get('lookups', [])
                    if lookups:
                        md.append("**Lookups:**")
                        for i, lookup in enumerate(lookups, 1):
                            md.append(f"- **Lookup {i}**: {lookup.get('name', 'Unknown')}")
                            md.append(f"  - Connection: {lookup.get('connection_id', 'N/A')}")
                            md.append(f"  - Object: {lookup.get('object_name', 'N/A')}")
                            md.append(f"  - Cache Type: {lookup.get('cache_type', 'N/A')}")
                        md.append("")
                    
                    md.append("---")
                    md.append("")
            
            # Connections summary for this taskflow
            if analysis['connections']:
                md.append("#### Connections Used")
                md.append("")
                md.append("| Connection Name | Type |")
                md.append("|---|---|")
                for conn_name in analysis['connections']:
                    md.append(f"| {conn_name} | Connection |")
                md.append("")
            
            # Data templates summary
            if analysis['dtemplates']:
                md.append("#### Data Templates")
                md.append("")
                md.append("| Template Name | Type |")
                md.append("|---|---|")
                for dt_name in analysis['dtemplates']:
                    md.append(f"| {dt_name} | DTEMPLATE |")
                md.append("")
            
            md.append("---")
            md.append("")
        
        # Cross-taskflow analysis
        md.append("## Cross-Taskflow Analysis")
        md.append("")
        
        # Shared connections
        all_connections = defaultdict(list)
        for taskflow_name, analysis in taskflow_analyses.items():
            for conn_name in analysis['connections']:
                all_connections[conn_name].append(taskflow_name)
        
        md.append("### Shared Connections")
        md.append("")
        md.append("| Connection | Used by Taskflows | Usage Count |")
        md.append("|---|---|---|")
        for conn_name, taskflows in all_connections.items():
            md.append(f"| {conn_name} | {', '.join(taskflows)} | {len(taskflows)} |")
        md.append("")
        
        md.append("---")
        md.append("*Report generated by IICS Job Analyzer - Multi-Taskflow Edition*")
        
        return "\n".join(md)
    
    def run_job_analysis(self):
        """Run complete job analysis workflow"""
        print("Starting IICS Job Analysis (Multi-Taskflow)...")
        print("-" * 60)
        
        # Load job-level metadata
        self.load_export_metadata()
        
        # Analyze job structure
        self.analyze_job_structure()
        
        # Generate reports
        self.generate_hierarchical_report()
        self.export_job_csv()
        
        print("\n✅ Job analysis completed successfully!")
        
    def export_job_csv(self, output_file: str = "job_analysis.csv"):
        """Export job analysis to CSV with taskflow grouping"""
        data = []
        
        for taskflow_name, taskflow_info in self.taskflows.items():
            analysis = self.analyze_taskflow_details(taskflow_name)
            
            # Add taskflow-level row
            data.append({
                'Type': 'TASKFLOW',
                'Taskflow': taskflow_name,
                'Component_Name': taskflow_name,
                'Project_Path': analysis['project_path'],
                'Object_Type': 'TASKFLOW',
                'MTT_Count': analysis['summary']['total_mtt_tasks'],
                'Connection_Count': analysis['summary']['total_connections'],
                'Template_Count': analysis['summary']['total_dtemplates']
            })
            
            # Add MTT task rows
            for task_name, task_details in analysis['mtt_tasks'].items():
                operation_types = ', '.join(task_details.get('operation_types', []))
                data.append({
                    'Type': 'MTT',
                    'Taskflow': taskflow_name,
                    'Component_Name': task_name,
                    'Project_Path': analysis['project_path'],
                    'Object_Type': 'MTT',
                    'Mapping_Reference': task_details.get('mapping_name', ''),
                    'Operation_Types': operation_types,
                    'Source_Count': len(task_details.get('sources', [])),
                    'Target_Count': len(task_details.get('targets', [])),
                    'Lookup_Count': len(task_details.get('lookups', []))
                })
        
        df = pd.DataFrame(data)
        df.to_csv(output_file, index=False)
        print(f"Exported job analysis to {output_file}")

def main():
    """Main function for job analysis"""
    import sys
    
    if len(sys.argv) > 1:
        extracted_path = sys.argv[1]
    else:
        extracted_path = "taskflows/job_extracted"
    
    if not os.path.exists(extracted_path):
        print(f"❌ Extracted path not found: {extracted_path}")
        print("Please extract the job export first.")
        return
        
    analyzer = IICSJobAnalyzer(extracted_path)
    analyzer.run_job_analysis()

if __name__ == "__main__":
    main()