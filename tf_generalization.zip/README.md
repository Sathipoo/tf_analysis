# IICS Taskflow Analyzer

🚀 **Comprehensive analysis tool for Informatica Intelligent Cloud Services (IICS) taskflow exports**

## Overview

The IICS Taskflow Analyzer is a powerful Python-based tool that automatically analyzes **any** IICS taskflow export and generates detailed technical documentation including:

- 📊 **Detailed mapping analysis** with source/target details
- 🔗 **Connection usage patterns** and data flow diagrams  
- 📈 **Component inventory** and technical statistics
- 🎨 **Visual dependency graphs** and architecture diagrams

## Quick Start

### 1. Install Dependencies
```bash
pip install pandas networkx matplotlib
```

### 2. Analyze Any IICS Export
```bash
python analyze_any_taskflow.py your_export.zip
```

### 3. View Results
- **`detailed_taskflow_report.md`** - Complete technical analysis
- **`taskflow_analysis.csv`** - Data for further analysis  
- **`taskflow_dependencies.png`** - Visual dependency graph

## Key Features

✅ **Universal Compatibility** - Works with ANY IICS taskflow export  
✅ **Auto-Discovery** - Automatically finds and analyzes all components  
✅ **Detailed Mapping Analysis** - Source/target/transformation details  
✅ **Visual Documentation** - Dependency graphs and data flow diagrams  
✅ **Multiple Output Formats** - Markdown, CSV, PNG for different audiences  
✅ **Command-Line Interface** - Perfect for automation and CI/CD pipelines  
✅ **Enterprise Ready** - Handles large exports with 100+ mappings  

## Generated Analysis

### Detailed Mapping Report
For each mapping task, get complete details on:
- **Sources**: Connections, objects, schemas, filter conditions
- **Targets**: Connections, objects, operation types (Insert/Update/Upsert)
- **Lookups**: Cache configurations and validation logic
- **Transformations**: Session properties and optimization settings
- **Data Flows**: Visual ASCII diagrams showing data movement

### Technical Documentation
- Component inventory with GUIDs and metadata
- Connection usage analysis and patterns
- Object type breakdowns and statistics
- Dependency relationships and execution flows

## Usage Examples

### Basic Analysis
```bash
# Analyze any IICS export
python analyze_any_taskflow.py my_export.zip
```

### Advanced Options
```bash
# Custom output directory and keep extracted files
python analyze_any_taskflow.py my_export.zip --output analysis/ --keep-extracted
```

### Enterprise Use Cases
- **Data Architecture Documentation** - Generate technical specs for stakeholders
- **Impact Analysis** - Understand data dependencies before changes
- **Compliance Auditing** - Document data flows for regulatory requirements
- **Migration Planning** - Analyze existing integrations before system upgrades

## Supported Export Types

✅ **Single Taskflows** - Individual workflow exports  
✅ **Multiple Taskflows** - Complex multi-workflow packages  
✅ **Mapping Collections** - MTT task exports  
✅ **Connection Exports** - Database/cloud connection definitions  
✅ **Project Exports** - Complete IICS project structures  

## Industries & Domains

Works with IICS exports from any industry:
- 🏦 **Financial Services** - Banking, insurance data flows
- 🏥 **Healthcare** - Patient data, clinical system integrations  
- 🏭 **Manufacturing** - Supply chain, inventory management
- 🛒 **Retail/E-commerce** - Customer data, order processing
- 🏛️ **Government** - Citizen services, regulatory reporting
- 📚 **Education** - Student information systems, HR data

## Documentation

📖 **[Complete Setup & Execution Guide](SETUP_AND_EXECUTION_GUIDE.md)** - Detailed installation and usage instructions  
📋 **[Generalization Confirmation](GENERALIZATION_CONFIRMED.md)** - Technical validation and capabilities  

## Files in This Project

| File | Purpose |
|------|---------|
| **`analyze_any_taskflow.py`** | 🎯 **Main script** - Use this for any IICS export |
| `iics_taskflow_analyzer.py` | Core analysis engine |
| `generate_detailed_report.py` | Standalone report generator |
| `test_generalization.py` | Validation and testing utilities |
| `SETUP_AND_EXECUTION_GUIDE.md` | 📖 Complete setup instructions |

## Quick Help

```bash
# See all available options
python analyze_any_taskflow.py --help

# Example with all options
python analyze_any_taskflow.py export.zip --output results/ --keep-extracted --verbose
```

## Requirements

- **Python 3.7+** (3.8+ recommended)
- **Dependencies**: pandas, networkx, matplotlib
- **System**: Windows, macOS, or Linux
- **Memory**: 2GB+ RAM (4GB+ for large exports)

## Getting Started

1. **Download** the project files
2. **Install** Python dependencies: `pip install pandas networkx matplotlib`
3. **Run** analysis: `python analyze_any_taskflow.py your_export.zip`
4. **Review** generated reports in markdown, CSV, and PNG formats

---

🎉 **Ready to analyze your IICS exports?** Start with the [Setup Guide](SETUP_AND_EXECUTION_GUIDE.md) for detailed instructions!