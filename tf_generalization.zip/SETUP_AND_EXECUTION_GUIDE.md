# IICS Taskflow Analyzer - Setup & Execution Guide

## 🚀 Quick Start

This guide will help you set up and run the IICS Taskflow Analyzer to analyze **any** IICS (Informatica Intelligent Cloud Services) taskflow export.

## 📋 Prerequisites

### System Requirements
- **Python 3.7+** (Python 3.8 or higher recommended)
- **Operating System**: Windows, macOS, or Linux
- **Memory**: 2GB+ RAM (4GB+ for large exports)
- **Disk Space**: 1GB+ free space for analysis outputs

### Required Python Libraries
The analyzer will automatically check for these dependencies:
- `pandas` - Data analysis and CSV generation
- `networkx` - Dependency graph creation
- `matplotlib` - Visualization generation
- `pathlib` - File path handling (built-in)
- `zipfile` - Zip extraction (built-in)
- `json` - JSON parsing (built-in)
- `xml.etree.ElementTree` - XML parsing (built-in)

## ⚙️ Installation

### Step 1: Download the Project
```bash
# Option A: Clone/download the project files
# Ensure you have these files in your directory:
# - analyze_any_taskflow.py
# - iics_taskflow_analyzer.py
# - generate_detailed_report.py (optional)
```

### Step 2: Install Dependencies
```bash
# Install required Python packages
pip install pandas networkx matplotlib

# Or using conda
conda install pandas networkx matplotlib

# Or install all at once
pip install pandas networkx matplotlib pathlib2
```

### Step 3: Verify Installation
```bash
# Test that all dependencies are available
python -c "import pandas, networkx, matplotlib; print('✅ All dependencies installed successfully!')"
```

## 🎯 Basic Usage

### Analyze Any IICS Export (Simplest Method)
```bash
# Basic analysis - works with ANY IICS export zip file
python analyze_any_taskflow.py your_export.zip
```

**That's it!** The analyzer will:
1. ✅ Extract your zip file
2. ✅ Validate the IICS export
3. ✅ Analyze all components
4. ✅ Generate comprehensive reports

### Generated Output Files
After running, you'll find these files in your directory:
- **`detailed_taskflow_report.md`** - Complete analysis with mappings, sources, targets
- **`taskflow_analysis.csv`** - Structured data for further analysis
- **`taskflow_dependencies.png`** - Visual dependency graph

## 🔧 Advanced Usage

### Custom Output Directory
```bash
# Put analysis results in a specific folder
python analyze_any_taskflow.py your_export.zip --output analysis_results/
```

### Keep Extracted Files for Manual Review
```bash
# Keep the extracted files for manual inspection
python analyze_any_taskflow.py your_export.zip --keep-extracted
```

### Full Command with All Options
```bash
# Complete analysis with all options
python analyze_any_taskflow.py your_export.zip \
  --output my_analysis_folder/ \
  --keep-extracted \
  --verbose
```

### Command Line Help
```bash
# See all available options
python analyze_any_taskflow.py --help
```

## 📁 File Descriptions

### Core Analysis Files
| File | Purpose |
|------|---------|
| `analyze_any_taskflow.py` | **Main script** - Use this for any IICS export |
| `iics_taskflow_analyzer.py` | Core analysis engine (automatically used) |
| `generate_detailed_report.py` | Alternative standalone report generator |

### Generated Output Files
| File | Content |
|------|---------|
| `detailed_taskflow_report.md` | **📊 Main Report** - Comprehensive analysis with mappings, transformations, source/target details |
| `taskflow_analysis.csv` | **📈 Data Export** - Structured component inventory for Excel/analysis tools |
| `taskflow_dependencies.png` | **🎨 Visual Graph** - Dependency relationships diagram |

## 🎯 Usage Examples

### Example 1: Financial Institution
```bash
# Analyze banking data integration flows
python analyze_any_taskflow.py bank_payment_flows.zip --output banking_analysis/
```

### Example 2: Healthcare System
```bash
# Analyze patient data synchronization
python analyze_any_taskflow.py patient_data_sync.zip --keep-extracted
```

### Example 3: E-commerce Platform
```bash
# Analyze customer order processing flows
python analyze_any_taskflow.py ecommerce_orders.zip --output reports/q4_2024/
```

### Example 4: Batch Processing Multiple Exports
```bash
# Analyze multiple exports (Windows)
for %f in (*.zip) do python analyze_any_taskflow.py "%f" --output "analysis_%~nf/"

# Analyze multiple exports (Linux/Mac)
for file in *.zip; do python analyze_any_taskflow.py "$file" --output "analysis_${file%.zip}/"; done
```

## 🔍 What the Analysis Provides

### For Each Mapping Task:
- ✅ **Source Details**: Connections, objects, schemas, filters
- ✅ **Target Details**: Connections, objects, operations (Insert/Update/Upsert)
- ✅ **Transformation Logic**: Lookups, data flows, session properties
- ✅ **Performance Settings**: Optimization options, caching configurations

### Summary Information:
- ✅ **Component Inventory**: All tasks, connections, templates
- ✅ **Connection Usage**: Which systems are connected and how
- ✅ **Data Flow Patterns**: Visual representation of data movement
- ✅ **Technical Statistics**: Object counts, operation types, etc.

## 🛠️ Troubleshooting

### Common Issues & Solutions

#### "Module not found" Error
```bash
# Problem: Missing Python packages
# Solution: Install dependencies
pip install pandas networkx matplotlib
```

#### "Zip file not found" Error
```bash
# Problem: Incorrect file path
# Solution: Use full path or check file location
python analyze_any_taskflow.py "C:\full\path\to\your_export.zip"
```

#### "Invalid IICS export" Error
```bash
# Problem: Not a valid IICS export zip
# Solution: Ensure you're using an export from IICS (not just any zip file)
# The zip should contain exportMetadata.json and .MTT.zip files
```

#### "Permission denied" Error
```bash
# Problem: No write permissions in current directory
# Solution: Run from a writable directory or specify output folder
python analyze_any_taskflow.py your_export.zip --output C:\temp\analysis\
```

#### Analysis Taking Too Long
```bash
# Problem: Large export with many components
# Solution: This is normal for large exports (100+ mappings)
# Let it run - progress messages will show what's being processed
```

### Getting Help
If you encounter issues:
1. Check that your zip file is a valid IICS export
2. Verify all Python dependencies are installed
3. Try running with `--verbose` flag for more details
4. Ensure you have write permissions in the output directory

## 📊 Understanding the Output

### Reading the Detailed Report
The `detailed_taskflow_report.md` file contains:

1. **Overview Section**: Export summary and statistics
2. **Connection Summary**: All data source connections
3. **Mapping Tasks Analysis**: Detailed breakdown of each task including:
   - Basic information (task name, mapping reference)
   - Source details (what data is read from where)
   - Target details (where data is written and how)
   - Lookup details (data validation and enrichment)
   - Session properties (performance and optimization settings)
   - Data flow summary (visual ASCII diagram)

### Using the CSV Export
The `taskflow_analysis.csv` can be opened in:
- **Excel** - For business user analysis
- **Power BI** - For dashboard creation
- **Python/R** - For further data analysis
- **Database tools** - For integration with other systems

## 🎯 Best Practices

### For Regular Use:
1. **Organize outputs**: Use `--output` to create dated folders
2. **Keep extracts**: Use `--keep-extracted` for large exports you'll analyze repeatedly
3. **Batch processing**: Analyze multiple exports in sequence for comparison

### For Team Sharing:
1. **Share the markdown report** - Most readable for stakeholders
2. **Use CSV for analysis** - Import into business intelligence tools
3. **Include the PNG diagram** - Great for architecture discussions

### For Documentation:
1. **Generate reports before deployments** - Track changes over time
2. **Include in project documentation** - Technical specifications
3. **Archive analysis results** - Historical reference and compliance

## 🚀 Ready to Start!

You're now ready to analyze any IICS taskflow export! Start with:

```bash
python analyze_any_taskflow.py your_first_export.zip
```

The analyzer will guide you through the process and generate comprehensive reports automatically.

---

**Need more help?** Check the generated `detailed_taskflow_report.md` file for examples of what the analysis produces, or run with `--help` for all command-line options.