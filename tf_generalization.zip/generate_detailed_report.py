#!/usr/bin/env python3
"""
Standalone script to generate detailed IICS taskflow analysis report
"""

from iics_taskflow_analyzer import IICSTaskflowAnalyzer
import os

def main():
    """Generate detailed markdown report for IICS taskflow"""
    
    # Path to extracted taskflow files
    extracted_path = "taskflows/extracted"
    
    if not os.path.exists(extracted_path):
        print(f"❌ Extracted path not found: {extracted_path}")
        print("Please run the unzip script first.")
        return
        
    print("📝 Generating detailed IICS taskflow analysis report...")
    print("-" * 60)
    
    # Initialize analyzer
    analyzer = IICSTaskflowAnalyzer(extracted_path)
    
    # Load metadata and extract mapping tasks
    analyzer.load_export_metadata()
    analyzer.extract_mtt_tasks()
    
    # Generate detailed markdown report
    analyzer.generate_detailed_markdown_report("detailed_taskflow_report.md")
    
    print("\n✅ Detailed report generation completed!")
    print("\nGenerated files:")
    print("- detailed_taskflow_report.md - Comprehensive mapping analysis")
    
    # Show quick stats
    print(f"\n📊 Quick Stats:")
    print(f"- Total MTT Tasks Analyzed: {len(analyzer.mtt_tasks)}")
    print(f"- Total Objects in Package: {len(analyzer.metadata.get('exportedObjects', []))}")
    
if __name__ == "__main__":
    main()