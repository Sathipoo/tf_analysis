#!/usr/bin/env python3
"""
Quick script to unzip and examine IICS taskflow export
"""

import zipfile
import os
from pathlib import Path

def unzip_taskflow():
    # Set paths
    zip_path = "taskflows/Tf_Soft_Delete_Records_New-1754392566403.zip"
    extract_path = "taskflows/extracted"
    
    # Create extraction directory if it doesn't exist
    Path(extract_path).mkdir(parents=True, exist_ok=True)
    
    print(f"Extracting {zip_path} to {extract_path}...")
    
    try:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            # List contents first
            file_list = zip_ref.namelist()
            print(f"\nFound {len(file_list)} files in the zip:")
            
            # Show first 20 files
            for i, file_name in enumerate(file_list[:20]):
                print(f"  {file_name}")
            
            if len(file_list) > 20:
                print(f"  ... and {len(file_list) - 20} more files")
            
            # Extract all files
            zip_ref.extractall(extract_path)
            print(f"\n✓ Successfully extracted to {extract_path}")
            
            # Analyze file types
            file_extensions = {}
            for file_name in file_list:
                ext = Path(file_name).suffix.lower()
                if ext:
                    file_extensions[ext] = file_extensions.get(ext, 0) + 1
                else:
                    file_extensions['no_extension'] = file_extensions.get('no_extension', 0) + 1
            
            print("\nFile types found:")
            for ext, count in sorted(file_extensions.items()):
                print(f"  {ext}: {count} files")
                
    except Exception as e:
        print(f"Error extracting zip file: {e}")
        return False
    
    return True

def explore_extracted_structure():
    """Explore the directory structure of extracted files"""
    extract_path = "taskflows/extracted"
    
    if not os.path.exists(extract_path):
        print(f"Extraction directory {extract_path} not found")
        return
    
    print(f"\nExploring directory structure of {extract_path}:")
    
    for root, dirs, files in os.walk(extract_path):
        level = root.replace(extract_path, '').count(os.sep)
        indent = ' ' * 2 * level
        print(f"{indent}{os.path.basename(root)}/")
        
        subindent = ' ' * 2 * (level + 1)
        for file in files[:5]:  # Show first 5 files per directory
            print(f"{subindent}{file}")
        
        if len(files) > 5:
            print(f"{subindent}... and {len(files) - 5} more files")

if __name__ == "__main__":
    print("IICS Taskflow Unzip Tool")
    print("=" * 40)
    
    if unzip_taskflow():
        explore_extracted_structure()
        
        print("\n" + "=" * 40)
        print("Next steps:")
        print("1. Examine key files in taskflows/extracted/")
        print("2. Look for main configuration files (likely XML or JSON)")
        print("3. Identify the taskflow definition structure")