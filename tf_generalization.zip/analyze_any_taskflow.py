#!/usr/bin/env python3
"""
Generalized IICS Taskflow Analyzer - Works with ANY IICS taskflow export
Usage: python analyze_any_taskflow.py <path_to_zip_file> [output_directory]
"""

import sys
import os
import argparse
from pathlib import Path
import zipfile
from iics_taskflow_analyzer import IICSTaskflowAnalyzer

def extract_taskflow_zip(zip_path: str, extract_dir: str = None) -> str:
    """
    Extract any IICS taskflow zip file to a specified directory
    
    Args:
        zip_path: Path to the IICS taskflow zip file
        extract_dir: Directory to extract to (optional, auto-generated if not provided)
    
    Returns:
        Path to the extracted directory
    """
    zip_path = Path(zip_path)
    
    if not zip_path.exists():
        raise FileNotFoundError(f"Zip file not found: {zip_path}")
    
    # Auto-generate extract directory if not provided
    if extract_dir is None:
        extract_dir = zip_path.parent / f"{zip_path.stem}_extracted"
    else:
        extract_dir = Path(extract_dir)
    
    # Create extraction directory
    extract_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"🗂️  Extracting {zip_path.name} to {extract_dir}...")
    
    try:
        with zipfile.ZipFile(zip_path, 'r') as zip_ref:
            file_list = zip_ref.namelist()
            print(f"📦 Found {len(file_list)} files in the export package")
            
            # Show first few files for verification
            print("📄 Sample files:")
            for file_name in file_list[:5]:
                print(f"   • {file_name}")
            if len(file_list) > 5:
                print(f"   ... and {len(file_list) - 5} more files")
            
            # Extract all files
            zip_ref.extractall(extract_dir)
            print(f"✅ Successfully extracted to {extract_dir}")
            
            # Analyze file types
            file_extensions = {}
            for file_name in file_list:
                ext = Path(file_name).suffix.lower()
                if ext:
                    file_extensions[ext] = file_extensions.get(ext, 0) + 1
                else:
                    file_extensions['no_extension'] = file_extensions.get('no_extension', 0) + 1
            
            print(f"\n📊 File types in export:")
            for ext, count in sorted(file_extensions.items()):
                print(f"   • {ext}: {count} files")
                
    except Exception as e:
        raise Exception(f"Error extracting zip file: {e}")
    
    return str(extract_dir)

def validate_iics_export(extracted_path: str) -> dict:
    """
    Validate that the extracted directory contains a valid IICS export
    
    Args:
        extracted_path: Path to extracted directory
        
    Returns:
        Dictionary with validation results and export info
    """
    extracted_path = Path(extracted_path)
    validation = {
        'is_valid': False,
        'export_name': 'Unknown',
        'object_count': 0,
        'issues': []
    }
    
    # Check for metadata file
    metadata_file = extracted_path / "exportMetadata.v2.json"
    if not metadata_file.exists():
        # Try alternative metadata file names
        alt_files = list(extracted_path.glob("**/exportMetadata*.json"))
        if alt_files:
            metadata_file = alt_files[0]
            print(f"ℹ️  Found alternative metadata file: {metadata_file.name}")
        else:
            validation['issues'].append("No exportMetadata.json file found")
            return validation
    
    try:
        import json
        with open(metadata_file, 'r') as f:
            metadata = json.load(f)
            validation['export_name'] = metadata.get('name', 'Unknown')
            validation['object_count'] = len(metadata.get('exportedObjects', []))
            validation['source_org'] = metadata.get('sourceOrgName', 'Unknown')
    except Exception as e:
        validation['issues'].append(f"Error reading metadata: {e}")
        return validation
    
    # Check for taskflow components
    mtt_files = list(extracted_path.glob("**/*.MTT.zip"))
    taskflow_files = list(extracted_path.glob("**/*.TASKFLOW.xml"))
    connection_files = list(extracted_path.glob("**/*.Connection.zip"))
    
    if not any([mtt_files, taskflow_files]):
        validation['issues'].append("No MTT or TASKFLOW files found")
        return validation
    
    validation['is_valid'] = True
    validation['components'] = {
        'mtt_tasks': len(mtt_files),
        'taskflows': len(taskflow_files),
        'connections': len(connection_files)
    }
    
    return validation

def analyze_taskflow(zip_file_path: str, output_dir: str = None, keep_extracted: bool = False):
    """
    Complete analysis workflow for any IICS taskflow export
    
    Args:
        zip_file_path: Path to the IICS export zip file
        output_dir: Directory for output files (optional)
        keep_extracted: Whether to keep extracted files after analysis
    """
    
    print("🚀 Starting Generalized IICS Taskflow Analysis")
    print("=" * 60)
    
    try:
        # Step 1: Extract the zip file
        extracted_path = extract_taskflow_zip(zip_file_path)
        
        # Step 2: Validate the export
        print(f"\n🔍 Validating IICS export...")
        validation = validate_iics_export(extracted_path)
        
        if not validation['is_valid']:
            print("❌ Invalid IICS export detected:")
            for issue in validation['issues']:
                print(f"   • {issue}")
            return False
        
        print("✅ Valid IICS export detected!")
        print(f"   • Export Name: {validation['export_name']}")
        print(f"   • Source Organization: {validation.get('source_org', 'Unknown')}")
        print(f"   • Total Objects: {validation['object_count']}")
        if 'components' in validation:
            print(f"   • MTT Tasks: {validation['components']['mtt_tasks']}")
            print(f"   • Taskflows: {validation['components']['taskflows']}")
            print(f"   • Connections: {validation['components']['connections']}")
        
        # Step 3: Run the analysis
        print(f"\n📊 Running comprehensive analysis...")
        
        # Convert to absolute path before changing directories
        extracted_path_abs = Path(extracted_path).absolute()
        
        # Set output directory if specified
        if output_dir:
            output_dir = Path(output_dir)
            output_dir.mkdir(parents=True, exist_ok=True)
            original_dir = os.getcwd()
            os.chdir(output_dir)
            print(f"📁 Output directory: {output_dir.absolute()}")
        
        # Initialize analyzer with absolute path
        analyzer = IICSTaskflowAnalyzer(str(extracted_path_abs))
        
        # Run full analysis
        analyzer.run_full_analysis()
        
        # Return to original directory if we changed it
        if output_dir:
            os.chdir(original_dir)
        
        # Step 4: Clean up if requested
        if not keep_extracted:
            import shutil
            shutil.rmtree(extracted_path)
            print(f"🧹 Cleaned up extracted files: {extracted_path}")
        else:
            print(f"📁 Extracted files kept at: {extracted_path}")
        
        print(f"\n🎉 Analysis completed successfully!")
        print(f"📊 Generated reports:")
        print(f"   • taskflow_analysis.csv - Component inventory")
        print(f"   • detailed_taskflow_report.md - Comprehensive mapping analysis")
        print(f"   • taskflow_dependencies.png - Dependency visualization")
        
        return True
        
    except Exception as e:
        print(f"❌ Analysis failed: {e}")
        return False

def main():
    """Main function with command line argument support"""
    
    parser = argparse.ArgumentParser(
        description="Generalized IICS Taskflow Analyzer - Works with ANY IICS taskflow export",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python analyze_any_taskflow.py my_export.zip
  python analyze_any_taskflow.py my_export.zip --output reports/
  python analyze_any_taskflow.py my_export.zip --keep-extracted
        """
    )
    
    parser.add_argument("zip_file", help="Path to the IICS taskflow export zip file")
    parser.add_argument("-o", "--output", help="Output directory for analysis reports")
    parser.add_argument("-k", "--keep-extracted", action="store_true", 
                       help="Keep extracted files after analysis")
    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose output")
    
    args = parser.parse_args()
    
    # Validate input file
    if not os.path.exists(args.zip_file):
        print(f"❌ Error: Zip file not found: {args.zip_file}")
        sys.exit(1)
    
    if not args.zip_file.lower().endswith('.zip'):
        print(f"❌ Error: File must be a .zip file: {args.zip_file}")
        sys.exit(1)
    
    # Run analysis
    success = analyze_taskflow(
        zip_file_path=args.zip_file,
        output_dir=args.output,
        keep_extracted=args.keep_extracted
    )
    
    if not success:
        sys.exit(1)

if __name__ == "__main__":
    main()