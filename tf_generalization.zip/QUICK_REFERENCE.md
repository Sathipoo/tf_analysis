# IICS Taskflow Analyzer - Quick Reference

## 🚀 One-Minute Setup

```bash
# 1. Install dependencies
pip install pandas networkx matplotlib

# 2. Analyze any IICS export
python analyze_any_taskflow.py your_export.zip
```

## 📁 Output Files Created

| File | What It Contains |
|------|------------------|
| `detailed_taskflow_report.md` | 📊 **Complete analysis** - mappings, sources, targets, transformations |
| `taskflow_analysis.csv` | 📈 **Data export** - component inventory for Excel/BI tools |
| `taskflow_dependencies.png` | 🎨 **Visual graph** - dependency relationships diagram |

## 🎯 Common Commands

```bash
# Basic analysis
python analyze_any_taskflow.py my_export.zip

# Custom output folder
python analyze_any_taskflow.py my_export.zip --output analysis_results/

# Keep extracted files
python analyze_any_taskflow.py my_export.zip --keep-extracted

# All options
python analyze_any_taskflow.py my_export.zip -o results/ -k -v
```

## ✅ What It Analyzes

- **✅ MTT Mapping Tasks** - Source/target details, transformations
- **✅ Connections** - Database, cloud, file connections
- **✅ Data Templates** - Schema and structure definitions  
- **✅ Taskflows** - Orchestration and execution logic
- **✅ Dependencies** - Component relationships

## 🔧 Quick Troubleshooting

| Problem | Solution |
|---------|----------|
| "Module not found" | `pip install pandas networkx matplotlib` |
| "File not found" | Use full path: `python analyze_any_taskflow.py "C:\path\to\export.zip"` |
| "Invalid export" | Ensure it's an IICS export (contains .MTT.zip files) |
| Permission error | Use `--output` to specify writable directory |

## 💡 Pro Tips

- **Use dated folders**: `--output analysis_2024_12_05/`
- **Batch process**: Analyze multiple exports in sequence
- **Share markdown reports**: Most readable for stakeholders
- **Import CSV to Excel**: For business analysis and dashboards

## 📖 Need More Help?

- **[Complete Setup Guide](SETUP_AND_EXECUTION_GUIDE.md)** - Detailed instructions
- **[README](README.md)** - Full project overview
- **Command help**: `python analyze_any_taskflow.py --help`

---
⚡ **Quick Start**: `python analyze_any_taskflow.py your_export.zip` - That's it!