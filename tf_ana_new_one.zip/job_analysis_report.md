# IICS Job Analysis Report - Multi-Taskflow Export

## Job Overview

- **Job Export Name**: job-1754455542236
- **Source Organization**: ACC *TEST*
- **Total Objects**: 317
- **Total Taskflows**: 4
- **Analysis Date**: 2025-08-07 07:44:15

## Job Summary Statistics

- **Total MTT Tasks**: 151
- **Unique Connections**: 8
- **Total Data Templates**: 149

## Taskflow Overview

| Taskflow Name | Project Path | MTT Tasks | Connections | Templates |
|---|---|---|---|---|
| Tf_Soft_Delete_Records | Explore/ERP Hub/SoftDelete | 143 | 8 | 143 |
| tf_TimleyCare | Explore/OutBound_Data/TimleyCare | 3 | 8 | 3 |
| tf_TimleyCare_Delta | Explore/OutBound_Data/TimleyCare | 3 | 8 | 3 |
| tf_RECEPTION_STG_HUB | Explore/Third Party Data/Taskflows | 2 | 8 | 0 |

## Detailed Taskflow Analysis

### Taskflow: Tf_Soft_Delete_Records

**Project Path**: `Explore/ERP Hub/SoftDelete`

#### Mapping Tasks (MTT)

##### mt_ACADEMIC_CREDENTIAL_soft_delete

**Basic Information:**
- **Task Name**: mt_ACADEMIC_CREDENTIAL_soft_delete
- **Mapping Reference**: 8u9ZGsI36MjgNSsJB0AMQt
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: ACADEMIC_CREDENTIAL
  - Schema: 
  - Filter: `ACADEMIC_CREDENTIAL.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: ACADEMIC_CREDENTIAL
  - Operation: Update
- **Target 2**: tgt_ERP_HUB
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: ACADEMIC_CREDENTIAL
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: ACAD_CREDENTIALS
  - Cache Type: Cached

---

##### mt_ACADEMIC_LEVEL_soft_delete

**Basic Information:**
- **Task Name**: mt_ACADEMIC_LEVEL_soft_delete
- **Mapping Reference**: gJEQLI0QL84kKiKm1oYpc8
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: ACADEMIC_LEVEL
  - Schema: 
  - Filter: `ACADEMIC_LEVEL.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_DW_CORP
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: ACADEMIC_LEVEL
  - Operation: Update
- **Target 2**: tgt_ERP_HUB
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: ACADEMIC_LEVEL
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: ACAD_LEVELS
  - Cache Type: Cached

---

##### mt_ACADEMIC_PROGRAM_REQUIREMENT_soft_delete

**Basic Information:**
- **Task Name**: mt_ACADEMIC_PROGRAM_REQUIREMENT_soft_delete
- **Mapping Reference**: 6gD3lNBII92epIQl2umB46
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_ACADEMIC_PROGRAM_REQUIREMENT
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: ACADEMIC_PROGRAM_REQUIREMENT
  - Schema: 
  - Filter: `ACADEMIC_PROGRAM_REQUIREMENT.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_ACADEMIC_PROGRAM_REQUIREMENT_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: ACADEMIC_PROGRAM_REQUIREMENT
  - Operation: Update
- **Target 2**: tgt_ACADEMIC_PROGRAM_REQUIREMENT_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: ACADEMIC_PROGRAM_REQUIREMENT
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_acad_pgm_reqmts
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: ACAD_PROGRAM_REQMTS
  - Cache Type: Cached

---

##### mt_ACADEMIC_PROGRAM_soft_delete

**Basic Information:**
- **Task Name**: mt_ACADEMIC_PROGRAM_soft_delete
- **Mapping Reference**: do0aUpYSPU6cBXruBVQc65
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_ACADEMIC_PROGRAM
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: ACADEMIC_PROGRAM
  - Schema: 
  - Filter: `ACADEMIC_PROGRAM.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_ACADEMIC_PROGRAM_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: ACADEMIC_PROGRAM
  - Operation: Update
- **Target 2**: tgt_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: ACADEMIC_PROGRAM
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_acad_programs
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: ACAD_PROGRAMS
  - Cache Type: Cached

---

##### mt_ADDRESS_soft_delete

**Basic Information:**
- **Task Name**: mt_ADDRESS_soft_delete
- **Mapping Reference**: 7mEcGJAdsn8fbdMWMKsFSb
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_ADDRESS
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: ADDRESS
  - Schema: 
  - Filter: `ADDRESS.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_ADDRESS_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: ADDRESS
  - Operation: Update
- **Target 2**: tgt_ADDRESS_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: ADDRESS
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_address
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: ADDRESS
  - Cache Type: Cached

---

##### mt_ADMIT_STATUS_soft_delete

**Basic Information:**
- **Task Name**: mt_ADMIT_STATUS_soft_delete
- **Mapping Reference**: 04X3MkAoRgXiZrldZBkGqk
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: ADMIT_STATUS
  - Schema: 
  - Filter: `ADMIT_STATUS.IS_DELETED is null`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: ADMIT_STATUS
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: ADMIT_STATUS
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: ADMIT_STATUSES
  - Cache Type: Cached

---

##### mt_APPLICANT_soft_delete

**Basic Information:**
- **Task Name**: mt_APPLICANT_soft_delete
- **Mapping Reference**: dB86yRhrboZjpggqxqfqgh
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_APPLICANT
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: APPLICANT
  - Schema: 
  - Filter: `APPLICANT.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_APPLICANT_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: APPLICANT
  - Operation: Update
- **Target 2**: tgt_APPLICANT_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: APPLICANT
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_applicants
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: APPLICANTS
  - Cache Type: Cached

---

##### mt_APPLICATION_soft_delete

**Basic Information:**
- **Task Name**: mt_APPLICATION_soft_delete
- **Mapping Reference**: akrjuYNqWoTb8YNKJogG8x
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_APPLICATION
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: APPLICATION
  - Schema: 
  - Filter: `APPLICATION.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_APPLICATION_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: APPLICATION
  - Operation: Update
- **Target 2**: tgt_APPLICATION_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: APPLICATION
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_applications
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: APPLICATIONS
  - Cache Type: Cached

---

##### mt_AWARD_PERIOD_soft_delete

**Basic Information:**
- **Task Name**: mt_AWARD_PERIOD_soft_delete
- **Mapping Reference**: 6xN575su8PhhntP6hSPoQJ
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_AWARD_PERIOD
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: AWARD_PERIOD
  - Schema: 
  - Filter: `AWARD_PERIOD.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_AWARD_PERIOD_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: AWARD_PERIOD
  - Operation: Update
- **Target 2**: tgt_AWARD_PERIOD_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: AWARD_PERIOD
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_award_periods
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: AWARD_PERIODS
  - Cache Type: Cached

---

##### mt_AWARD_soft_delete

**Basic Information:**
- **Task Name**: mt_AWARD_soft_delete
- **Mapping Reference**: 4JesH6ZjyKJfU4PQgpA2az
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: AWARD
  - Schema: 
  - Filter: `AWARD.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: AWARD
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: AWARD
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: AWARDS
  - Cache Type: Cached

---

##### mt_BUILDING_soft_delete

**Basic Information:**
- **Task Name**: mt_BUILDING_soft_delete
- **Mapping Reference**: 2fKXOrfm0yce9vwzWg35UC
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_BUILDING
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: BUILDING
  - Schema: 
  - Filter: `BUILDING.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_BUILDING_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: BUILDING
  - Operation: Update
- **Target 2**: tgt_BUILDING_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: BUILDING
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_buildings
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: BUILDINGS
  - Cache Type: Cached

---

##### mt_CALENDAR_SCHEDULE_soft_delete

**Basic Information:**
- **Task Name**: mt_CALENDAR_SCHEDULE_soft_delete
- **Mapping Reference**: leMz5yQGXuah6WwlgrDUwT
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_calendar_schedule_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: CALENDAR_SCHEDULE
  - Schema: 

**Targets:**
- **Target 1**: tgt_calendar_schedule_ERP_Hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: CALENDAR_SCHEDULE
  - Operation: Update
- **Target 2**: tgt_calendar_schedule_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: CALENDAR_SCHEDULE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_colleague_calendar_schedule
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: DUMMY_lkp_colleague_calendar_schedule
  - Cache Type: Cached

---

##### mt_CCDS_soft_delete

**Basic Information:**
- **Task Name**: mt_CCDS_soft_delete
- **Mapping Reference**: 6oJtFJp1WYLknUsZVOWJ26
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_CCDS
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: CCDS
  - Schema: 
  - Filter: `CCDS.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_CCDS_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: CCDS
  - Operation: Update
- **Target 2**: tgt_CCDS_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: CCDS
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_ccds
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: CCDS
  - Cache Type: Cached

---

##### mt_CORP_FOUND_soft_delete

**Basic Information:**
- **Task Name**: mt_CORP_FOUND_soft_delete
- **Mapping Reference**: aq2YYr2s2owjYtW08dBxYU
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_CORP_FOUNDS
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: CORP_FOUND
  - Schema: 
  - Filter: `CORP_FOUND.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_DW_CORP
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: CORP_FOUND
  - Operation: Update
- **Target 2**: tgt_ERP_HUB
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: CORP_FOUND
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_corp_found
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: CORP_FOUNDS
  - Cache Type: Cached

---

##### mt_COUNTRY_soft_delete

**Basic Information:**
- **Task Name**: mt_COUNTRY_soft_delete
- **Mapping Reference**: 4kfcJCzf9VAgaptFpsCJkh
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_COUNTRY
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COUNTRY
  - Schema: 
  - Filter: `COUNTRY.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_COUNTRY_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: COUNTRY
  - Operation: Update
- **Target 2**: tgt_COUNTRY_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COUNTRY
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_countries
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: COUNTRIES
  - Cache Type: Cached

---

##### mt_COURSE_CONTACT_soft_delete

**Basic Information:**
- **Task Name**: mt_COURSE_CONTACT_soft_delete
- **Mapping Reference**: 0ebIueJWnwDju6LuTA8QqD
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_CONTACT
  - Schema: 
  - Filter: `COURSE_CONTACT.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_CONTACT
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: COURSE_CONTACT
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: COURSES_COURSE_CONTACT
  - Cache Type: Cached

---

##### mt_COURSE_EQUATE_CODE_COURSE_soft_delete

**Basic Information:**
- **Task Name**: mt_COURSE_EQUATE_CODE_COURSE_soft_delete
- **Mapping Reference**: h22uUS3DJAKfF3cN8tIhey
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_EQUATE_CODE_COURSE
  - Schema: 
  - Filter: `COURSE_EQUATE_CODE_COURSE.IS_DELETED is null`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_EQUATE_CODE_COURSE
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: COURSE_EQUATE_CODE_COURSE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: COURSE_EQUATE_CODES_CEC_COURSES
  - Cache Type: Cached

---

##### mt_COURSE_EQUATE_CODE_soft_delete

**Basic Information:**
- **Task Name**: mt_COURSE_EQUATE_CODE_soft_delete
- **Mapping Reference**: 4wXAfPCUzkyfb482Tjt8ik
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_EQUATE_CODE
  - Schema: 
  - Filter: `COURSE_EQUATE_CODE.IS_DELETED is null`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_EQUATE_CODE
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: COURSE_EQUATE_CODE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: COURSE_EQUATE_CODES
  - Cache Type: Cached

---

##### mt_COURSE_EQUIVALENCE_soft_delete

**Basic Information:**
- **Task Name**: mt_COURSE_EQUIVALENCE_soft_delete
- **Mapping Reference**: aTmujPPQBHtgugdWDZYne8
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_COURSE_EQUIVALENCE
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_EQUIVALENCE
  - Schema: 
  - Filter: `COURSE_EQUIVALENCE.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_COURSE_EQUIVALENCE_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: COURSE_EQUIVALENCE
  - Operation: Update
- **Target 2**: tgt_COURSE_EQUIVALENCE_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_EQUIVALENCE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_course_equivs
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: COURSE_EQUIVS
  - Cache Type: Cached

---

##### mt_COURSE_SECTION_CONTACT_soft_delete

**Basic Information:**
- **Task Name**: mt_COURSE_SECTION_CONTACT_soft_delete
- **Mapping Reference**: 0KCLoclhHmCeaIzgDgoRQ9
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_COURSE_SECTION_CONTACT
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_SECTION_CONTACT
  - Schema: 
  - Filter: `COURSE_SECTION_CONTACT.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_COURSE_SECTION_CONTACT_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: COURSE_SECTION_CONTACT
  - Operation: Update
- **Target 2**: tgt_COURSE_SECTION_CONTACT_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_SECTION_CONTACT
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_course_sec_contact
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: COURSE_SECTIONS_SEC_CONTACT
  - Cache Type: Cached

---

##### mt_COURSE_SECTION_COREQ_SECTION_soft_delete

**Basic Information:**
- **Task Name**: mt_COURSE_SECTION_COREQ_SECTION_soft_delete
- **Mapping Reference**: 8h1CgWbbLOhjrEvyG9cKWN
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_SECTION_COREQ_SECTION
  - Schema: 
  - Filter: `COURSE_SECTION_COREQ_SECTION.IS_DELETED is null`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_SECTION_COREQ_SECTION
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: COURSE_SECTION_COREQ_SECTION
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: COURSE_SECTIONS_SEC_COREQ_SECS
  - Cache Type: Cached

---

##### mt_COURSE_SECTION_COURSE_TYPE_soft_delete

**Basic Information:**
- **Task Name**: mt_COURSE_SECTION_COURSE_TYPE_soft_delete
- **Mapping Reference**: 6ZLepQH72EMdAaUlu0sPkT
- **Operation Types**: Update

**Sources:**
- **Source 1**: COURSE_SECTION_COURSE_TYPE
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_SECTION_COURSE_TYPE
  - Schema: 
  - Filter: `COURSE_SECTION_COURSE_TYPE.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_COURSE_SECTION_COURSE_TYPE_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: COURSE_SECTION_COURSE_TYPE
  - Operation: Update
- **Target 2**: tgt_COURSE_SECTION_COURSE_TYPE_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_SECTION_COURSE_TYPE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_COURSE_SECTIONS_SEC_COURSE_TYPES
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: COURSE_SECTIONS_SEC_COURSE_TYPES
  - Cache Type: Cached

---

##### mt_COURSE_SECTION_FACULTY_soft_delete

**Basic Information:**
- **Task Name**: mt_COURSE_SECTION_FACULTY_soft_delete
- **Mapping Reference**: 09trpdGEcrobwEbSuTWA0L
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_COURSE_SECTION_FACULTY
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_SECTION_FACULTY
  - Schema: 
  - Filter: `COURSE_SECTION_FACULTY.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_COURSE_SECTION_FACULTY_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: COURSE_SECTION_FACULTY
  - Operation: Update
- **Target 2**: tgt_COURSE_SECTION_FACULTY_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_SECTION_FACULTY
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_course_sec_flty
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: COURSE_SEC_FACULTY
  - Cache Type: Cached

---

##### mt_COURSE_SECTION_LOCAL_GOVT_CODE_soft_delete

**Basic Information:**
- **Task Name**: mt_COURSE_SECTION_LOCAL_GOVT_CODE_soft_delete
- **Mapping Reference**: 5Ed4aLYBSXNgZdoms4WIQ2
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_COURSE_SECTION_LOCAL_GOVT_CODE
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_SECTION_LOCAL_GOVT_CODE
  - Schema: 
  - Filter: `COURSE_SECTION_LOCAL_GOVT_CODE.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_COURSE_SECTION_LOCAL_GOVT_CODE_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: COURSE_SECTION_LOCAL_GOVT_CODE
  - Operation: Update
- **Target 2**: tgt_COURSE_SECTION_LOCAL_GOVT_CODE_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_SECTION_LOCAL_GOVT_CODE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_course_sec_lcl_gvt
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: COURSE_SECTIONS_SEC_LOCAL_GOVT_CODES
  - Cache Type: Cached

---

##### mt_COURSE_SECTION_MEETING_soft_delete

**Basic Information:**
- **Task Name**: mt_COURSE_SECTION_MEETING_soft_delete
- **Mapping Reference**: jjbSIAiWiqBbzmiFyXN4yo
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_COURSE_SECTION_MEETING
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_SECTION_MEETING
  - Schema: 
  - Filter: `COURSE_SECTION_MEETING.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_COURSE_SECTION_MEETING_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: COURSE_SECTION_MEETING
  - Operation: Update
- **Target 2**: tgt_COURSE_SECTION_MEETING_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_SECTION_MEETING
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_course_sec_meeting
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: COURSE_SEC_MEETING
  - Cache Type: Cached

---

##### mt_COURSE_SECTION_soft_delete

**Basic Information:**
- **Task Name**: mt_COURSE_SECTION_soft_delete
- **Mapping Reference**: 4MoHIxJIDAGfJHLyyyUz0C
- **Operation Types**: Update

**Targets:**
- **Target 1**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: COURSE_SECTION
  - Operation: Update
- **Target 2**: tgt_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_SECTION
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: COURSE_SECTIONS
  - Cache Type: Cached

---

##### mt_COURSE_soft_delete

**Basic Information:**
- **Task Name**: mt_COURSE_soft_delete
- **Mapping Reference**: ayS28zhCFEVj70bM15hXmV
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_COURSE
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE
  - Schema: 
  - Filter: `COURSE.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_COURSE_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: COURSE
  - Operation: Update
- **Target 2**: tgt_COURSE_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_courses
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: COURSES
  - Cache Type: Cached

---

##### mt_COURSE_TITLE_INFO_soft_delete

**Basic Information:**
- **Task Name**: mt_COURSE_TITLE_INFO_soft_delete
- **Mapping Reference**: lgLohPNAfCpbZw90Ztvmit
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_TITLE_INFO
  - Schema: 
  - Filter: `COURSE_TITLE_INFO.IS_DELETED is null`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_TITLE_INFO
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: COURSE_TITLE_INFO
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: A70_COURSES_A70_CRSE_TITLE_INFO
  - Cache Type: Cached

---

##### mt_COURSE_TYPE_soft_delete

**Basic Information:**
- **Task Name**: mt_COURSE_TYPE_soft_delete
- **Mapping Reference**: 5KIOY9eW1AZdKUKgTazZUl
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_TYPE
  - Schema: 
  - Filter: `COURSE_TYPE.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_TYPE
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: COURSE_TYPE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: COURSES_CRS_COURSE_TYPES
  - Cache Type: Cached

---

##### mt_CREDIT_TYPE_soft_delete

**Basic Information:**
- **Task Name**: mt_CREDIT_TYPE_soft_delete
- **Mapping Reference**: 7RfZsqAVeoRiZApUIqm9A0
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_CREDIT_TYPE
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: CREDIT_TYPE
  - Schema: 
  - Filter: `CREDIT_TYPE.IS_DELETED  IS NULL`

**Targets:**
- **Target 1**: tgt_DW_CORP
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: CREDIT_TYPE
  - Operation: Update
- **Target 2**: tgt_ERP_HUB
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: CREDIT_TYPE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_cred_types
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: CRED_TYPES
  - Cache Type: Cached

---

##### mt_CS_ACYR_soft_delete

**Basic Information:**
- **Task Name**: mt_CS_ACYR_soft_delete
- **Mapping Reference**: 7lGcC14Qt2pdIUJR4cDv6Q
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_CS_ACYR
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: CS_ACYR
  - Schema: 
  - Filter: `CS_ACYR.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_CS_ACYR_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: CS_ACYR
  - Operation: Update
- **Target 2**: tgt_CS_ACYR_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: CS_ACYR
  - Operation: Update

---

##### mt_DEAN_DEPARTMENT_DETAIL_soft_delete

**Basic Information:**
- **Task Name**: mt_DEAN_DEPARTMENT_DETAIL_soft_delete
- **Mapping Reference**: 4oeGs22vp9OkEu3rziTjox
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DEAN_DEPARTMENT_DETAIL
  - Schema: 

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DEAN_DEPARTMENT_DETAIL
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: DEAN_DEPARTMENT_DETAIL
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: A70_DEANS_A70_DEAN_SUB_AUTH
  - Cache Type: Cached

---

##### mt_DEGREE_soft_delete

**Basic Information:**
- **Task Name**: mt_DEGREE_soft_delete
- **Mapping Reference**: 8LlISCuqhQddpGuaSYrEMU
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DEGREE
  - Schema: 

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DEGREE
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: DEGREE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: DEGREES_
  - Cache Type: Cached

---

##### mt_DEPARTMENT_CHAIR_soft_delete

**Basic Information:**
- **Task Name**: mt_DEPARTMENT_CHAIR_soft_delete
- **Mapping Reference**: gRU10jSgtAzetVe7Rh2jcF
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DEPARTMENT_CHAIR
  - Schema: 
  - Filter: `DEPARTMENT_CHAIR.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DEPARTMENT_CHAIR
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: DEPARTMENT_CHAIR
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: A70_DEPT_CHAIRS
  - Cache Type: Cached

---

##### mt_DEPARTMENT_soft_delete

**Basic Information:**
- **Task Name**: mt_DEPARTMENT_soft_delete
- **Mapping Reference**: 3794mxxFeSjlKkDY36fgGQ
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_DEPARTMENT
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DEPARTMENT
  - Schema: 
  - Filter: `DEPARTMENT.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_DEPARTMENT_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: DEPARTMENT
  - Operation: Update
- **Target 2**: tgt_DEPARTMENT_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DEPARTMENT
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_depts
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: DEPTS
  - Cache Type: Cached

---

##### mt_DISABILITY_soft_delete

**Basic Information:**
- **Task Name**: mt_DISABILITY_soft_delete
- **Mapping Reference**: 2UER7odNIIblCkNiVyCFWu
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DISABILITY
  - Schema: 
  - Filter: `DISABILITY.IS_DELETED is null`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DISABILITY
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: DISABILITY
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: DISABILITY
  - Cache Type: Cached

---

##### mt_DIVISION_soft_delete

**Basic Information:**
- **Task Name**: mt_DIVISION_soft_delete
- **Mapping Reference**: lCZYfIkjpcOiDHY9MospMN
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_DIVISION
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DIVISION
  - Schema: 
  - Filter: `DIVISION.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_DIVISION_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: DIVISION
  - Operation: Update
- **Target 2**: tgt_DIVISION_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DIVISION
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_divisions
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: DIVISIONS
  - Cache Type: Cached

---

##### mt_DREGISTRATION_EXEMPT_REST_soft_delete

**Basic Information:**
- **Task Name**: mt_DREGISTRATION_EXEMPT_REST_soft_delete
- **Mapping Reference**: 4gwyzyoEI26cMMSuszT4YF
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_DREGISTRATION_EXEMPT_REST_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/DREGISTRATION_EXEMPT_REST
  - Schema: dbo
  - Filter: `DREGISTRATION_EXEMPT_REST.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_DREGISTRATION_EXEMPT_REST_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: erp/DREGISTRATION_EXEMPT_REST
  - Operation: Upsert
- **Target 2**: tgt_DREGISTRATION_EXEMPT_REST_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/DREGISTRATION_EXEMPT_REST
  - Operation: Upsert

**Lookups:**
- **Lookup 1**: lkp_stg_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: data/A70_DRGN_EXEMPT_A70_DRGN_RESTS
  - Cache Type: Cached

---

##### mt_DREGISTRATION_EXEMPT_soft_delete

**Basic Information:**
- **Task Name**: mt_DREGISTRATION_EXEMPT_soft_delete
- **Mapping Reference**: ecE2JBAvkmndWm5c3awnKX
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_DREGISTRATION_EXEMPT_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/DREGISTRATION_EXEMPT
  - Schema: dbo
  - Filter: `DREGISTRATION_EXEMPT.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_DREGISTRATION_EXEMPT_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: erp/DREGISTRATION_EXEMPT
  - Operation: Upsert
- **Target 2**: tgt_DREGISTRATION_EXEMPT_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/DREGISTRATION_EXEMPT
  - Operation: Upsert

**Lookups:**
- **Lookup 1**: lkp_stg_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: data/A70_DRGN_EXEMPT
  - Cache Type: Cached

---

##### mt_DREGISTRATION_EXEMPT_TOUCHNET_soft_delete

**Basic Information:**
- **Task Name**: mt_DREGISTRATION_EXEMPT_TOUCHNET_soft_delete
- **Mapping Reference**: l7n3LAhtGEuiPeA0vGRT0q
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_DREGISTRATION_EXEMPT_TOUCHNET_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/DREGISTRATION_EXEMPT_TOUCHNET
  - Schema: dbo
  - Filter: `DREGISTRATION_EXEMPT_TOUCHNET.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_DREGISTRATION_EXEMPT_TOUCHNET_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: erp/DREGISTRATION_EXEMPT_TOUCHNET
  - Operation: Upsert
- **Target 2**: tgt_DREGISTRATION_EXEMPT_TOUCHNET_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/DREGISTRATION_EXEMPT_TOUCHNET
  - Operation: Upsert

**Lookups:**
- **Lookup 1**: lkp_stg_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: data/A70_DRGN_EXEMPT_A70_DRGN_TOUCHNET
  - Cache Type: Cached

---

##### mt_DREGISTRATION_EXEMPT_VETERAN_soft_delete

**Basic Information:**
- **Task Name**: mt_DREGISTRATION_EXEMPT_VETERAN_soft_delete
- **Mapping Reference**: 6yi6uDryXFPdvzrB14jfEP
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/DREGISTRATION_EXEMPT_VETERAN
  - Schema: dbo
  - Filter: `dbo.DREGISTRATION_EXEMPT_VETERAN.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_DW_CORP
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: erp/DREGISTRATION_EXEMPT_VETERAN
  - Operation: Update
- **Target 2**: tgt_ERP_HUB
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/DREGISTRATION_EXEMPT_VETERAN
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: data/A70_DRGN_EXEMPT_A70_DRGN_VETERAN
  - Cache Type: Cached

---

##### mt_DREGISTRATION_STUDENT_soft_delete

**Basic Information:**
- **Task Name**: mt_DREGISTRATION_STUDENT_soft_delete
- **Mapping Reference**: 70yOqPFHsqAbNxwbE5QniV
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DREGISTRATION_STUDENT
  - Schema: 
  - Filter: `DREGISTRATION_STUDENT.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DREGISTRATION_STUDENT
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: DREGISTRATION_STUDENT
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: A70_DRGN_STUDENT
  - Cache Type: Cached

---

##### mt_EDI_TRAN_COURSE_soft_delete

**Basic Information:**
- **Task Name**: mt_EDI_TRAN_COURSE_soft_delete
- **Mapping Reference**: 7k4aHdoJ1itfNZ5NYEsly1
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EDI_TRAN_COURSE
  - Schema: 
  - Filter: `EDI_TRAN_COURSE.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_DW_CORP
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: EDI_TRAN_COURSE
  - Operation: Update
- **Target 2**: tgt_ERP_HUB
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EDI_TRAN_COURSE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: EDI_TRAN_COURSES
  - Cache Type: Cached

---

##### mt_EXTERNAL_TRANSCRIPTS_soft_delete

**Basic Information:**
- **Task Name**: mt_EXTERNAL_TRANSCRIPTS_soft_delete
- **Mapping Reference**: 0fJ7LgEwgiBetNNXr7yfIB
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EXTERNAL_TRANSCRIPTS
  - Schema: 
  - Filter: `EXTERNAL_TRANSCRIPTS.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_DW_CORP1
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: EXTERNAL_TRANSCRIPTS
  - Operation: Update
- **Target 2**: tgt_ERP_HUB1
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EXTERNAL_TRANSCRIPTS
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: EXTERNAL_TRANSCRIPTS
  - Cache Type: Cached

---

##### mt_FINANCIAL_AID_AWARD_HISTORY_soft_delete

**Basic Information:**
- **Task Name**: mt_FINANCIAL_AID_AWARD_HISTORY_soft_delete
- **Mapping Reference**: 1YyB4V1QCvsdr7iuktyVeH
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_FINANCIAL_AID_AWARD_HISTORY
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_AWARD_HISTORY
  - Schema: 
  - Filter: `FINANCIAL_AID_AWARD_HISTORY.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_FINANCIAL_AID_AWARD_HISTORY_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: FINANCIAL_AID_AWARD_HISTORY
  - Operation: Update
- **Target 2**: tgt_FINANCIAL_AID_AWARD_HISTORY_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_AWARD_HISTORY
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_fa_award_hist
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: FA_AWARD_HISTORY
  - Cache Type: Cached

---

##### mt_FINANCIAL_AID_CATEGORY_AMOUNT_soft_delete

**Basic Information:**
- **Task Name**: mt_FINANCIAL_AID_CATEGORY_AMOUNT_soft_delete
- **Mapping Reference**: 8XkT2bbeDe0deiH6KoHbmN
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_FINANCIAL_AID_CATEGORY_AMOUNT
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_CATEGORY_AMOUNT
  - Schema: 
  - Filter: `FINANCIAL_AID_CATEGORY_AMOUNT.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_FINANCIAL_AID_CATEGORY_AMOUNT_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: FINANCIAL_AID_CATEGORY_AMOUNT
  - Operation: Update
- **Target 2**: tgt_FINANCIAL_AID_CATEGORY_AMOUNT_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_CATEGORY_AMOUNT
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_fa_category_amts
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: FA_CATEGORY_AMOUNTS
  - Cache Type: Cached

---

##### mt_FINANCIAL_AID_COMMENT_CODE_soft_delete

**Basic Information:**
- **Task Name**: mt_FINANCIAL_AID_COMMENT_CODE_soft_delete
- **Mapping Reference**: k8GHrDeWd2Scma5eI6YDcA
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_FINANCIAL_AID_COMMENT_CODE
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_COMMENT_CODE
  - Schema: 
  - Filter: `FINANCIAL_AID_COMMENT_CODE.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_FINANCIAL_AID_COMMENT_CODE_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: FINANCIAL_AID_COMMENT_CODE
  - Operation: Update
- **Target 2**: tgt_FINANCIAL_AID_COMMENT_CODE_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_COMMENT_CODE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_fa_comments_codes
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: FA_COMMENT_CODES
  - Cache Type: Cached

---

##### mt_FINANCIAL_AID_COMMENT_soft_delete

**Basic Information:**
- **Task Name**: mt_FINANCIAL_AID_COMMENT_soft_delete
- **Mapping Reference**: 3Ca0utJWGWee8FUzgPjAMw
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_FINANCIAL_AID_COMMENT
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_COMMENT
  - Schema: 
  - Filter: `FINANCIAL_AID_COMMENT.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_FINANCIAL_AID_COMMENT_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: FINANCIAL_AID_COMMENT
  - Operation: Update
- **Target 2**: tgt_FINANCIAL_AID_COMMENT_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_COMMENT
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_fa_comments
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: FA_COMMENTS
  - Cache Type: Cached

---

##### mt_FINANCIAL_AID_DL_AWARD_CONDITION_soft_delete

**Basic Information:**
- **Task Name**: mt_FINANCIAL_AID_DL_AWARD_CONDITION_soft_delete
- **Mapping Reference**: fUlwtCcXeshjGoKx9DAoSM
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_FINANCIAL_AID_DL_AWARD_CONDITION
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_DL_AWARD_CONDITION
  - Schema: 
  - Filter: `FINANCIAL_AID_DL_AWARD_CONDITION.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_FINANCIAL_AID_DL_AWARD_CONDITION_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: FINANCIAL_AID_DL_AWARD_CONDITION
  - Operation: Update
- **Target 2**: tgt_FINANCIAL_AID_DL_AWARD_CONDITION_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_DL_AWARD_CONDITION
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_fa_dl_award_conditions
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: FA_DL_AWARD_CONDITIONS
  - Cache Type: Cached

---

##### mt_FINANCIAL_AID_FISAP_EAAD_soft_delete

**Basic Information:**
- **Task Name**: mt_FINANCIAL_AID_FISAP_EAAD_soft_delete
- **Mapping Reference**: cK8vqElLa82lxM6FJrzZEo
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_FISAP_EAAD
  - Schema: 
  - Filter: `FINANCIAL_AID_FISAP_EAAD.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_FISAP_EAAD
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: FINANCIAL_AID_FISAP_EAAD
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: FA_FISAP_EAAD
  - Cache Type: Cached

---

##### mt_FINANCIAL_AID_FISAP_PRDD_soft_delete

**Basic Information:**
- **Task Name**: mt_FINANCIAL_AID_FISAP_PRDD_soft_delete
- **Mapping Reference**: hJo8V7DgCQ9exv9RpUVBqF
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_FISAP_PRDD
  - Schema: 
  - Filter: `FINANCIAL_AID_FISAP_PRDD.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_FISAP_PRDD
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: FINANCIAL_AID_FISAP_PRDD
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: FA_FISAP_PRDD
  - Cache Type: Cached

---

##### mt_FINANCIAL_AID_INTERVIEW_CODE_soft_delete

**Basic Information:**
- **Task Name**: mt_FINANCIAL_AID_INTERVIEW_CODE_soft_delete
- **Mapping Reference**: 6D28gWYzXcYinc5r45Ngm7
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_INTERVIEW_CODE
  - Schema: 
  - Filter: `FINANCIAL_AID_INTERVIEW_CODE.IS_DELETED is null`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_INTERVIEW_CODE
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: FINANCIAL_AID_INTERVIEW_CODE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: FA_INTERVIEW_CODES
  - Cache Type: Cached

---

##### mt_FINANCIAL_AID_INTERVIEW_soft_delete

**Basic Information:**
- **Task Name**: mt_FINANCIAL_AID_INTERVIEW_soft_delete
- **Mapping Reference**: kJTS59fmtiehVDTrQoIa2d
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_INTERVIEW
  - Schema: 
  - Filter: `FINANCIAL_AID_INTERVIEW.IS_DELETED is null`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_INTERVIEW
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: FINANCIAL_AID_INTERVIEW
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: FA_INTERVIEW
  - Cache Type: Cached

---

##### mt_FINANCIAL_AID_LOCATION_soft_delete

**Basic Information:**
- **Task Name**: mt_FINANCIAL_AID_LOCATION_soft_delete
- **Mapping Reference**: 5DCLxtGCjubedyZ41Hkau7
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_LOCATION
  - Schema: 
  - Filter: `FINANCIAL_AID_LOCATION.IS_DELETED is null`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_LOCATION
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: FINANCIAL_AID_LOCATION
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: FA_LOCATIONS
  - Cache Type: Cached

---

##### mt_FINANCIAL_AID_OFFICE_soft_delete

**Basic Information:**
- **Task Name**: mt_FINANCIAL_AID_OFFICE_soft_delete
- **Mapping Reference**: 2ZjKWwFxrwOhEliKE2Mfg0
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_OFFICE
  - Schema: 
  - Filter: `FINANCIAL_AID_OFFICE.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_OFFICE
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: FINANCIAL_AID_OFFICE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: FA_OFFICES
  - Cache Type: Cached

---

##### mt_FINANCIAL_AID_OUTSIDE_AWARD_soft_delete

**Basic Information:**
- **Task Name**: mt_FINANCIAL_AID_OUTSIDE_AWARD_soft_delete
- **Mapping Reference**: 2hslordLTupfLeZgBjdaQp
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_OUTSIDE_AWARD
  - Schema: 
  - Filter: `FINANCIAL_AID_OUTSIDE_AWARD.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_OUTSIDE_AWARD
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: FINANCIAL_AID_OUTSIDE_AWARD
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: FA_OUTSIDE_AWARDS
  - Cache Type: Cached

---

##### mt_FINANCIAL_AID_REQUIRED_CHILD_soft_delete

**Basic Information:**
- **Task Name**: mt_FINANCIAL_AID_REQUIRED_CHILD_soft_delete
- **Mapping Reference**: jjciPfeSQmSk2VsX69sVow
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_REQUIRED_CHILD
  - Schema: 
  - Filter: `FINANCIAL_AID_REQUIRED_CHILD.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_REQUIRED_CHILD
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: FINANCIAL_AID_REQUIRED_CHILD
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: FA_REQUIRED_FA_REQ
  - Cache Type: Cached

---

##### mt_FINANCIAL_AID_REQUIRED_soft_delete

**Basic Information:**
- **Task Name**: mt_FINANCIAL_AID_REQUIRED_soft_delete
- **Mapping Reference**: 168NUTfbKoolrLjMj9qd2x
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_REQUIRED
  - Schema: 
  - Filter: `FINANCIAL_AID_REQUIRED.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_REQUIRED
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: FINANCIAL_AID_REQUIRED
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: FA_REQUIRED
  - Cache Type: Cached

---

##### mt_FINANCIAL_AID_SAP_RESULT_soft_delete

**Basic Information:**
- **Task Name**: mt_FINANCIAL_AID_SAP_RESULT_soft_delete
- **Mapping Reference**: 5pW13KtzrAib2KfsPSx6g1
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_SAP_RESULT
  - Schema: 
  - Filter: `FINANCIAL_AID_SAP_RESULT.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_SAP_RESULT
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: FINANCIAL_AID_SAP_RESULT
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: FIN_AID_FA_SAP_RESULTS_ID
  - Cache Type: Cached

---

##### mt_FINANCIAL_AID_SAP_STATUS_INFO_soft_delete

**Basic Information:**
- **Task Name**: mt_FINANCIAL_AID_SAP_STATUS_INFO_soft_delete
- **Mapping Reference**: dF6oWdO1YuBhLiCvmraVC0
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_FINANCIAL_AID_SAP_STATUS_INFO
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_SAP_STATUS_INFO
  - Schema: 
  - Filter: `FINANCIAL_AID_SAP_STATUS_INFO.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_FINANCIAL_AID_SAP_STATUS_INFO_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: FINANCIAL_AID_SAP_STATUS_INFO
  - Operation: Update
- **Target 2**: tgt_FINANCIAL_AID_SAP_STATUS_INFO_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_SAP_STATUS_INFO
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_fa_sap_status_info
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: FA_SAP_STATUS_INFO
  - Cache Type: Cached

---

##### mt_FINANCIAL_AID_SCP_soft_delete

**Basic Information:**
- **Task Name**: mt_FINANCIAL_AID_SCP_soft_delete
- **Mapping Reference**: 66F7B6KwhkClmPxb85sFAr
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_FINANCIAL_AID_SCP
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_SCP
  - Schema: 
  - Filter: `FINANCIAL_AID_SCP.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_FINANCIAL_AID_SCP_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: FINANCIAL_AID_SCP
  - Operation: Update
- **Target 2**: tgt_FINANCIAL_AID_SCP_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_SCP
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_fa_scp
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: FA_SCP
  - Cache Type: Cached

---

##### mt_FINANCIAL_AID_soft_delete

**Basic Information:**
- **Task Name**: mt_FINANCIAL_AID_soft_delete
- **Mapping Reference**: 5jwFY1PgLmQiDpi7oRmFco
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_FINANCIAL_AID
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID
  - Schema: 
  - Filter: `FINANCIAL_AID.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_FINANCIAL_AID_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: FINANCIAL_AID
  - Operation: Update
- **Target 2**: tgt_FINANCIAL_AID_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_fin_aid
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: FIN_AID
  - Cache Type: Cached

---

##### mt_FINANCIAL_AID_TRANSMITTAL_soft_delete

**Basic Information:**
- **Task Name**: mt_FINANCIAL_AID_TRANSMITTAL_soft_delete
- **Mapping Reference**: 8rXqI3fRFqjlFKYBk9vtCY
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_FINANCIAL_AID_TRANSMITTAL
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_TRANSMITTAL
  - Schema: 
  - Filter: `FINANCIAL_AID_TRANSMITTAL.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_FINANCIAL_AID_TRANSMITTAL_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: FINANCIAL_AID_TRANSMITTAL
  - Operation: Update
- **Target 2**: tgt_FINANCIAL_AID_TRANSMITTAL_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FINANCIAL_AID_TRANSMITTAL
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_fa_transmittals
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: FA_TRANSMITTALS
  - Cache Type: Cached

---

##### mt_FOREIGN_PERSON_soft_delete

**Basic Information:**
- **Task Name**: mt_FOREIGN_PERSON_soft_delete
- **Mapping Reference**: 7rN4NkwCiPWc494LJkaMKP
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_FOREIGN_PERSON
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FOREIGN_PERSON
  - Schema: 
  - Filter: `FOREIGN_PERSON.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_FOREIGN_PERSON_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: FOREIGN_PERSON
  - Operation: Update
- **Target 2**: tgt_FOREIGN_PERSON_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: FOREIGN_PERSON
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_foreign_person
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: FOREIGN_PERSON
  - Cache Type: Cached

---

##### mt_GRADE_soft_delete

**Basic Information:**
- **Task Name**: mt_GRADE_soft_delete
- **Mapping Reference**: 3dqHI0raIy5fAjmVO8WxC8
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_GRADE
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: GRADE
  - Schema: 
  - Filter: `GRADE.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_GRADE_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: GRADE
  - Operation: Update
- **Target 2**: tgt_GRADE_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: GRADE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_grades
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: GRADES
  - Cache Type: Cached

---

##### mt_GRADUATE_soft_delete

**Basic Information:**
- **Task Name**: mt_GRADUATE_soft_delete
- **Mapping Reference**: gcJVXtHfUSegk5Fi0tjSkj
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_GRADUATE_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: GRADUATE
  - Schema: 

**Targets:**
- **Target 1**: tgt_GRADUATE_ERP_Hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: GRADUATE
  - Operation: Update
- **Target 2**: tgt_GRADUATE_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: GRADUATE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: GRADUATES
  - Cache Type: Cached

---

##### mt_HR_PERSON_INSTITUTIONAL_STATUS_soft_delete

**Basic Information:**
- **Task Name**: mt_HR_PERSON_INSTITUTIONAL_STATUS_soft_delete
- **Mapping Reference**: 5eFIgOylWK6h4MPXqJdwuT
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_HR_PERSON_INSTITUTIONAL_STATUS
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: HR_PERSON_INSTITUTIONAL_STATUS
  - Schema: 
  - Filter: `HR_PERSON_INSTITUTIONAL_STATUS.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_HR_PERSON_INSTITUTIONAL_STATUS_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: HR_PERSON_INSTITUTIONAL_STATUS
  - Operation: Update
- **Target 2**: tgt_HR_PERSON_INSTITUTIONAL_STATUS_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: HR_PERSON_INSTITUTIONAL_STATUS
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_perstat
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: PERSTAT
  - Cache Type: Cached

---

##### mt_HR_PERSON_soft_delete

**Basic Information:**
- **Task Name**: mt_HR_PERSON_soft_delete
- **Mapping Reference**: 4mLd5PUpg8HbC4vDhsNRy9
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_HR_PERSON
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: HR_PERSON
  - Schema: 
  - Filter: `HR_PERSON.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_HR_PERSON_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: HR_PERSON
  - Operation: Update
- **Target 2**: tgt_HR_PERSON_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: HR_PERSON
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_hrper
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: HRPER
  - Cache Type: Cached

---

##### mt_HS_STUDENT_soft_delete

**Basic Information:**
- **Task Name**: mt_HS_STUDENT_soft_delete
- **Mapping Reference**: 2AYQ8Rng46SklH06XKRZUq
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_HS_STUDENT_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/HS_STUDENT
  - Schema: dbo
  - Filter: `"HS_STUDENT"."IS_DELETED" is null`

**Targets:**
- **Target 1**: tgt_HS_STUDENT_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: erp/HS_STUDENT
  - Operation: Upsert
- **Target 2**: tgt_HS_STUDENT_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/HS_STUDENT
  - Operation: Upsert

**Lookups:**
- **Lookup 1**: lkp_stg_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: data/A70_HS_STUDENT
  - Cache Type: Cached

---

##### mt_INSTITUTION_ATTENDED_ACAD_CREDENTIAL_soft_delete

**Basic Information:**
- **Task Name**: mt_INSTITUTION_ATTENDED_ACAD_CREDENTIAL_soft_delete
- **Mapping Reference**: 2dClxFDAHrbjfZ4JCsCFW9
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: INSTITUTION_ATTENDED_ACAD_CREDENTIAL
  - Schema: 
  - Filter: `INSTITUTION_ATTENDED_ACAD_CREDENTIAL.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: INSTITUTION_ATTENDED_ACAD_CREDENTIAL
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: INSTITUTION_ATTENDED_ACAD_CREDENTIAL
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: INSTITUTIONS_ATTEND_INSTA_ACAD_CREDENTIALS
  - Cache Type: Cached

---

##### mt_INSTITUTION_ATTENDED_DATE_soft_delete

**Basic Information:**
- **Task Name**: mt_INSTITUTION_ATTENDED_DATE_soft_delete
- **Mapping Reference**: 7GDKFAjlEmziTmFfPGRWqY
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: INSTITUTION_ATTENDED_DATE
  - Schema: 

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: INSTITUTION_ATTENDED_DATE
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: INSTITUTION_ATTENDED_DATE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: INSTITUTIONS_ATTEND_DATES_ATTENDED
  - Cache Type: Cached

---

##### mt_INSTITUTION_ATTENDED_soft_delete

**Basic Information:**
- **Task Name**: mt_INSTITUTION_ATTENDED_soft_delete
- **Mapping Reference**: e7Qpl9e96gLeU0HjCufPqL
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_INSTITUTION_ATTENDED
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: INSTITUTION_ATTENDED
  - Schema: 
  - Filter: `INSTITUTION_ATTENDED.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_INSTITUTION_ATTENDED_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: INSTITUTION_ATTENDED
  - Operation: Update
- **Target 2**: tgt_INSTITUTION_ATTENDED_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: INSTITUTION_ATTENDED
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_institutions_attend
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: INSTITUTIONS_ATTEND
  - Cache Type: Cached

---

##### mt_INSTITUTION_ATTENDED_YEAR_soft_delete

**Basic Information:**
- **Task Name**: mt_INSTITUTION_ATTENDED_YEAR_soft_delete
- **Mapping Reference**: 7l0fRjeAp9tk0TVWr6wceV
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: INSTITUTION_ATTENDED_YEAR
  - Schema: 
  - Filter: `INSTITUTION_ATTENDED_YEAR.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: INSTITUTION_ATTENDED_YEAR
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: INSTITUTION_ATTENDED_YEAR
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: INSTITUTIONS_ATTEND_YEARS_ATTENDED
  - Cache Type: Cached

---

##### mt_INSTITUTION_soft_delete

**Basic Information:**
- **Task Name**: mt_INSTITUTION_soft_delete
- **Mapping Reference**: 5eDPAdCcLGHbpFRZ0eHVYj
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_INSTITUTION
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: INSTITUTION
  - Schema: 
  - Filter: `INSTITUTION.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_INSTITUTION_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: INSTITUTION
  - Operation: Update
- **Target 2**: tgt_INSTITUTION_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: INSTITUTION
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_institutions
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: INSTITUTIONS
  - Cache Type: Cached

---

##### mt_INSTRUCTIONAL_METHOD_soft_delete

**Basic Information:**
- **Task Name**: mt_INSTRUCTIONAL_METHOD_soft_delete
- **Mapping Reference**: 2rxBlP0Rt2bd7wbB8LItU2
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: INSTRUCTIONAL_METHOD
  - Schema: 
  - Filter: `INSTRUCTIONAL_METHOD.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: INSTRUCTIONAL_METHOD
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: INSTRUCTIONAL_METHOD
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: INSTR_METHODS
  - Cache Type: Cached

---

##### mt_LOCATION_soft_delete

**Basic Information:**
- **Task Name**: mt_LOCATION_soft_delete
- **Mapping Reference**: hi7VuJZaiKTgFLuo3OJ06w
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: LOCATION
  - Schema: 
  - Filter: `LOCATION.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: LOCATION
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: LOCATION
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: LOCATIONS
  - Cache Type: Cached

---

##### mt_MAJOR_soft_delete

**Basic Information:**
- **Task Name**: mt_MAJOR_soft_delete
- **Mapping Reference**: 3CSU97oDpFQiK9OfJXAPsY
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: MAJOR
  - Schema: 
  - Filter: `MAJOR.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: MAJOR
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: MAJOR
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: MAJORS
  - Cache Type: Cached

---

##### mt_m_COURSE_SECTION_XLIST_soft_delete

**Basic Information:**
- **Task Name**: mt_m_COURSE_SECTION_XLIST_soft_delete
- **Mapping Reference**: 1VyGjPqixZwgsEURAd2Am0
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_COURSE_SECTION_XLIST
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_SECTION_XLIST
  - Schema: 
  - Filter: `COURSE_SECTION_XLIST.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_COURSE_SECTION_XLIST_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: COURSE_SECTION_XLIST
  - Operation: Update
- **Target 2**: tgt_COURSE_SECTION_XLIST_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: COURSE_SECTION_XLIST
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_course_sec_xlists
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: COURSE_SEC_XLISTS_CSXL_COURSE_SECTIONS
  - Cache Type: Cached

---

##### mt_NON_COURSES_soft_delete

**Basic Information:**
- **Task Name**: mt_NON_COURSES_soft_delete
- **Mapping Reference**: 4qgLJ3fWIhCeRylqgbGxiF
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: NON_COURSES
  - Schema: 
  - Filter: `NON_COURSES.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_DW_CORP
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: NON_COURSES
  - Operation: Update
- **Target 2**: tgt_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: NON_COURSES
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: NON_COURSES
  - Cache Type: Cached

---

##### mt_OTHER_DEGREE_soft_delete

**Basic Information:**
- **Task Name**: mt_OTHER_DEGREE_soft_delete
- **Mapping Reference**: 6xORKJWX4xWkX4ljqcBLIS
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: OTHER_DEGREE
  - Schema: 
  - Filter: `OTHER_DEGREE.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_DW_CORP
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: OTHER_DEGREE
  - Operation: Update
- **Target 2**: tgt_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: OTHER_DEGREE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: OTHER_DEGREES
  - Cache Type: Cached

---

##### mt_PERSON_ALT_soft_delete

**Basic Information:**
- **Task Name**: mt_PERSON_ALT_soft_delete
- **Mapping Reference**: 6SPpoJTXMOMgk8LN2nSdWv
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_ALT
  - Schema: 
  - Filter: `PERSON_ALT.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_ALT
  - Operation: Update
- **Target 2**: tgt_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON_ALT
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: PERSON_PERSON_ALT
  - Cache Type: Cached

---

##### mt_PERSON_DISABILITIES_soft_delete

**Basic Information:**
- **Task Name**: mt_PERSON_DISABILITIES_soft_delete
- **Mapping Reference**: aby6tGv9K08b2FoEYefJgk
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_DISABILITIES
  - Schema: 
  - Filter: `PERSON_DISABILITIES.IS_DELETED is null`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_DISABILITIES
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON_DISABILITIES
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: PERSON_HEALTH_PHL_DISABILITIES
  - Cache Type: Cached

---

##### mt_PERSON_HISTORY_LOG_soft_delete

**Basic Information:**
- **Task Name**: mt_PERSON_HISTORY_LOG_soft_delete
- **Mapping Reference**: cM7j8Y4sooSjCZOjKMeVIK
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_HISTORY_LOG
  - Schema: 
  - Filter: `PERSON_HISTORY_LOG.IS_DELETED is null`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_HISTORY_LOG
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON_HISTORY_LOG
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: PERSON_HIST_LOG
  - Cache Type: Cached

---

##### mt_PERSON_HISTORY_soft_delete

**Basic Information:**
- **Task Name**: mt_PERSON_HISTORY_soft_delete
- **Mapping Reference**: 2LdOnyYEz7ncQyxXapfBop
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_HISTORY
  - Schema: 
  - Filter: `PERSON_HISTORY.IS_DELETED is null`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_HISTORY
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON_HISTORY
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: PERSON_HIST
  - Cache Type: Cached

---

##### mt_PERSON_INSTITUTION_ATTENDED_soft_delete

**Basic Information:**
- **Task Name**: mt_PERSON_INSTITUTION_ATTENDED_soft_delete
- **Mapping Reference**: 5QDIxN4pPArkII4V81plQj
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_INSTITUTION_ATTENDED
  - Schema: 

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_INSTITUTION_ATTENDED
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON_INSTITUTION_ATTENDED
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: PERSON_PERSON_INSTITUTIONS_ATTEND
  - Cache Type: Cached

---

##### mt_PERSON_NAMEHIST_soft_delete

**Basic Information:**
- **Task Name**: mt_PERSON_NAMEHIST_soft_delete
- **Mapping Reference**: heTJ78OPbOBg7vYfDfC8oO
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_NAMEHIST
  - Schema: 
  - Filter: `PERSON_NAMEHIST.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_NAMEHIST
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON_NAMEHIST
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: PERSON_NAMEHIST
  - Cache Type: Cached

---

##### mt_PERSON_PARENTING_ANSWERS_soft_delete

**Basic Information:**
- **Task Name**: mt_PERSON_PARENTING_ANSWERS_soft_delete
- **Mapping Reference**: 1RUupplLA73gR0vlImAYIq
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_PERSON_PARENTING_ANSWERS_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_PARENTING_ANSWERS
  - Schema: 
  - Filter: `"PERSON_PARENTING_ANSWERS"."IS_DELETED" is null`

**Targets:**
- **Target 1**: tgt_GRADUATE_ERP_Hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_PARENTING_ANSWERS
  - Operation: Update
- **Target 2**: tgt_GRADUATE_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON_PARENTING_ANSWERS
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: A70_PERSON_A70_PER_PARENTING_ANSWERS
  - Cache Type: Cached

---

##### mt_PERSON_PARENTING_QUESTIONS_soft_delete

**Basic Information:**
- **Task Name**: mt_PERSON_PARENTING_QUESTIONS_soft_delete
- **Mapping Reference**: iyJXpZpA52uiGXYCC5GKgk
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_PERSON_PARENTING_QUESTIONS_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_PARENTING_QUESTIONS
  - Schema: 

**Targets:**
- **Target 1**: tgt_PERSON_PARENTING_QUESTIONS_ERP_Hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_PARENTING_QUESTIONS
  - Operation: Update
- **Target 2**: tgt_PERSON_PARENTING_QUESTIONS_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON_PARENTING_QUESTIONS
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: A70_PERSON_A70_PER_PARENTING_QUESTIONS
  - Cache Type: Cached

---

##### mt_PERSON_PEOPLE_EMAIL_soft_delete

**Basic Information:**
- **Task Name**: mt_PERSON_PEOPLE_EMAIL_soft_delete
- **Mapping Reference**: 7mJgQHbs4mUkmeK4Ia9Biw
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_PEOPLE_EMAIL
  - Schema: 
  - Filter: `PERSON_PEOPLE_EMAIL.IS_DELETED is null`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_PEOPLE_EMAIL
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON_PEOPLE_EMAIL
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: PERSON_PEOPLE_EMAIL
  - Cache Type: Cached

---

##### mt_PERSON_PERPHONE_soft_delete

**Basic Information:**
- **Task Name**: mt_PERSON_PERPHONE_soft_delete
- **Mapping Reference**: 0xTAjFn5dJfk1ZcUtfyVcG
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_PERPHONE
  - Schema: 
  - Filter: `PERSON_PERPHONE.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_PERPHONE
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON_PERPHONE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: PERSON_PERPHONE
  - Cache Type: Cached

---

##### mt_PERSON_POSITION_soft_delete

**Basic Information:**
- **Task Name**: mt_PERSON_POSITION_soft_delete
- **Mapping Reference**: 9iTl62atSWGiItqcOHshyb
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_POSITION
  - Schema: 
  - Filter: `PERSON_POSITION.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_PERSON_POSITION_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON_POSITION
  - Operation: Update
- **Target 2**: tgt_PERSON_POSITION_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_POSITION
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: PERPOS
  - Cache Type: Cached

---

##### mt_PERSON_POSITION_WAGE_ITEM_soft_delete

**Basic Information:**
- **Task Name**: mt_PERSON_POSITION_WAGE_ITEM_soft_delete
- **Mapping Reference**: 0Vism6I2wPtiKTgmtQykk6
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_POSITION_WAGE_ITEM
  - Schema: 
  - Filter: `PERSON_POSITION_WAGE_ITEM.IS_DELETED is null`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_POSITION_WAGE_ITEM
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON_POSITION_WAGE_ITEM
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: PERPOSWG_PPWITEMS
  - Cache Type: Cached

---

##### mt_PERSON_POSITION_WAGE_soft_delete

**Basic Information:**
- **Task Name**: mt_PERSON_POSITION_WAGE_soft_delete
- **Mapping Reference**: 4fMdateYHM3jXsSPb6ipsB
- **Operation Types**: Delete

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_POSITION_WAGE
  - Schema: 
  - Filter: `PERSON_POSITION_WAGE.IS_DELETED is null`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_POSITION_WAGE
  - Operation: Delete
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON_POSITION_WAGE
  - Operation: Delete

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: PERPOSWG
  - Cache Type: Cached

---

##### mt_PERSON_PSEASON_soft_delete

**Basic Information:**
- **Task Name**: mt_PERSON_PSEASON_soft_delete
- **Mapping Reference**: 02xgQ0xeh6AeqborEYXWo6
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_PERSON_PSEASON
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_PSEASON
  - Schema: 
  - Filter: `PERSON_PSEASON.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_PERSON_PSEASON_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON_PSEASON
  - Operation: Update
- **Target 2**: tgt_PERSON_PSEASON_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_PSEASON
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_person_pseason
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: PERSON_PSEASON
  - Cache Type: Cached

---

##### mt_PERSON_RACE_soft_delete

**Basic Information:**
- **Task Name**: mt_PERSON_RACE_soft_delete
- **Mapping Reference**: 3bTOEEBbroPeUQ1wABjwAa
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_PERSON_RACE
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_RACE
  - Schema: 
  - Filter: `PERSON_RACE.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_PERSON_RACE_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON_RACE
  - Operation: Update
- **Target 2**: tgt_PERSON_RACE_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_RACE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_person_per_races
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: PERSON_PER_RACES
  - Cache Type: Cached

---

##### mt_PERSON_soft_delete

**Basic Information:**
- **Task Name**: mt_PERSON_soft_delete
- **Mapping Reference**: eXJ6hxyQKw7c3ZWl9GJdyB
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_PERSON
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON
  - Schema: 
  - Filter: `PERSON.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_PERSON_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON
  - Operation: Update
- **Target 2**: tgt_PERSON_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_person
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: PERSON
  - Cache Type: Cached

---

##### mt_PERSON_SPONSORSHIP_soft_delete

**Basic Information:**
- **Task Name**: mt_PERSON_SPONSORSHIP_soft_delete
- **Mapping Reference**: eysxeD2zeYKci9zDfD1cgC
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_PERSON_SPONSORSHIP
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/PERSON_SPONSORSHIP
  - Schema: dbo
  - Filter: `"PERSON_SPONSORSHIP"."IS_DELETED" is null`

**Targets:**
- **Target 1**: tgt_PERSON_SPONSORSHIP_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: erp/PERSON_SPONSORSHIP
  - Operation: Upsert
- **Target 2**: tgt_PERSON_SPONSORSHIP_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/PERSON_SPONSORSHIP
  - Operation: Upsert

**Lookups:**
- **Lookup 1**: lkp_stg_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: data/PERSON_SPONSORSHIPS
  - Cache Type: Cached

---

##### mt_PERSON_ST_EDUCATION_GOAL_soft_delete

**Basic Information:**
- **Task Name**: mt_PERSON_ST_EDUCATION_GOAL_soft_delete
- **Mapping Reference**: 56q5r2dSf2AiVfIhr1qAIj
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_ST_EDUCATION_GOAL
  - Schema: 
  - Filter: `PERSON_ST_EDUCATION_GOAL.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_ST_EDUCATION_GOAL
  - Operation: Update
- **Target 2**: tgt_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON_ST_EDUCATION_GOAL
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: PERSON_ST_EDUC_GOALS
  - Cache Type: Cached

---

##### mt_PERSON_VETERAN_ASSOCIATION_soft_delete

**Basic Information:**
- **Task Name**: mt_PERSON_VETERAN_ASSOCIATION_soft_delete
- **Mapping Reference**: 4xwbKOvwj43deW0qL5UGgI
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_VETERAN_ASSOCIATION
  - Schema: 
  - Filter: `PERSON_VETERAN_ASSOCIATION.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_VETERAN_ASSOCIATION
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON_VETERAN_ASSOCIATION
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: PERSON_VETERAN_ASSOC
  - Cache Type: Cached

---

##### mt_POSITION_soft_delete

**Basic Information:**
- **Task Name**: mt_POSITION_soft_delete
- **Mapping Reference**: hgHCa79d7epl5xr7uiADgI
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: POSITION
  - Schema: 
  - Filter: `POSITION.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: POSITION
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: POSITION
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: POSITION
  - Cache Type: Cached

---

##### mt_REG_BILLING_RATE_soft_delete

**Basic Information:**
- **Task Name**: mt_REG_BILLING_RATE_soft_delete
- **Mapping Reference**: 8JdXrBf9fmcfXbTQEbgEUq
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_REG_BILLING_RATE
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: REG_BILLING_RATE
  - Schema: 
  - Filter: `REG_BILLING_RATE.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_REG_BILLING_RATE_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: REG_BILLING_RATE
  - Operation: Update
- **Target 2**: tgt_REG_BILLING_RATE_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: REG_BILLING_RATE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_reg_billing_rates
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: REG_BILLING_RATES
  - Cache Type: Cached

---

##### mt_SAP_APPEAL_soft_delete

**Basic Information:**
- **Task Name**: mt_SAP_APPEAL_soft_delete
- **Mapping Reference**: 03GS0WjiiM6hndJuXuPc4z
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_SAP_APPEAL
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: SAP_APPEAL
  - Schema: 
  - Filter: `SAP_APPEAL.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_SAP_APPEAL_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: SAP_APPEAL
  - Operation: Update
- **Target 2**: tgt_SAP_APPEAL_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: SAP_APPEAL
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_sap_appeals
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: SAP_APPEALS
  - Cache Type: Cached

---

##### mt_SAP_RESULT_soft_delete

**Basic Information:**
- **Task Name**: mt_SAP_RESULT_soft_delete
- **Mapping Reference**: 8GxJMw4nmuZhzRK92uFC4L
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_SAP_RESULT
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: SAP_RESULT
  - Schema: 
  - Filter: `SAP_RESULT.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_SAP_RESULT_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: SAP_RESULT
  - Operation: Update
- **Target 2**: tgt_SAP_RESULT_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: SAP_RESULT
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_sap_results
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: SAP_RESULTS
  - Cache Type: Cached

---

##### mt_SA_ACYR_AWARD_LIST_soft_delete

**Basic Information:**
- **Task Name**: mt_SA_ACYR_AWARD_LIST_soft_delete
- **Mapping Reference**: igTR4pW24IweaHNl0DwZmI
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_SA_ACYR_AWARD_LIST_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: SA_ACYR_AWARD_LIST
  - Schema: 
  - Filter: `SA_ACYR_AWARD_LIST.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_SA_ACYR_AWARD_LIST_DW_CORP
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: SA_ACYR_AWARD_LIST
  - Operation: Update
- **Target 2**: tgt_SA_ACYR_AWARD_LIST_ERP_HUB
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: SA_ACYR_AWARD_LIST
  - Operation: Update

---

##### mt_SA_ACYR_soft_delete

**Basic Information:**
- **Task Name**: mt_SA_ACYR_soft_delete
- **Mapping Reference**: 1kWbGz8UUuQgVbrmsG96uk
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: SA_ACYR
  - Schema: 
  - Filter: `SA_ACYR.IS_DELETED is null`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: SA_ACYR
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: SA_ACYR
  - Operation: Update

---

##### mt_SCHOOL_DIVISION_soft_delete

**Basic Information:**
- **Task Name**: mt_SCHOOL_DIVISION_soft_delete
- **Mapping Reference**: 34etx0tuhGmjjLjzahIiMu
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_SCHOOL_DIVISION
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: SCHOOL_DIVISION
  - Schema: 
  - Filter: `SCHOOL_DIVISION.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_SCHOOL_DIVISION_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: SCHOOL_DIVISION
  - Operation: Update
- **Target 2**: tgt_SCHOOL_DIVISION_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: SCHOOL_DIVISION
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_schools_divisions
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: SCHOOLS_SCHOOLS_DIVISIONS
  - Cache Type: Cached

---

##### mt_SCHOOL_soft_delete

**Basic Information:**
- **Task Name**: mt_SCHOOL_soft_delete
- **Mapping Reference**: 80RLO9RL8YNjrltsdJbLI4
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_SCHOOL
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: SCHOOL
  - Schema: 
  - Filter: `SCHOOL.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_SCHOOL_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: SCHOOL
  - Operation: Update
- **Target 2**: tgt_SCHOOL_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: SCHOOL
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_schools
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: SCHOOLS
  - Cache Type: Cached

---

##### mt_SL_ACYR_soft_delete

**Basic Information:**
- **Task Name**: mt_SL_ACYR_soft_delete
- **Mapping Reference**: lNWk30nwKubiCHP9bOWGwX
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: SL_ACYR
  - Schema: 
  - Filter: `SL_ACYR.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: SL_ACYR
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: SL_ACYR
  - Operation: Update

---

##### mt_SPONSORED_PERSON_TERM_soft_delete

**Basic Information:**
- **Task Name**: mt_SPONSORED_PERSON_TERM_soft_delete
- **Mapping Reference**: 2uFGiUkAkI5kIqKpAqGDWw
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/SPONSORED_PERSON_TERM
  - Schema: dbo
  - Filter: `"SPONSORED_PERSON_TERM"."IS_DELETED" is null`

**Targets:**
- **Target 1**: tgt_DW_CORP
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: erp/SPONSORED_PERSON_TERM
  - Operation: Update
- **Target 2**: tgt_ERP_HUB
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/SPONSORED_PERSON_TERM
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: data/SPONSORED_PERSON_SPNP_TERMS
  - Cache Type: Cached

---

##### mt_STUDENT_ACADEMIC_CREDIT_soft_delete

**Basic Information:**
- **Task Name**: mt_STUDENT_ACADEMIC_CREDIT_soft_delete
- **Mapping Reference**: ddhIYSZ2gGyiIDfIPFYiSK
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_STUDENT_ACADEMIC_CREDIT
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_ACADEMIC_CREDIT
  - Schema: 
  - Filter: `STUDENT_ACADEMIC_CREDIT.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_STUDENT_ACADEMIC_CREDIT_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: STUDENT_ACADEMIC_CREDIT
  - Operation: Update
- **Target 2**: tgt_STUDENT_ACADEMIC_CREDIT_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_ACADEMIC_CREDIT
  - Operation: Update

**Lookups:**
- **Lookup 1**: LKP_STUDENT_ACAD_CRED
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: STUDENT_ACAD_CRED
  - Cache Type: Cached

---

##### mt_STUDENT_ACADEMIC_CREDIT_STATUS_soft_delete

**Basic Information:**
- **Task Name**: mt_STUDENT_ACADEMIC_CREDIT_STATUS_soft_delete
- **Mapping Reference**: agKdikbHbQWc1i0CW0HS8k
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_STUDENT_ACADEMIC_CREDIT_STATUS
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_ACADEMIC_CREDIT_STATUS
  - Schema: 
  - Filter: `STUDENT_ACADEMIC_CREDIT_STATUS.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_STUDENT_ACADEMIC_CREDIT_STATUS_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: STUDENT_ACADEMIC_CREDIT_STATUS
  - Operation: Update
- **Target 2**: tgt_STUDENT_ACADEMIC_CREDIT_STATUS_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_ACADEMIC_CREDIT_STATUS
  - Operation: Update

**Lookups:**
- **Lookup 1**: U_Lookup
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: STUDENT_ACAD_CRED_STC_STATUSES
  - Cache Type: Cached

---

##### mt_STUDENT_ACADEMIC_LEVEL_soft_delete

**Basic Information:**
- **Task Name**: mt_STUDENT_ACADEMIC_LEVEL_soft_delete
- **Mapping Reference**: dIYnRKirxCykYashFNZWI9
- **Operation Types**: Update

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_ACADEMIC_LEVEL
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: STUDENT_ACADEMIC_LEVEL
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: STUDENT_ACAD_LEVELS
  - Cache Type: Cached

---

##### mt_STUDENT_ADVISEMENT_soft_delete

**Basic Information:**
- **Task Name**: mt_STUDENT_ADVISEMENT_soft_delete
- **Mapping Reference**: aiWo4m93h8HjUkYGhE4VkD
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_ADVISEMENT
  - Schema: 
  - Filter: `STUDENT_ADVISEMENT.IS_DELETED is null`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_ADVISEMENT
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: STUDENT_ADVISEMENT
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: STUDENT_ADVISEMENT
  - Cache Type: Cached

---

##### mt_STUDENT_COURSE_SECTION_soft_delete

**Basic Information:**
- **Task Name**: mt_STUDENT_COURSE_SECTION_soft_delete
- **Mapping Reference**: aG42C9ezqYYlM1g4UAMIID
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_COURSE_SECTION
  - Schema: 
  - Filter: `STUDENT_COURSE_SECTION.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_DW_CORP
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: STUDENT_COURSE_SECTION
  - Operation: Update
- **Target 2**: tgt_ERP_HUB
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_COURSE_SECTION
  - Operation: Update

**Lookups:**
- **Lookup 1**: LKP_STUDENT_COURSE_SECTION_STAGE
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: STUDENT_COURSE_SEC
  - Cache Type: Cached

---

##### mt_STUDENT_EQUIV_EVAL_soft_delete

**Basic Information:**
- **Task Name**: mt_STUDENT_EQUIV_EVAL_soft_delete
- **Mapping Reference**: 5gjA8KHAFmrbUl0hfhrF2o
- **Operation Types**: Update

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_EQUIV_EVAL
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: STUDENT_EQUIV_EVAL
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: STUDENT_EQUIV_EVALS
  - Cache Type: Cached

---

##### mt_STUDENT_MILITARY_VETERAN_soft_delete

**Basic Information:**
- **Task Name**: mt_STUDENT_MILITARY_VETERAN_soft_delete
- **Mapping Reference**: 1TxJbI3F5Hdf4M1TU0zRA7
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_MILITARY_VETERAN
  - Schema: 
  - Filter: `STUDENT_MILITARY_VETERAN.IS_DELETED is null`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_MILITARY_VETERAN
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: STUDENT_MILITARY_VETERAN
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: STU_MILITARY_VETERAN_STUDENT_VET_BENEFITS
  - Cache Type: Cached

---

##### mt_STUDENT_NON_COURSE_soft_delete

**Basic Information:**
- **Task Name**: mt_STUDENT_NON_COURSE_soft_delete
- **Mapping Reference**: exYZ4gz07QhbeqPBugIOO3
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_NON_COURSE
  - Schema: 
  - Filter: `STUDENT_NON_COURSE.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_NON_COURSE
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: STUDENT_NON_COURSE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: STUDENT_NON_COURSES
  - Cache Type: Cached

---

##### mt_STUDENT_PROGRAM_DATE_soft_delete

**Basic Information:**
- **Task Name**: mt_STUDENT_PROGRAM_DATE_soft_delete
- **Mapping Reference**: 79ltKaRsayek0XC77FrjeM
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_STUDENT_PROGRAM_DATE
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_PROGRAM_DATE
  - Schema: 
  - Filter: `STUDENT_PROGRAM_DATE.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_STUDENT_PROGRAM_DATE_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: STUDENT_PROGRAM_DATE
  - Operation: Update
- **Target 2**: tgt_STUDENT_PROGRAM_DATE_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_PROGRAM_DATE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_student_program_dates
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: STUDENT_PROGRAMS_STPR_DATES
  - Cache Type: Cached

---

##### mt_STUDENT_PROGRAM_soft_delete

**Basic Information:**
- **Task Name**: mt_STUDENT_PROGRAM_soft_delete
- **Mapping Reference**: iui0y6d8Y2fg7KFAcDE0KK
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_STUDENT_PROGRAM
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_PROGRAM
  - Schema: 
  - Filter: `STUDENT_PROGRAM.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_STUDENT_PROGRAM_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: STUDENT_PROGRAM
  - Operation: Update
- **Target 2**: tgt_STUDENT_PROGRAM_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_PROGRAM
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_student_program
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: STUDENT_PROGRAMS
  - Cache Type: Cached

---

##### mt_STUDENT_PROGRAM_STATUS_soft_delete

**Basic Information:**
- **Task Name**: mt_STUDENT_PROGRAM_STATUS_soft_delete
- **Mapping Reference**: 1Ba1w0fnUSJdwq4nKWROQp
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_STUDENT_PROGRAM_STATUS
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_PROGRAM_STATUS
  - Schema: 
  - Filter: `STUDENT_PROGRAM_STATUS.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_STUDENT_PROGRAM_STATUS_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: STUDENT_PROGRAM_STATUS
  - Operation: Update
- **Target 2**: tgt_STUDENT_PROGRAM_STATUS_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_PROGRAM_STATUS
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_student_program_status
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: STUDENT_PROGRAMS_STPR_STATUSES
  - Cache Type: Cached

---

##### mt_STUDENT_REPEATED_ACADEMIC_CREDIT_soft_delete

**Basic Information:**
- **Task Name**: mt_STUDENT_REPEATED_ACADEMIC_CREDIT_soft_delete
- **Mapping Reference**: az22BWaUfM9bBh1GNiULCb
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_REPEATED_ACADEMIC_CREDIT
  - Schema: 
  - Filter: `STUDENT_REPEATED_ACADEMIC_CREDIT.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_DW_CORP
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: STUDENT_REPEATED_ACADEMIC_CREDIT
  - Operation: Update
- **Target 2**: tgt_ERP_HUB
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_REPEATED_ACADEMIC_CREDIT
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: STUDENT_ACAD_CRED_STC_REPEATED_ACAD_CRED
  - Cache Type: Cached

---

##### mt_STUDENT_RESTRICTION_soft_delete

**Basic Information:**
- **Task Name**: mt_STUDENT_RESTRICTION_soft_delete
- **Mapping Reference**: 30eviFrxALZkFCWbX0LjwY
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_RESTRICTION
  - Schema: 
  - Filter: `STUDENT_RESTRICTION.IS_DELETED is null`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_RESTRICTION
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: STUDENT_RESTRICTION
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: STUDENT_RESTRICTIONS
  - Cache Type: Cached

---

##### mt_STUDENT_soft_delete

**Basic Information:**
- **Task Name**: mt_STUDENT_soft_delete
- **Mapping Reference**: lwF8zzRGOenfj9GcXjooeP
- **Operation Types**: Update

**Targets:**
- **Target 1**: tgt_STUDENT_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: STUDENT
  - Operation: Update
- **Target 2**: tgt_STUDENT_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_students
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: STUDENTS
  - Cache Type: Cached

---

##### mt_STUDENT_STANDING_soft_delete

**Basic Information:**
- **Task Name**: mt_STUDENT_STANDING_soft_delete
- **Mapping Reference**: 76Apa3buzD5lzmYzpWyGmQ
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_STUDENT_STANDING
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_STANDING
  - Schema: 
  - Filter: `STUDENT_STANDING.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_STUDENT_STANDING_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: STUDENT_STANDING
  - Operation: Update
- **Target 2**: tgt_STUDENT_STANDING_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_STANDING
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_student_standings
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: STUDENT_STANDINGS
  - Cache Type: Cached

---

##### mt_STUDENT_TERM_soft_delete

**Basic Information:**
- **Task Name**: mt_STUDENT_TERM_soft_delete
- **Mapping Reference**: 39GL7ItE62qitWcY97plQ7
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_TERM
  - Schema: 

**Targets:**
- **Target 1**: tgt_STUDENT_TERM_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: STUDENT_TERM
  - Operation: Update
- **Target 2**: tgt_STUDENT_TERM_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_TERM
  - Operation: Update

**Lookups:**
- **Lookup 1**: LKP_STUDENT_TERMS
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: STUDENT_TERMS
  - Cache Type: Cached

---

##### mt_STUDENT_TYPE_INFO_soft_delete

**Basic Information:**
- **Task Name**: mt_STUDENT_TYPE_INFO_soft_delete
- **Mapping Reference**: 61ctBDhXa8Ue4ZgERxNlYY
- **Operation Types**: Update

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_TYPE_INFO
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: STUDENT_TYPE_INFO
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: STUDENTS_STU_TYPE_INFO
  - Cache Type: Cached

---

##### mt_STUDENT_TYPE_soft_delete

**Basic Information:**
- **Task Name**: mt_STUDENT_TYPE_soft_delete
- **Mapping Reference**: 8PeZbHZPLWRiNPmgXmyyeH
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_STUDENT_TYPE
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_TYPE
  - Schema: 
  - Filter: `STUDENT_TYPE.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_STUDENT_TYPE_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: STUDENT_TYPE
  - Operation: Update
- **Target 2**: tgt_STUDENT_TYPE_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: STUDENT_TYPE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_student_types
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: STUDENT_TYPES
  - Cache Type: Cached

---

##### mt_ST_TX_COURSE_WORK_soft_delete

**Basic Information:**
- **Task Name**: mt_ST_TX_COURSE_WORK_soft_delete
- **Mapping Reference**: 2tPYKz6UowpkzLae7JmPal
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/ST_TX_COURSE_WORK
  - Schema: dbo
  - Filter: `dbo.ST_TX_COURSE_WORK.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_DW_CORP
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: erp/ST_TX_COURSE_WORK
  - Operation: Update
- **Target 2**: tgt_ERP_HUB
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/ST_TX_COURSE_WORK
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: data/ST_TX_CRS_WORK
  - Cache Type: Cached

---

##### mt_ST_TX_STUDENT_WORK_soft_delete

**Basic Information:**
- **Task Name**: mt_ST_TX_STUDENT_WORK_soft_delete
- **Mapping Reference**: 6uYeO50yN1HlNFvcJZqhC7
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_ST_TX_STUDENT_WORK
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/ST_TX_STUDENT_WORK
  - Schema: dbo
  - Filter: `"ST_TX_STUDENT_WORK"."IS_DELETED" is null`

**Targets:**
- **Target 1**: tgt_ST_TX_STUDENT_WORK_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: erp/ST_TX_STUDENT_WORK
  - Operation: Upsert
- **Target 2**: tgt_ST_TX_STUDENT_WORK_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/ST_TX_STUDENT_WORK
  - Operation: Upsert

**Lookups:**
- **Lookup 1**: lkp_stg_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: data/ST_TX_STU_WORK
  - Cache Type: Cached

---

##### mt_TASP_HISTORY_soft_delete

**Basic Information:**
- **Task Name**: mt_TASP_HISTORY_soft_delete
- **Mapping Reference**: 5XcyzrEk0kqg1KUAo4xEGi
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_TASP_HISTORY
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TASP_HISTORY
  - Schema: 
  - Filter: `TASP_HISTORY.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_TASP_HISTORY_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: TASP_HISTORY
  - Operation: Update
- **Target 2**: tgt_TASP_HISTORY_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TASP_HISTORY
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_tsap_history
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: A70_TASP_HISTORY
  - Cache Type: Cached

---

##### mt_TA_ACYR_soft_delete

**Basic Information:**
- **Task Name**: mt_TA_ACYR_soft_delete
- **Mapping Reference**: iveQ3PjVE6ajs0WTEdiEge
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_TA_ACYR_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TA_ACYR
  - Schema: 
  - Filter: `TA_ACYR.IS_DELETED is null`

**Targets:**
- **Target 1**: tgt_TA_ACYR_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: TA_ACYR
  - Operation: Update
- **Target 2**: tgt_TA_ACYR_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TA_ACYR
  - Operation: Update

---

##### mt_TERM_soft_delete

**Basic Information:**
- **Task Name**: mt_TERM_soft_delete
- **Mapping Reference**: 9rIdExz8jMZfWCYKn2LB4s
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_TERM
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TERM
  - Schema: 
  - Filter: `TERM.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_TERM_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: TERM
  - Operation: Update
- **Target 2**: tgt_TERM_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TERM
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_terms
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: TERMS
  - Cache Type: Cached

---

##### mt_TEXAS_STUDENT_PERKINS_soft_delete

**Basic Information:**
- **Task Name**: mt_TEXAS_STUDENT_PERKINS_soft_delete
- **Mapping Reference**: 1Q20Htwp9c5i98p2BJ6eUM
- **Operation Types**: Update

**Targets:**
- **Target 1**: tgt_TEXAS_STUDENT_PERKINS_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: TEXAS_STUDENT_PERKINS
  - Operation: Update
- **Target 2**: tgt_TEXAS_STUDENT_PERKINS_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TEXAS_STUDENT_PERKINS
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_txst_perkins
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: TXST_PERKINS
  - Cache Type: Cached

---

##### mt_TEXAS_STUDENT_soft_delete

**Basic Information:**
- **Task Name**: mt_TEXAS_STUDENT_soft_delete
- **Mapping Reference**: 7ZewOmWKYkFjv5Dl2OE76v
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_TEXAS_STUDENT
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TEXAS_STUDENT
  - Schema: 
  - Filter: `TEXAS_STUDENT.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_TEXAS_STUDENT_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: TEXAS_STUDENT
  - Operation: Update
- **Target 2**: tgt_TEXAS_STUDENT_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TEXAS_STUDENT
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_stg_txst_Students
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: TXST_STUDENTS
  - Cache Type: Cached

---

##### mt_TX_ST_REPORT_PARAM_DEV_NCBO_soft_delete

**Basic Information:**
- **Task Name**: mt_TX_ST_REPORT_PARAM_DEV_NCBO_soft_delete
- **Mapping Reference**: 2sIz9IElUCkiCqgRoKmJi2
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TX_ST_REPORT_PARAM_DEV_NCBO
  - Schema: 
  - Filter: `TX_ST_REPORT_PARAM_DEV_NCBO.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TX_ST_REPORT_PARAM_DEV_NCBO
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: TX_ST_REPORT_PARAM_DEV_NCBO
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: TX_ST_RPT_PARAMS_TSRP_DEV_NCBO
  - Cache Type: Cached

---

##### mt_TX_ST_REPORT_PARAM_SCH_LIMIT_DEG_TYPE_soft_delete

**Basic Information:**
- **Task Name**: mt_TX_ST_REPORT_PARAM_SCH_LIMIT_DEG_TYPE_soft_delete
- **Mapping Reference**: 5GMqhYmzF4NjOH4cykXDGG
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_TX_ST_REPORT_PARAM_SCH_LIMIT_DEG_TYPE
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TX_ST_REPORT_PARAM_SCH_LIMIT_DEG_TYPE
  - Schema: 

**Targets:**
- **Target 1**: tgt_DW_CORP
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: TX_ST_REPORT_PARAM_SCH_LIMIT_DEG_TYPE
  - Operation: Update
- **Target 2**: tgt_ERP_HUB
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TX_ST_REPORT_PARAM_SCH_LIMIT_DEG_TYPE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_limit_deg_types
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: TX_ST_RPT_PARAMS_TSRP_SCH_LIMIT_DEG_TYPES
  - Cache Type: Cached

---

##### mt_TX_ST_REPORT_PARAM_soft_delete

**Basic Information:**
- **Task Name**: mt_TX_ST_REPORT_PARAM_soft_delete
- **Mapping Reference**: 2vqhm74acUgkf9yfncnKY2
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_TX_ST_REPORT_PARAM
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TX_ST_REPORT_PARAM
  - Schema: 
  - Filter: `TX_ST_REPORT_PARAM.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: tgt_TX_ST_REPORT_PARAM_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: TX_ST_REPORT_PARAM
  - Operation: Update
- **Target 2**: tgt_TX_ST_REPORT_PARAM_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TX_ST_REPORT_PARAM
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_txst_rpt_params
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: TX_ST_RPT_PARAMS
  - Cache Type: Cached

---

##### mt_TX_ST_REPORT_PARAM_TASP_CMPL_CRSS_soft_delete

**Basic Information:**
- **Task Name**: mt_TX_ST_REPORT_PARAM_TASP_CMPL_CRSS_soft_delete
- **Mapping Reference**: 3h518q06FSNlqdc4cK9H8q
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_TX_ST_REPORT_PARAM_TASP_CMPL_CRSS
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TX_ST_REPORT_PARAM_TASP_CMPL_CRSS
  - Schema: 

**Targets:**
- **Target 1**: tgt_DW_CORP
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: TX_ST_REPORT_PARAM_TASP_CMPL_CRSS
  - Operation: Update
- **Target 2**: tgt_ERP_HUB
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TX_ST_REPORT_PARAM_TASP_CMPL_CRSS
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_tasp_cmpl_crss
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: TX_ST_RPT_PARAMS_TSRP_TASP_CMPL_CRSS
  - Cache Type: Cached

---

##### mt_TX_ST_REPORT_PARAM_TASP_DEV_AREA_soft_delete

**Basic Information:**
- **Task Name**: mt_TX_ST_REPORT_PARAM_TASP_DEV_AREA_soft_delete
- **Mapping Reference**: 3YW9cmFYJbVc5s5G3QIxqn
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_TX_ST_REPORT_PARAM_TASP_DEV_AREA
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TX_ST_REPORT_PARAM_TASP_DEV_AREA
  - Schema: 

**Targets:**
- **Target 1**: tgt_DW_CORP
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: TX_ST_REPORT_PARAM_TASP_DEV_AREA
  - Operation: Update
- **Target 2**: tgt_ERP_HUB
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TX_ST_REPORT_PARAM_TASP_DEV_AREA
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_tasp_write_subjects
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: TX_ST_RPT_PARAMS_TSRP_TASP_WRITE_SUBJECTS
  - Cache Type: Cached

---

##### mt_TX_ST_REPORT_PARAM_TASP_DEV_COURSE_soft_delete

**Basic Information:**
- **Task Name**: mt_TX_ST_REPORT_PARAM_TASP_DEV_COURSE_soft_delete
- **Mapping Reference**: jNDfAsXr54wi87SKAavjMB
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_TX_ST_REPORT_PARAM_TASP_DEV_COURSE
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TX_ST_REPORT_PARAM_TASP_DEV_COURSE
  - Schema: 

**Targets:**
- **Target 1**: tgt_DW_CORP
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: TX_ST_REPORT_PARAM_TASP_DEV_COURSE
  - Operation: Update
- **Target 2**: tgt_ERP_HUB
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TX_ST_REPORT_PARAM_TASP_DEV_COURSE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_tasp_dev_course
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: TX_ST_RPT_PARAMS_TSRP_TASP_DEV_CRSS
  - Cache Type: Cached

---

##### mt_TX_ST_RPT_PARAM_TASP_DEV_COURSE_soft_delete

**Basic Information:**
- **Task Name**: mt_TX_ST_RPT_PARAM_TASP_DEV_COURSE_soft_delete
- **Mapping Reference**: lzwuF832Ma8epOvgySE5y1
- **Operation Types**: Update

**Sources:**
- **Source 1**: src_TX_ST_RPT_PARAM_TASP_DEV_COURSE
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TX_ST_RPT_PARAM_TASP_DEV_COURSE
  - Schema: 

**Targets:**
- **Target 1**: tgt_DW_CORP
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: TX_ST_RPT_PARAM_TASP_DEV_COURSE
  - Operation: Update
- **Target 2**: tgt_ERP_HUB
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: TX_ST_RPT_PARAM_TASP_DEV_COURSE
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_tasp_read_subjects
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: TX_ST_RPT_PARAMS_TSRP_TASP_READ_SUBJECTS
  - Cache Type: Cached

---

##### mt_VALCODE_soft_delete

**Basic Information:**
- **Task Name**: mt_VALCODE_soft_delete
- **Mapping Reference**: kUEtyw2d6iPfvqYeyH6Kky
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: VALCODE
  - Schema: 
  - Filter: `VALCODE.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: VALCODE
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: VALCODE
  - Operation: Update

---

##### mt_WAIT_LIST_soft_delete

**Basic Information:**
- **Task Name**: mt_WAIT_LIST_soft_delete
- **Mapping Reference**: 7V8P53GVekxceGwuBifS0b
- **Operation Types**: Update

**Sources:**
- **Source 1**: Source_ERPHub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: WAIT_LIST
  - Schema: 
  - Filter: `WAIT_LIST.IS_DELETED IS NULL`

**Targets:**
- **Target 1**: Tgt_ERP_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: WAIT_LIST
  - Operation: Update
- **Target 2**: tgt_DW_Corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: WAIT_LIST
  - Operation: Update

**Lookups:**
- **Lookup 1**: lkp_Stage_table
  - Connection: 5P29vuYLDHVfpnOFeoObk3
  - Object: WAIT_LIST
  - Cache Type: Cached

---

#### Connections Used

| Connection Name | Type |
|---|---|
| cn_File_Processor_Upload_TimelyCare | Connection |
| ff_NAS | Connection |
| ff_TimelyCare | Connection |
| SVC_Colleague_Stage | Connection |
| svc_DW_CORP | Connection |
| SVC_ERP_Hub | Connection |
| svc_ThirdpartyData_Hub | Connection |
| SVC_ThirdPartydata_stage | Connection |

#### Data Templates

| Template Name | Type |
|---|---|
| m_ACADEMIC_CREDENTIAL_soft_delete | DTEMPLATE |
| m_ACADEMIC_LEVEL_soft_delete | DTEMPLATE |
| m_ACADEMIC_PROGRAM_REQUIREMENT_soft_delete | DTEMPLATE |
| m_ACADEMIC_PROGRAM_soft_delete | DTEMPLATE |
| m_ADDRESS_soft_delete | DTEMPLATE |
| m_ADMIT_STATUS_soft_delete | DTEMPLATE |
| m_APPLICANT_soft_delete | DTEMPLATE |
| m_APPLICATION_soft_delete | DTEMPLATE |
| m_AWARD_PERIOD_soft_delete | DTEMPLATE |
| m_AWARD_soft_delete | DTEMPLATE |
| m_BUILDING_soft_delete | DTEMPLATE |
| m_CALENDAR_SCHEDULE_soft_delete | DTEMPLATE |
| m_CCDS_soft_delete | DTEMPLATE |
| m_CORP_FOUND_soft_delete | DTEMPLATE |
| m_COUNTRY_soft_delete | DTEMPLATE |
| m_COURSE_CONTACT_soft_delete | DTEMPLATE |
| m_COURSE_EQUATE_CODE_COURSE_soft_delete | DTEMPLATE |
| m_COURSE_EQUATE_CODE_soft_delete | DTEMPLATE |
| m_COURSE_EQUIVALENCE_soft_delete | DTEMPLATE |
| m_COURSE_SECTION_CONTACT_soft_delete | DTEMPLATE |
| m_COURSE_SECTION_COREQ_SECTION_soft_delete | DTEMPLATE |
| m_COURSE_SECTION_COURSE_TYPE_soft_delete | DTEMPLATE |
| m_COURSE_SECTION_FACULTY_soft_delete | DTEMPLATE |
| m_COURSE_SECTION_LOCAL_GOVT_CODE_soft_delete | DTEMPLATE |
| m_COURSE_SECTION_MEETING_soft_delete | DTEMPLATE |
| m_COURSE_SECTION_soft_delete | DTEMPLATE |
| m_COURSE_SECTION_XLIST_soft_delete | DTEMPLATE |
| m_COURSE_soft_delete | DTEMPLATE |
| m_COURSE_TITLE_INFO_soft_delete | DTEMPLATE |
| m_COURSE_TYPE_soft_delete | DTEMPLATE |
| m_CREDIT_TYPE_soft_delete | DTEMPLATE |
| m_CS_ACYR_soft_delete | DTEMPLATE |
| m_DEAN_DEPARTMENT_DETAIL_soft_delete | DTEMPLATE |
| m_DEGREE_soft_delete | DTEMPLATE |
| m_DEPARTMENT_CHAIR_soft_delete | DTEMPLATE |
| m_DEPARTMENT_soft_delete | DTEMPLATE |
| m_DISABILITY_soft_delete | DTEMPLATE |
| m_DIVISION_soft_delete | DTEMPLATE |
| m_DREGISTRATION_EXEMPT_REST_soft_delete | DTEMPLATE |
| m_DREGISTRATION_EXEMPT_soft_delete | DTEMPLATE |
| m_DREGISTRATION_EXEMPT_TOUCHNET_soft_delete | DTEMPLATE |
| m_DREGISTRATION_EXEMPT_VETERAN_soft_delete | DTEMPLATE |
| m_DREGISTRATION_STUDENT_soft_delete | DTEMPLATE |
| m_EDI_TRAN_COURSE_soft_delete | DTEMPLATE |
| m_EXTERNAL_TRANSCRIPTS_soft_delete | DTEMPLATE |
| m_FINANCIAL_AID_AWARD_HISTORY_soft_delete | DTEMPLATE |
| m_FINANCIAL_AID_CATEGORY_AMOUNT_soft_delete | DTEMPLATE |
| m_FINANCIAL_AID_COMMENT_CODE_soft_delete | DTEMPLATE |
| m_FINANCIAL_AID_COMMENT_soft_delete | DTEMPLATE |
| m_FINANCIAL_AID_DL_AWARD_CONDITION_soft_delete | DTEMPLATE |
| m_FINANCIAL_AID_FISAP_EAAD_soft_delete | DTEMPLATE |
| m_FINANCIAL_AID_FISAP_PRDD_soft_delete | DTEMPLATE |
| m_FINANCIAL_AID_INTERVIEW_CODE_soft_delete | DTEMPLATE |
| m_FINANCIAL_AID_INTERVIEW_soft_delete | DTEMPLATE |
| m_FINANCIAL_AID_LOCATION_soft_delete | DTEMPLATE |
| m_FINANCIAL_AID_OFFICE_soft_delete | DTEMPLATE |
| m_FINANCIAL_AID_OUTSIDE_AWARD_soft_delete | DTEMPLATE |
| m_FINANCIAL_AID_REQUIRED_CHILD_soft_delete | DTEMPLATE |
| m_FINANCIAL_AID_REQUIRED_soft_delete | DTEMPLATE |
| m_FINANCIAL_AID_SAP_RESULT_soft_delete | DTEMPLATE |
| m_FINANCIAL_AID_SAP_STATUS_INFO_soft_delete | DTEMPLATE |
| m_FINANCIAL_AID_SCP_soft_delete | DTEMPLATE |
| m_FINANCIAL_AID_soft_delete | DTEMPLATE |
| m_FINANCIAL_AID_TRANSMITTAL_soft_delete | DTEMPLATE |
| m_FOREIGN_PERSON_soft_delete | DTEMPLATE |
| m_GRADE_soft_delete | DTEMPLATE |
| m_GRADUATE_soft_delete | DTEMPLATE |
| m_HR_PERSON_INSTITUTIONAL_STATUS_soft_delete | DTEMPLATE |
| m_HR_PERSON_soft_delete | DTEMPLATE |
| m_HS_STUDENT_soft_delete | DTEMPLATE |
| m_INSTITUTION_ATTENDED_ACAD_CREDENTIAL_soft_delete | DTEMPLATE |
| m_INSTITUTION_ATTENDED_DATE_soft_delete | DTEMPLATE |
| m_INSTITUTION_ATTENDED_soft_delete | DTEMPLATE |
| m_INSTITUTION_ATTENDED_YEAR_soft_delete | DTEMPLATE |
| m_INSTITUTION_soft_delete | DTEMPLATE |
| m_INSTRUCTIONAL_METHOD_soft_delete | DTEMPLATE |
| m_LOCATION_soft_delete | DTEMPLATE |
| m_MAJOR_soft_delete | DTEMPLATE |
| m_NON_COURSES_soft_delete | DTEMPLATE |
| m_OTHER_DEGREE_soft_delete | DTEMPLATE |
| m_PERSON_ALT_soft_delete | DTEMPLATE |
| m_PERSON_DISABILITIES_soft_delete | DTEMPLATE |
| m_PERSON_HISTORY_LOG_soft_delete | DTEMPLATE |
| m_PERSON_HISTORY_soft_delete | DTEMPLATE |
| m_PERSON_INSTITUTION_ATTENDED_soft_delete | DTEMPLATE |
| m_PERSON_NAMEHIST_soft_delete | DTEMPLATE |
| m_PERSON_PARENTING_ANSWERS_soft_delete | DTEMPLATE |
| m_PERSON_PARENTING_QUESTIONS_soft_delete | DTEMPLATE |
| m_PERSON_PEOPLE_EMAIL_soft_delete | DTEMPLATE |
| m_PERSON_PERPHONE_soft_delete | DTEMPLATE |
| m_PERSON_POSITION_soft_delete | DTEMPLATE |
| m_PERSON_POSITION_WAGE_ITEM_soft_delete | DTEMPLATE |
| m_PERSON_POSITION_WAGE_soft_delete | DTEMPLATE |
| m_PERSON_PSEASON_soft_delete | DTEMPLATE |
| m_PERSON_RACE_soft_delete | DTEMPLATE |
| m_PERSON_soft_delete | DTEMPLATE |
| m_PERSON_SPONSORSHIP_soft_delete | DTEMPLATE |
| m_PERSON_ST_EDUCATION_GOAL_soft_delete | DTEMPLATE |
| m_PERSON_VETERAN_ASSOCIATION_soft_delete | DTEMPLATE |
| m_POSITION_soft_delete | DTEMPLATE |
| m_REG_BILLING_RATE_soft_delete | DTEMPLATE |
| m_SAP_APPEAL_soft_delete | DTEMPLATE |
| m_SAP_RESULT_soft_delete | DTEMPLATE |
| m_SA_ACYR_AWARD_LIST_soft_delete | DTEMPLATE |
| m_SA_ACYR_soft_delete | DTEMPLATE |
| m_SCHOOL_DIVISION_soft_delete | DTEMPLATE |
| m_SCHOOL_soft_delete | DTEMPLATE |
| m_SL_ACYR_soft_delete | DTEMPLATE |
| m_SPONSORED_PERSON_TERM_soft_delete | DTEMPLATE |
| m_STUDENT_ACADEMIC_CREDIT_soft_delete | DTEMPLATE |
| m_STUDENT_ACADEMIC_CREDIT_STATUS_soft_delete | DTEMPLATE |
| m_STUDENT_ACADEMIC_LEVEL_soft_delete | DTEMPLATE |
| m_STUDENT_ADVISEMENT_soft_delete | DTEMPLATE |
| m_STUDENT_COURSE_SECTION_soft_delete | DTEMPLATE |
| m_STUDENT_EQUIV_EVAL_soft_delete | DTEMPLATE |
| m_STUDENT_MILITARY_VETERAN_soft_delete | DTEMPLATE |
| m_STUDENT_NON_COURSE_soft_delete | DTEMPLATE |
| m_STUDENT_PROGRAM_DATE_soft_delete | DTEMPLATE |
| m_STUDENT_PROGRAM_soft_delete | DTEMPLATE |
| m_STUDENT_PROGRAM_STATUS_soft_delete | DTEMPLATE |
| m_STUDENT_REPEATED_ACADEMIC_CREDIT_soft_delete | DTEMPLATE |
| m_STUDENT_RESTRICTION_soft_delete | DTEMPLATE |
| m_STUDENT_soft_delete | DTEMPLATE |
| m_STUDENT_STANDING_soft_delete | DTEMPLATE |
| m_STUDENT_TERM_soft_delete | DTEMPLATE |
| m_STUDENT_TYPE_INFO_soft_delete | DTEMPLATE |
| m_STUDENT_TYPE_soft_delete | DTEMPLATE |
| m_ST_TX_COURSE_WORK_soft_delete | DTEMPLATE |
| m_ST_TX_STUDENT_WORK_soft_delete | DTEMPLATE |
| m_TASP_HISTORY_soft_delete | DTEMPLATE |
| m_TA_ACYR_soft_delete | DTEMPLATE |
| m_TERM_soft_delete | DTEMPLATE |
| m_TEXAS_STUDENT_PERKINS_soft_delete | DTEMPLATE |
| m_TEXAS_STUDENT_soft_delete | DTEMPLATE |
| m_TX_ST_REPORT_PARAM_DEV_NCBO_soft_delete | DTEMPLATE |
| m_TX_ST_REPORT_PARAM_SCH_LIMIT_DEG_TYPE_soft_delete | DTEMPLATE |
| m_TX_ST_REPORT_PARAM_soft_delete | DTEMPLATE |
| m_TX_ST_REPORT_PARAM_TASP_CMPL_CRSS_soft_delete | DTEMPLATE |
| m_TX_ST_REPORT_PARAM_TASP_DEV_AREA_soft_delete | DTEMPLATE |
| m_TX_ST_REPORT_PARAM_TASP_DEV_COURSE_soft_delete | DTEMPLATE |
| m_TX_ST_RPT_PARAM_TASP_DEV_COURSE_soft_delete | DTEMPLATE |
| m_VALCODE_soft_delete | DTEMPLATE |
| m_WAIT_LIST_soft_delete | DTEMPLATE |

---

### Taskflow: tf_TimleyCare

**Project Path**: `Explore/OutBound_Data/TimleyCare`

#### Mapping Tasks (MTT)

##### mt_TIMELYCARE_LOAD_OUTBOUND

**Basic Information:**
- **Task Name**: mt_TIMELYCARE_LOAD_OUTBOUND
- **Mapping Reference**: jl9UIBysC2Fchs08dDzmIR
- **Operation Types**: Insert, Upsert

**Sources:**
- **Source 1**: src_TIMELYCARE_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/TIMELYCARE
  - Schema: dbo

**Targets:**
- **Target 1**: tgt_TIMELYCARE_delete_upd
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/TIMELYCARE
  - Operation: Upsert
- **Target 2**: tgt_TIMELYCARE_deletes
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/TIMELYCARE
  - Operation: Upsert
- **Target 3**: tgt_TIMELYCARE_inserts
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/TIMELYCARE
  - Operation: Insert
- **Target 4**: tgt_ff_TIMELYCARE
  - Connection: 3QrOdtYEXYAhHXRPr4CAU4
  - Object: $tgt_ff_TIMELYCARE
  - Operation: Insert

---

##### mt_TIMELYCARE_OUTBOUND_GENERATE

**Basic Information:**
- **Task Name**: mt_TIMELYCARE_OUTBOUND_GENERATE
- **Mapping Reference**: 0nVgoy0IVxJev8pu4AhNWQ
- **Operation Types**: Insert

**Targets:**
- **Target 1**: Target
  - Connection: 3QrOdtYEXYAhHXRPr4CAU4
  - Object: $Target
  - Operation: Insert

---

##### mt_TimleyCare_SFTP

**Basic Information:**
- **Task Name**: mt_TimleyCare_SFTP
- **Mapping Reference**: heXH1xqvXA4k3LA5JTCOuP
- **Operation Types**: Insert

**Sources:**
- **Source 1**: src_ff_local_TimleyCare
  - Connection: 3Lfa58VbR0LfUZWioIh9qY
  - Object: SFTP_PUT
  - Schema: 

**Targets:**
- **Target 1**: tgt_dummy_ff
  - Connection: 0SZSz3Aw8nAlGZFaEEPSGe
  - Object: Dummy_TimelyCare_SFTP.csv
  - Operation: Insert

---

#### Connections Used

| Connection Name | Type |
|---|---|
| cn_File_Processor_Upload_TimelyCare | Connection |
| ff_NAS | Connection |
| ff_TimelyCare | Connection |
| SVC_Colleague_Stage | Connection |
| svc_DW_CORP | Connection |
| SVC_ERP_Hub | Connection |
| svc_ThirdpartyData_Hub | Connection |
| SVC_ThirdPartydata_stage | Connection |

#### Data Templates

| Template Name | Type |
|---|---|
| m_TIMELYCARE_LOAD_OUTBOUND | DTEMPLATE |
| m_TIMELYCARE_OUTBOUND_GENERATE | DTEMPLATE |
| m_TimleyCare_SFTP | DTEMPLATE |

---

### Taskflow: tf_TimleyCare_Delta

**Project Path**: `Explore/OutBound_Data/TimleyCare`

#### Mapping Tasks (MTT)

##### mt_TIMELYCARE_LOAD_OUTBOUND

**Basic Information:**
- **Task Name**: mt_TIMELYCARE_LOAD_OUTBOUND
- **Mapping Reference**: jl9UIBysC2Fchs08dDzmIR
- **Operation Types**: Insert, Upsert

**Sources:**
- **Source 1**: src_TIMELYCARE_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/TIMELYCARE
  - Schema: dbo

**Targets:**
- **Target 1**: tgt_TIMELYCARE_delete_upd
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/TIMELYCARE
  - Operation: Upsert
- **Target 2**: tgt_TIMELYCARE_deletes
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/TIMELYCARE
  - Operation: Upsert
- **Target 3**: tgt_TIMELYCARE_inserts
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: dbo/TIMELYCARE
  - Operation: Insert
- **Target 4**: tgt_ff_TIMELYCARE
  - Connection: 3QrOdtYEXYAhHXRPr4CAU4
  - Object: $tgt_ff_TIMELYCARE
  - Operation: Insert

---

##### mt_TIMELYCARE_OUTBOUND_GENERATE

**Basic Information:**
- **Task Name**: mt_TIMELYCARE_OUTBOUND_GENERATE
- **Mapping Reference**: 0nVgoy0IVxJev8pu4AhNWQ
- **Operation Types**: Insert

**Targets:**
- **Target 1**: Target
  - Connection: 3QrOdtYEXYAhHXRPr4CAU4
  - Object: $Target
  - Operation: Insert

---

##### mt_TimleyCare_SFTP

**Basic Information:**
- **Task Name**: mt_TimleyCare_SFTP
- **Mapping Reference**: heXH1xqvXA4k3LA5JTCOuP
- **Operation Types**: Insert

**Sources:**
- **Source 1**: src_ff_local_TimleyCare
  - Connection: 3Lfa58VbR0LfUZWioIh9qY
  - Object: SFTP_PUT
  - Schema: 

**Targets:**
- **Target 1**: tgt_dummy_ff
  - Connection: 0SZSz3Aw8nAlGZFaEEPSGe
  - Object: Dummy_TimelyCare_SFTP.csv
  - Operation: Insert

---

#### Connections Used

| Connection Name | Type |
|---|---|
| cn_File_Processor_Upload_TimelyCare | Connection |
| ff_NAS | Connection |
| ff_TimelyCare | Connection |
| SVC_Colleague_Stage | Connection |
| svc_DW_CORP | Connection |
| SVC_ERP_Hub | Connection |
| svc_ThirdpartyData_Hub | Connection |
| SVC_ThirdPartydata_stage | Connection |

#### Data Templates

| Template Name | Type |
|---|---|
| m_TIMELYCARE_LOAD_OUTBOUND | DTEMPLATE |
| m_TIMELYCARE_OUTBOUND_GENERATE | DTEMPLATE |
| m_TimleyCare_SFTP | DTEMPLATE |

---

### Taskflow: tf_RECEPTION_STG_HUB

**Project Path**: `Explore/Third Party Data/Taskflows`

#### Mapping Tasks (MTT)

##### mt_RECEPTIONIST_CONTACT

**Basic Information:**
- **Task Name**: mt_RECEPTIONIST_CONTACT
- **Mapping Reference**: 38pk9a86uEmliaVYBrCBCQ
- **Operation Types**: Upsert

**Targets:**
- **Target 1**: Tgt_ThirdpartyHub_RECEPTIONIST_CONTACT
  - Connection: 9IvOPhcp6ezgaEdrAZb4Ol
  - Object: RECEPTIONIST_CONTACT
  - Operation: Upsert

---

##### mt_RECEPTION_LOCATION

**Basic Information:**
- **Task Name**: mt_RECEPTION_LOCATION
- **Mapping Reference**: 58uBNwG0OB0bCTN3iklEIi
- **Operation Types**: Upsert

**Targets:**
- **Target 1**: Tgt_RECEPTION_LOCATION_Upsert
  - Connection: 9IvOPhcp6ezgaEdrAZb4Ol
  - Object: RECEPTION_LOCATION
  - Operation: Upsert

---

#### Connections Used

| Connection Name | Type |
|---|---|
| cn_File_Processor_Upload_TimelyCare | Connection |
| ff_NAS | Connection |
| ff_TimelyCare | Connection |
| SVC_Colleague_Stage | Connection |
| svc_DW_CORP | Connection |
| SVC_ERP_Hub | Connection |
| svc_ThirdpartyData_Hub | Connection |
| SVC_ThirdPartydata_stage | Connection |

---

## Cross-Taskflow Analysis

### Shared Connections

| Connection | Used by Taskflows | Usage Count |
|---|---|---|
| cn_File_Processor_Upload_TimelyCare | Tf_Soft_Delete_Records, tf_TimleyCare, tf_TimleyCare_Delta, tf_RECEPTION_STG_HUB | 4 |
| ff_NAS | Tf_Soft_Delete_Records, tf_TimleyCare, tf_TimleyCare_Delta, tf_RECEPTION_STG_HUB | 4 |
| ff_TimelyCare | Tf_Soft_Delete_Records, tf_TimleyCare, tf_TimleyCare_Delta, tf_RECEPTION_STG_HUB | 4 |
| SVC_Colleague_Stage | Tf_Soft_Delete_Records, tf_TimleyCare, tf_TimleyCare_Delta, tf_RECEPTION_STG_HUB | 4 |
| svc_DW_CORP | Tf_Soft_Delete_Records, tf_TimleyCare, tf_TimleyCare_Delta, tf_RECEPTION_STG_HUB | 4 |
| SVC_ERP_Hub | Tf_Soft_Delete_Records, tf_TimleyCare, tf_TimleyCare_Delta, tf_RECEPTION_STG_HUB | 4 |
| svc_ThirdpartyData_Hub | Tf_Soft_Delete_Records, tf_TimleyCare, tf_TimleyCare_Delta, tf_RECEPTION_STG_HUB | 4 |
| SVC_ThirdPartydata_stage | Tf_Soft_Delete_Records, tf_TimleyCare, tf_TimleyCare_Delta, tf_RECEPTION_STG_HUB | 4 |

---
*Report generated by IICS Job Analyzer - Multi-Taskflow Edition*