# IICS Job Analysis Report - Multi-Taskflow Export

## Job Overview

- **Job Export Name**: job-1754455944289
- **Source Organization**: ACC *TEST*
- **Total Objects**: 102
- **Total Taskflows**: 12
- **Analysis Date**: 2025-08-07 10:48:23

## Job Summary Statistics

- **Total MTT Tasks**: 75
- **Unique Connections**: 11
- **Total Data Templates**: 38

## Taskflow Overview

| Taskflow Name | Project Path | MTT Tasks | Connections | Templates |
|---|---|---|---|---|
| tf_WD_ACADEMIC_APPOINTEE | Explore/ERP Hub/TaskFlows | 3 | 11 | 1 |
| tf_WD_JOB_PROFILES | Explore/ERP Hub/TaskFlows | 4 | 11 | 2 |
| tf_WD_LOCATIONS | Explore/ERP Hub/TaskFlows | 3 | 11 | 1 |
| tf_WD_ORGANIZATIONS | Explore/ERP Hub/TaskFlows | 4 | 11 | 2 |
| tf_WD_WORKER | Explore/ERP Hub/TaskFlows | 13 | 11 | 1 |
| tf_WD_WORKER_COMPENSATION_DATA_PLUS_BENEFIT_ENROLLMENTS_ELIGIBILITY | Explore/ERP Hub/TaskFlows | 7 | 11 | 1 |
| tf_WD_WORKER_PAYROLL_RESULT_LINE | Explore/ERP Hub/TaskFlows | 4 | 11 | 2 |
| tf_WD_Worker_Qualifications | Explore/ERP Hub/TaskFlows | 5 | 11 | 1 |
| tf_WD_WORK_SCHEDULE_CALENDARS | Explore/ERP Hub/TaskFlows | 5 | 11 | 2 |
| tf_WORKDAY_MASTER | Explore/ERP Hub/TaskFlows | 0 | 11 | 0 |
| tf_WD_POSITION | Explore/ERP Hub/WorkDay | 24 | 11 | 22 |
| tf_Vector_Daily | Explore/OutBound_Data/Vector | 3 | 11 | 3 |

## Detailed Taskflow Analysis

### Taskflow: tf_WD_ACADEMIC_APPOINTEE

**Project Path**: `Explore/ERP Hub/TaskFlows`

#### Mapping Tasks (MTT)

##### mt_ACADEMIC_APPOINTEE

**Basic Information:**
- **Task Name**: mt_ACADEMIC_APPOINTEE
- **Mapping Reference**: gogylEO466bi9fgCM7vbcK
- **Operation Types**: Insert

**Targets:**
- **Target 1**: tgt_Academic_Appointee
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: Academic_Appointee
  - Operation: Insert

---

##### mt_WORKDAY_UPDATE_TIMESTAMP_END

**Basic Information:**
- **Task Name**: mt_WORKDAY_UPDATE_TIMESTAMP_END
- **Mapping Reference**: idgVEgOhzkakW1mXIXsAYN
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_mapping_name
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: DUMMY_src_mapping_name
  - Schema: 
  - Filter: `mapping_name='$$mapping_name'`

**Targets:**
- **Target 1**: tgt_Workday_Timestamp_Control_table
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: LOAD_DATE_CONTROL
  - Operation: Upsert

---

##### mt_WORKDAY_UPDATE_TIMESTAMP_START

**Basic Information:**
- **Task Name**: mt_WORKDAY_UPDATE_TIMESTAMP_START
- **Mapping Reference**: ahhTvYbWjAKlVRNjWBOFUJ
- **Operation Types**: Insert, Upsert

**Sources:**
- **Source 1**: Source
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: DUMMY_Source
  - Schema: 
  - Filter: `mapping_name='$$mapping_name'`

**Targets:**
- **Target 1**: db_target
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: LOAD_DATE_CONTROL
  - Operation: Upsert
- **Target 2**: ff_target
  - Connection: fdtLkJfC7MshWQ81Nzv88G
  - Object: file_name
  - Operation: Insert

---

#### Connections Used

| Connection Name | Type |
|---|---|
| cn_File_Processor_Upload_Vector | Connection |
| ff_Vector | Connection |
| ff_workday_param | Connection |
| svc_DW_CORP | Connection |
| svc_DW_CORP_Apps | Connection |
| SVC_ERP_Hub | Connection |
| svc_ETL | Connection |
| svc_Workday_Connector_Recruiting_austincc | Connection |
| svc_Workday_Human_Resources_austincc | Connection |
| svc_Workday_Payroll_austincc | Connection |
| svc_WorkDay_Stage | Connection |

#### Data Templates

| Template Name | Type |
|---|---|
| m_ACADEMIC_APPOINTEE | DTEMPLATE |

---

### Taskflow: tf_WD_JOB_PROFILES

**Project Path**: `Explore/ERP Hub/TaskFlows`

#### Mapping Tasks (MTT)

##### mt_JOB_PROFILE

**Basic Information:**
- **Task Name**: mt_JOB_PROFILE
- **Mapping Reference**: 89Pjq6n1WU0kx7vM8CWMk0
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_JOB_PROFILE
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_JOB_PROFILE
  - Schema: WORKDAY_STAGE

**Targets:**
- **Target 1**: tgt_DW_CORP_JOB_PROFILE
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: JOB_PROFILE
  - Operation: Upsert
- **Target 2**: tgt_erphub_JOB_PROFILE
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: JOB_PROFILE
  - Operation: Upsert

---

##### mt_WD_JOB_PROFILES

**Basic Information:**
- **Task Name**: mt_WD_JOB_PROFILES
- **Mapping Reference**: lAZA7RWpr4HlpA8nd1CYMg
- **Operation Types**: Insert

**Targets:**
- **Target 1**: tgt_WD_Job_Profiles
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Job_Profiles
  - Operation: Insert

---

##### mt_WORKDAY_UPDATE_TIMESTAMP_END

**Basic Information:**
- **Task Name**: mt_WORKDAY_UPDATE_TIMESTAMP_END
- **Mapping Reference**: idgVEgOhzkakW1mXIXsAYN
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_mapping_name
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: DUMMY_src_mapping_name
  - Schema: 
  - Filter: `mapping_name='$$mapping_name'`

**Targets:**
- **Target 1**: tgt_Workday_Timestamp_Control_table
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: LOAD_DATE_CONTROL
  - Operation: Upsert

---

##### mt_WORKDAY_UPDATE_TIMESTAMP_START

**Basic Information:**
- **Task Name**: mt_WORKDAY_UPDATE_TIMESTAMP_START
- **Mapping Reference**: ahhTvYbWjAKlVRNjWBOFUJ
- **Operation Types**: Insert, Upsert

**Sources:**
- **Source 1**: Source
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: DUMMY_Source
  - Schema: 
  - Filter: `mapping_name='$$mapping_name'`

**Targets:**
- **Target 1**: db_target
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: LOAD_DATE_CONTROL
  - Operation: Upsert
- **Target 2**: ff_target
  - Connection: fdtLkJfC7MshWQ81Nzv88G
  - Object: file_name
  - Operation: Insert

---

#### Connections Used

| Connection Name | Type |
|---|---|
| cn_File_Processor_Upload_Vector | Connection |
| ff_Vector | Connection |
| ff_workday_param | Connection |
| svc_DW_CORP | Connection |
| svc_DW_CORP_Apps | Connection |
| SVC_ERP_Hub | Connection |
| svc_ETL | Connection |
| svc_Workday_Connector_Recruiting_austincc | Connection |
| svc_Workday_Human_Resources_austincc | Connection |
| svc_Workday_Payroll_austincc | Connection |
| svc_WorkDay_Stage | Connection |

#### Data Templates

| Template Name | Type |
|---|---|
| m_JOB_PROFILE | DTEMPLATE |
| m_WD_JOB_PROFILES | DTEMPLATE |

---

### Taskflow: tf_WD_LOCATIONS

**Project Path**: `Explore/ERP Hub/TaskFlows`

#### Mapping Tasks (MTT)

##### mt_WD_LOCATIONS

**Basic Information:**
- **Task Name**: mt_WD_LOCATIONS
- **Mapping Reference**: hWhGyjYerIud4Ebbev6I0k
- **Operation Types**: Insert

**Targets:**
- **Target 1**: tgt_WD_Locations
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Locations
  - Operation: Insert

---

##### mt_WORKDAY_UPDATE_TIMESTAMP_END

**Basic Information:**
- **Task Name**: mt_WORKDAY_UPDATE_TIMESTAMP_END
- **Mapping Reference**: idgVEgOhzkakW1mXIXsAYN
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_mapping_name
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: DUMMY_src_mapping_name
  - Schema: 
  - Filter: `mapping_name='$$mapping_name'`

**Targets:**
- **Target 1**: tgt_Workday_Timestamp_Control_table
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: LOAD_DATE_CONTROL
  - Operation: Upsert

---

##### mt_WORKDAY_UPDATE_TIMESTAMP_START

**Basic Information:**
- **Task Name**: mt_WORKDAY_UPDATE_TIMESTAMP_START
- **Mapping Reference**: ahhTvYbWjAKlVRNjWBOFUJ
- **Operation Types**: Insert, Upsert

**Sources:**
- **Source 1**: Source
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: DUMMY_Source
  - Schema: 
  - Filter: `mapping_name='$$mapping_name'`

**Targets:**
- **Target 1**: db_target
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: LOAD_DATE_CONTROL
  - Operation: Upsert
- **Target 2**: ff_target
  - Connection: fdtLkJfC7MshWQ81Nzv88G
  - Object: file_name
  - Operation: Insert

---

#### Connections Used

| Connection Name | Type |
|---|---|
| cn_File_Processor_Upload_Vector | Connection |
| ff_Vector | Connection |
| ff_workday_param | Connection |
| svc_DW_CORP | Connection |
| svc_DW_CORP_Apps | Connection |
| SVC_ERP_Hub | Connection |
| svc_ETL | Connection |
| svc_Workday_Connector_Recruiting_austincc | Connection |
| svc_Workday_Human_Resources_austincc | Connection |
| svc_Workday_Payroll_austincc | Connection |
| svc_WorkDay_Stage | Connection |

#### Data Templates

| Template Name | Type |
|---|---|
| m_WD_LOCATIONS | DTEMPLATE |

---

### Taskflow: tf_WD_ORGANIZATIONS

**Project Path**: `Explore/ERP Hub/TaskFlows`

#### Mapping Tasks (MTT)

##### mt_ORGANIZATION

**Basic Information:**
- **Task Name**: mt_ORGANIZATION
- **Mapping Reference**: eBSH22fp9kDipn6P3PQwy2
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: Source
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_Source
  - Schema: 
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)`

**Targets:**
- **Target 1**: Target
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: ORGANIZATION
  - Operation: Upsert
- **Target 2**: Target1
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: ORGANIZATION
  - Operation: Upsert

---

##### mt_WD_ORGANIZATIONS

**Basic Information:**
- **Task Name**: mt_WD_ORGANIZATIONS
- **Mapping Reference**: asCq6uEW2yObfSiC2bBwOO
- **Operation Types**: Insert

**Targets:**
- **Target 1**: WD_ORGANIZATIONS
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Organizations
  - Operation: Insert

---

##### mt_WORKDAY_UPDATE_TIMESTAMP_END

**Basic Information:**
- **Task Name**: mt_WORKDAY_UPDATE_TIMESTAMP_END
- **Mapping Reference**: idgVEgOhzkakW1mXIXsAYN
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_mapping_name
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: DUMMY_src_mapping_name
  - Schema: 
  - Filter: `mapping_name='$$mapping_name'`

**Targets:**
- **Target 1**: tgt_Workday_Timestamp_Control_table
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: LOAD_DATE_CONTROL
  - Operation: Upsert

---

##### mt_WORKDAY_UPDATE_TIMESTAMP_START

**Basic Information:**
- **Task Name**: mt_WORKDAY_UPDATE_TIMESTAMP_START
- **Mapping Reference**: ahhTvYbWjAKlVRNjWBOFUJ
- **Operation Types**: Insert, Upsert

**Sources:**
- **Source 1**: Source
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: DUMMY_Source
  - Schema: 
  - Filter: `mapping_name='$$mapping_name'`

**Targets:**
- **Target 1**: db_target
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: LOAD_DATE_CONTROL
  - Operation: Upsert
- **Target 2**: ff_target
  - Connection: fdtLkJfC7MshWQ81Nzv88G
  - Object: file_name
  - Operation: Insert

---

#### Connections Used

| Connection Name | Type |
|---|---|
| cn_File_Processor_Upload_Vector | Connection |
| ff_Vector | Connection |
| ff_workday_param | Connection |
| svc_DW_CORP | Connection |
| svc_DW_CORP_Apps | Connection |
| SVC_ERP_Hub | Connection |
| svc_ETL | Connection |
| svc_Workday_Connector_Recruiting_austincc | Connection |
| svc_Workday_Human_Resources_austincc | Connection |
| svc_Workday_Payroll_austincc | Connection |
| svc_WorkDay_Stage | Connection |

#### Data Templates

| Template Name | Type |
|---|---|
| m_ORGANIZATION | DTEMPLATE |
| m_WD_ORGANIZATIONS | DTEMPLATE |

---

### Taskflow: tf_WD_WORKER

**Project Path**: `Explore/ERP Hub/TaskFlows`

#### Mapping Tasks (MTT)

##### mt_ADDRESS_MASTER

**Basic Information:**
- **Task Name**: mt_ADDRESS_MASTER
- **Mapping Reference**: hDtRO3PK7MacLoPCwR10IZ
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_ADDRESS_MASTER
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_ADDRESS_MASTER
  - Schema: Workday_Stage
  - Filter: `wid is not null
	and  LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)
--where address like '50 Kilgraston Road&#xa;Bridge of Weir&#xa;Renfrewshire&#xa;PA11 3DP&#xa;United K...`

**Targets:**
- **Target 1**: tgt_ADDRESS_MASTER_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: ADDRESS_MASTER
  - Operation: Upsert
- **Target 2**: tgt_ADDRESS_MASTER_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: ADDRESS_MASTER
  - Operation: Upsert

---

##### mt_EMPLOYEE_EMPLOYMENT

**Basic Information:**
- **Task Name**: mt_EMPLOYEE_EMPLOYMENT
- **Mapping Reference**: 1cJJ8mNvuIGbs8TtmUYmG8
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_WD_Worker
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_WD_Worker
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)and
patindex('%[0-9]%',Worker_ID )<2 and LEN(Worker_ID)>6

) a where active_rec=1`

**Targets:**
- **Target 1**: tgt_DW_CORP_WORKER_EMPLOYMENT
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: EMPLOYEE_EMPLOYMENT
  - Operation: Upsert
- **Target 2**: tgt_erphub_WORKER_EMPLOYMENT
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EMPLOYEE_EMPLOYMENT
  - Operation: Upsert

---

##### mt_EMPLOYEE_MANAGER

**Basic Information:**
- **Task Name**: mt_EMPLOYEE_MANAGER
- **Mapping Reference**: 2ZQUMlJG5Jzc2XKKt2PRSV
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_WD_WD_Worker_Manager
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_WD_WD_Worker_Manager
  - Schema: Workday_Stage
  - Filter: `len(SUBSTRING(FK_Worker, PATINDEX('%[0-9]%', FK_Worker), PATINDEX('%[0-9][^0-9]%', FK_Worker + 't') - PATINDEX('%[0-9]%', FK_Worker) + 1))>6
  and LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GET...`

**Targets:**
- **Target 1**: tgt_DW_CORP_EMPLOYEE_MANAGER
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: EMPLOYEE_MANAGER
  - Operation: Upsert
- **Target 2**: tgt_erphub_EMPLOYEE_MANAGER
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EMPLOYEE_MANAGER
  - Operation: Upsert

---

##### mt_EMPLOYEE_ORGANIZATION

**Basic Information:**
- **Task Name**: mt_EMPLOYEE_ORGANIZATION
- **Mapping Reference**: lOT05QQ3VK6lGns9D6Pjka
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_EMPLOYEE_ORGANIZATION
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_EMPLOYEE_ORGANIZATION
  - Schema: Workday_Stage
  - Filter: `len(SUBSTRING(FK_Worker, PATINDEX('%[0-9]%', FK_Worker), PATINDEX('%[0-9][^0-9]%', FK_Worker + 't') - PATINDEX('%[0-9]%', FK_Worker) + 1))>6 and
LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDA...`

**Targets:**
- **Target 1**: tgt_EMPLOYEE_ORGANIZATION_dw_corp
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: EMPLOYEE_ORGANIZATION
  - Operation: Upsert
- **Target 2**: tgt_EMPLOYEE_ORGANIZATION_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EMPLOYEE_ORGANIZATION
  - Operation: Upsert

---

##### mt_PERSON_ADDRESS

**Basic Information:**
- **Task Name**: mt_PERSON_ADDRESS
- **Mapping Reference**: g7rDalP6xcgcxOo2yd0Rwc
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_PERSON_ADDRESS
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_PERSON_ADDRESS
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)`

**Targets:**
- **Target 1**: Tgt_PERSON_ADDRESS_dw_corp
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: PERSON_ADDRESS
  - Operation: Upsert
- **Target 2**: Tgt_PERSON_ADDRESS_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_ADDRESS
  - Operation: Upsert

**Lookups:**
- **Lookup 1**: LKP_ERP_HUB_ADDRESS_MASTER
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: ADDRESS_MASTER
  - Cache Type: Cached

---

##### mt_PERSON_EMAIL

**Basic Information:**
- **Task Name**: mt_PERSON_EMAIL
- **Mapping Reference**: a5okIzDoP9ZewcUdNe0vm4
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_PERSON_EMAIL
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_PERSON_EMAIL
  - Schema: 
  - Filter: `patindex('%[0-9]%',FK_Worker )<2
--and LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)`

**Targets:**
- **Target 1**: tgt_PERSON_EMAIL_dw_corp
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: PERSON_EMAIL
  - Operation: Upsert
- **Target 2**: tgt_PERSON_EMAIL_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_EMAIL
  - Operation: Upsert

---

##### mt_PERSON_PHONE

**Basic Information:**
- **Task Name**: mt_PERSON_PHONE
- **Mapping Reference**: 7nVmsX2JQijdnXwmSfRD2u
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_PERSON_PHONE
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_PERSON_PHONE
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)
  )A
  )B where B.row_num=1`

**Targets:**
- **Target 1**: tgt_PERSON_PHONE_dw_corp
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: PERSON_PHONE
  - Operation: Upsert
- **Target 2**: tgt_PERSON_PHONE_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_PHONE
  - Operation: Upsert

---

##### mt_PERSON_STEP_1

**Basic Information:**
- **Task Name**: mt_PERSON_STEP_1
- **Mapping Reference**: 4Mk3RjWr3pddIoZcNFcuwi
- **Operation Types**: Update

**Sources:**
- **Source 1**: SRC_Workdaystage_Worker
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_SRC_Workdaystage_Worker
  - Schema: 
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)
--where worker_id in ('0001258', '0001295', '0001315', '0001335', '0001487', '0001549')

) a where active_rec=1
and --LEN(a....`

**Targets:**
- **Target 1**: DW_CORP_UPD_PERSON_ID
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON
  - Operation: Update
- **Target 2**: ERP_HUB_UPD_PERSON_ID
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON
  - Operation: Update

**Lookups:**
- **Lookup 1**: Lkp_ERPHUB_Person_by_Personid
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON
  - Cache Type: Cached

---

##### mt_PERSON_STEP_2

**Basic Information:**
- **Task Name**: mt_PERSON_STEP_2
- **Mapping Reference**: 5pxY0w88YSphpfv8xWzocH
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: SRC_Workdaystage_Worker
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_SRC_Workdaystage_Worker
  - Schema: 
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)
--where worker_id in ('0001258', '0001295', '0001315', '0001335', '0001487', '0001549')

) a where active_rec=1
and --LEN(a....`

**Targets:**
- **Target 1**: DW_CORP_Upsert_by_ERP_ID
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON
  - Operation: Upsert
- **Target 2**: ERP_HUB_Upsert_by_ERP_ID
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON
  - Operation: Upsert

**Lookups:**
- **Lookup 1**: Lkp_ERPHUB_Person_by_Personid
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON
  - Cache Type: Cached

---

##### mt_WD_STG_WORKERS

**Basic Information:**
- **Task Name**: mt_WD_STG_WORKERS
- **Mapping Reference**: 1WqVBXyDvQrcQzffM5dLuX
- **Operation Types**: Insert

**Targets:**
- **Target 1**: WD_Worker
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker
  - Operation: Insert
- **Target 2**: WD_Worker_Address
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Address
  - Operation: Insert
- **Target 3**: WD_Worker_Email
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Email
  - Operation: Insert
- **Target 4**: WD_Worker_Job_Classification
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Job_Classification
  - Operation: Insert
- **Target 5**: WD_Worker_Manager
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Manager
  - Operation: Insert
- **Target 6**: WD_Worker_Organization
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Organization
  - Operation: Insert
- **Target 7**: WD_Worker_Organization_Role
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Organization_Role
  - Operation: Insert
- **Target 8**: WD_Worker_Phone
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Phone
  - Operation: Insert
- **Target 9**: WD_Worker_Race
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Race
  - Operation: Insert
- **Target 10**: tgt_WD_Worker_Web_Address
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Web_Address
  - Operation: Insert

---

##### mt_WD_Worker_Qualifications

**Basic Information:**
- **Task Name**: mt_WD_Worker_Qualifications
- **Mapping Reference**: 3K9GErY1H8ykLrVi0RNxk9
- **Operation Types**: Insert

**Targets:**
- **Target 1**: tgt_WD_Worker_Certification
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Certification
  - Operation: Insert
- **Target 2**: tgt_WD_Worker_Education
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Education
  - Operation: Insert
- **Target 3**: tgt_WD_Worker_Language
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Language
  - Operation: Insert
- **Target 4**: tgt_WD_Worker_Skills
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Skills
  - Operation: Insert

---

##### mt_WORKDAY_UPDATE_TIMESTAMP_END

**Basic Information:**
- **Task Name**: mt_WORKDAY_UPDATE_TIMESTAMP_END
- **Mapping Reference**: idgVEgOhzkakW1mXIXsAYN
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_mapping_name
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: DUMMY_src_mapping_name
  - Schema: 
  - Filter: `mapping_name='$$mapping_name'`

**Targets:**
- **Target 1**: tgt_Workday_Timestamp_Control_table
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: LOAD_DATE_CONTROL
  - Operation: Upsert

---

##### mt_WORKDAY_UPDATE_TIMESTAMP_START

**Basic Information:**
- **Task Name**: mt_WORKDAY_UPDATE_TIMESTAMP_START
- **Mapping Reference**: ahhTvYbWjAKlVRNjWBOFUJ
- **Operation Types**: Insert, Upsert

**Sources:**
- **Source 1**: Source
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: DUMMY_Source
  - Schema: 
  - Filter: `mapping_name='$$mapping_name'`

**Targets:**
- **Target 1**: db_target
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: LOAD_DATE_CONTROL
  - Operation: Upsert
- **Target 2**: ff_target
  - Connection: fdtLkJfC7MshWQ81Nzv88G
  - Object: file_name
  - Operation: Insert

---

#### Connections Used

| Connection Name | Type |
|---|---|
| cn_File_Processor_Upload_Vector | Connection |
| ff_Vector | Connection |
| ff_workday_param | Connection |
| svc_DW_CORP | Connection |
| svc_DW_CORP_Apps | Connection |
| SVC_ERP_Hub | Connection |
| svc_ETL | Connection |
| svc_Workday_Connector_Recruiting_austincc | Connection |
| svc_Workday_Human_Resources_austincc | Connection |
| svc_Workday_Payroll_austincc | Connection |
| svc_WorkDay_Stage | Connection |

#### Data Templates

| Template Name | Type |
|---|---|
| m_WD_Worker_Qualifications | DTEMPLATE |

---

### Taskflow: tf_WD_WORKER_COMPENSATION_DATA_PLUS_BENEFIT_ENROLLMENTS_ELIGIBILITY

**Project Path**: `Explore/ERP Hub/TaskFlows`

#### Mapping Tasks (MTT)

##### mt_EMPLOYEE_ADDITIONAL_BENEFIT

**Basic Information:**
- **Task Name**: mt_EMPLOYEE_ADDITIONAL_BENEFIT
- **Mapping Reference**: 3qeykKKQ94bfUxHfLmJZa9
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_EMPLOYEE_ADDITIONAL_BENEFIT
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_EMPLOYEE_ADDITIONAL_BENEFIT
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)
)a
	where LEN(a.Worker_ID)>6`

**Targets:**
- **Target 1**: tgt_EMPLOYEE_ADDITIONAL_BENEFIT_dw_corp
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: EMPLOYEE_ADDITIONAL_BENEFIT
  - Operation: Upsert
- **Target 2**: tgt_EMPLOYEE_ADDITIONAL_BENEFIT_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EMPLOYEE_ADDITIONAL_BENEFIT
  - Operation: Upsert

---

##### mt_EMPLOYEE_BENEFIT_HEALTHCARE

**Basic Information:**
- **Task Name**: mt_EMPLOYEE_BENEFIT_HEALTHCARE
- **Mapping Reference**: 5jnjWlKt6degAKm94H2MeB
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_EMPLOYEE_BENEFIT_HEALTHCARE
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_EMPLOYEE_BENEFIT_HEALTHCARE
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)
) a
where a.EMPLOYEE_ID > 6`

**Targets:**
- **Target 1**: tgt_DW_CORP_EMPLOYEE_BENEFIT_HEALTHCARE
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: EMPLOYEE_BENEFIT_HEALTHCARE
  - Operation: Upsert
- **Target 2**: tgt_erphub_EMPLOYEE_BENEFIT_HEALTHCARE
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EMPLOYEE_BENEFIT_HEALTHCARE
  - Operation: Upsert

---

##### mt_EMPLOYEE_BENEFIT_INSURANCE

**Basic Information:**
- **Task Name**: mt_EMPLOYEE_BENEFIT_INSURANCE
- **Mapping Reference**: 9PZsELDdL48l8vop98lsIJ
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_EMPLOYEE_BENEFIT_INSURANCE
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_EMPLOYEE_BENEFIT_INSURANCE
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)
) a
where a.Worker_ID > 6`

**Targets:**
- **Target 1**: tgt_EMPLOYEE_BENEFIT_INSURANCE_dw_corp
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: EMPLOYEE_BENEFIT_INSURANCE
  - Operation: Upsert
- **Target 2**: tgt_EMPLOYEE_BENEFIT_INSURANCE_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EMPLOYEE_BENEFIT_INSURANCE
  - Operation: Upsert

---

##### mt_EMPLOYEE_BENEFIT_RETIREMENT_SAVINGS

**Basic Information:**
- **Task Name**: mt_EMPLOYEE_BENEFIT_RETIREMENT_SAVINGS
- **Mapping Reference**: 4iqgBoqmuwJiKQyzBN2JSe
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_EMPLOYEE_WORK_SCHEDULE_ASSIGNMENT
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_EMPLOYEE_WORK_SCHEDULE_ASSIGNMENT
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)
) a
where a.EMPLOYEE_ID > 6`

**Targets:**
- **Target 1**: tgt_DW_CORP_EMPLOYEE_BENEFIT_RETIREMENT_SAVINGS
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: EMPLOYEE_BENEFIT_RETIREMENT_SAVINGS
  - Operation: Upsert
- **Target 2**: tgt_erphub_EMPLOYEE_BENEFIT_RETIREMENT_SAVINGS
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EMPLOYEE_BENEFIT_RETIREMENT_SAVINGS
  - Operation: Upsert

---

##### mt_WORKDAY_UPDATE_TIMESTAMP_END

**Basic Information:**
- **Task Name**: mt_WORKDAY_UPDATE_TIMESTAMP_END
- **Mapping Reference**: idgVEgOhzkakW1mXIXsAYN
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_mapping_name
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: DUMMY_src_mapping_name
  - Schema: 
  - Filter: `mapping_name='$$mapping_name'`

**Targets:**
- **Target 1**: tgt_Workday_Timestamp_Control_table
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: LOAD_DATE_CONTROL
  - Operation: Upsert

---

##### mt_WORKDAY_UPDATE_TIMESTAMP_START

**Basic Information:**
- **Task Name**: mt_WORKDAY_UPDATE_TIMESTAMP_START
- **Mapping Reference**: ahhTvYbWjAKlVRNjWBOFUJ
- **Operation Types**: Insert, Upsert

**Sources:**
- **Source 1**: Source
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: DUMMY_Source
  - Schema: 
  - Filter: `mapping_name='$$mapping_name'`

**Targets:**
- **Target 1**: db_target
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: LOAD_DATE_CONTROL
  - Operation: Upsert
- **Target 2**: ff_target
  - Connection: fdtLkJfC7MshWQ81Nzv88G
  - Object: file_name
  - Operation: Insert

---

##### mt_WORKER_COMPENSATION_DATA_PLUS_BENEFIT_ENROLLMENTS_ELIGIBILITY

**Basic Information:**
- **Task Name**: mt_WORKER_COMPENSATION_DATA_PLUS_BENEFIT_ENROLLMENTS_ELIGIBILITY
- **Mapping Reference**: 5yh57fTtcIJd01Gw2U87Ml
- **Operation Types**: Insert

**Targets:**
- **Target 1**: tgt_WD_Worker_Benefit_Eligibility_Data
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Benefit_Eligibility_Data
  - Operation: Insert
- **Target 2**: tgt_WD_Worker_Benefit_Enrollment_Additional_Benefits_Coverage_Data
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Benefit_Enrollment_Additional_Benefits_Coverage_Data
  - Operation: Insert
- **Target 3**: tgt_WD_Worker_Benefit_Enrollment_Health_Care_Data
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Benefit_Enrollment_Health_Care_Data
  - Operation: Insert
- **Target 4**: tgt_WD_Worker_Benefit_Enrollment_Insurance_Coverage_Data
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Benefit_Enrollment_Insurance_Coverage_Data
  - Operation: Insert
- **Target 5**: tgt_WD_Worker_Benefit_Enrollment_Retirement_Savings_Coverage_Data
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Benefit_Enrollment_Retirement_Savings_Coverage_Data
  - Operation: Insert
- **Target 6**: tgt_WD_Worker_Compensation_Data
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Compensation_Data
  - Operation: Insert

---

#### Connections Used

| Connection Name | Type |
|---|---|
| cn_File_Processor_Upload_Vector | Connection |
| ff_Vector | Connection |
| ff_workday_param | Connection |
| svc_DW_CORP | Connection |
| svc_DW_CORP_Apps | Connection |
| SVC_ERP_Hub | Connection |
| svc_ETL | Connection |
| svc_Workday_Connector_Recruiting_austincc | Connection |
| svc_Workday_Human_Resources_austincc | Connection |
| svc_Workday_Payroll_austincc | Connection |
| svc_WorkDay_Stage | Connection |

#### Data Templates

| Template Name | Type |
|---|---|
| m_WORKER_COMPENSATION_DATA_PLUS_BENEFIT_ENROLLMENTS_ELIGIBILITY | DTEMPLATE |

---

### Taskflow: tf_WD_WORKER_PAYROLL_RESULT_LINE

**Project Path**: `Explore/ERP Hub/TaskFlows`

#### Mapping Tasks (MTT)

##### mt_PAYROLL_RESULT_LINE

**Basic Information:**
- **Task Name**: mt_PAYROLL_RESULT_LINE
- **Mapping Reference**: 3ghWqq6SJJ3b24iSdNXQcK
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_SCHEDULE_PATTERN_WEEK
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DUMMY_src_SCHEDULE_PATTERN_WEEK
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime) and
LEN(SUBSTRING(worker_employee_id, PATINDEX('%[0-9]%', worker_employee_id), PATINDEX('%[0-9][^0-9]%', worker_employee_id ...`

**Targets:**
- **Target 1**: tgt_DW_CORP_PAYROLL_RESULT_LINE
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: PAYROLL_RESULT_LINE
  - Operation: Upsert
- **Target 2**: tgt_ERP_HUB_PAYROLL_RESULT_LINE1
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PAYROLL_RESULT_LINE
  - Operation: Upsert

**Lookups:**
- **Lookup 1**: lkp_organization
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: ORGANIZATION
  - Cache Type: Cached

---

##### mt_WORKDAY_UPDATE_TIMESTAMP_END

**Basic Information:**
- **Task Name**: mt_WORKDAY_UPDATE_TIMESTAMP_END
- **Mapping Reference**: idgVEgOhzkakW1mXIXsAYN
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_mapping_name
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: DUMMY_src_mapping_name
  - Schema: 
  - Filter: `mapping_name='$$mapping_name'`

**Targets:**
- **Target 1**: tgt_Workday_Timestamp_Control_table
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: LOAD_DATE_CONTROL
  - Operation: Upsert

---

##### mt_WORKDAY_UPDATE_TIMESTAMP_START

**Basic Information:**
- **Task Name**: mt_WORKDAY_UPDATE_TIMESTAMP_START
- **Mapping Reference**: ahhTvYbWjAKlVRNjWBOFUJ
- **Operation Types**: Insert, Upsert

**Sources:**
- **Source 1**: Source
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: DUMMY_Source
  - Schema: 
  - Filter: `mapping_name='$$mapping_name'`

**Targets:**
- **Target 1**: db_target
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: LOAD_DATE_CONTROL
  - Operation: Upsert
- **Target 2**: ff_target
  - Connection: fdtLkJfC7MshWQ81Nzv88G
  - Object: file_name
  - Operation: Insert

---

##### mt_WORKER_PAYROLL_RESULT_LINE

**Basic Information:**
- **Task Name**: mt_WORKER_PAYROLL_RESULT_LINE
- **Mapping Reference**: lCxVnpywPuGk21LWPLdxK6
- **Operation Types**: Insert

**Targets:**
- **Target 1**: payroll_result_line
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: payroll_result_line
  - Operation: Insert

---

#### Connections Used

| Connection Name | Type |
|---|---|
| cn_File_Processor_Upload_Vector | Connection |
| ff_Vector | Connection |
| ff_workday_param | Connection |
| svc_DW_CORP | Connection |
| svc_DW_CORP_Apps | Connection |
| SVC_ERP_Hub | Connection |
| svc_ETL | Connection |
| svc_Workday_Connector_Recruiting_austincc | Connection |
| svc_Workday_Human_Resources_austincc | Connection |
| svc_Workday_Payroll_austincc | Connection |
| svc_WorkDay_Stage | Connection |

#### Data Templates

| Template Name | Type |
|---|---|
| m_PAYROLL_RESULT_LINE | DTEMPLATE |
| m_WORKER_PAYROLL_RESULT_LINE | DTEMPLATE |

---

### Taskflow: tf_WD_Worker_Qualifications

**Project Path**: `Explore/ERP Hub/TaskFlows`

#### Mapping Tasks (MTT)

##### mt_EMPLOYEE_EDUCATION

**Basic Information:**
- **Task Name**: mt_EMPLOYEE_EDUCATION
- **Mapping Reference**: fB6gJ2iBHqohk5ff0XGlo7
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_EMPLOYEE_EDUCATION
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_EMPLOYEE_EDUCATION
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)
 and Worker_ID is NOT null and patindex('%[0-9]%',Worker_ID )<2 
 and  LEN(SUBSTRING(Worker_ID, PATINDEX('%[0-9]%', Worker_I...`

**Targets:**
- **Target 1**: tgt_DW_CORP_EMPLOYEE_EDUCATION
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: EMPLOYEE_EDUCATION
  - Operation: Upsert
- **Target 2**: tgt_erphub_EMPLOYEE_EDUCATION
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EMPLOYEE_EDUCATION
  - Operation: Upsert

---

##### mt_EMPLOYEE_SKILL

**Basic Information:**
- **Task Name**: mt_EMPLOYEE_SKILL
- **Mapping Reference**: 3FxpHslL67jlAn0QCnvmwH
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_EMPLOYEE_SKILL
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_EMPLOYEE_SKILL
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime) and 
 Worker_ID is NOT null and patindex('%[0-9]%',Worker_ID )<2 
 and  LEN(SUBSTRING(Worker_ID, PATINDEX('%[0-9]%', Worker_...`

**Targets:**
- **Target 1**: tgt_DW_CORP_EMPLOYEE_SKILL
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: EMPLOYEE_SKILL
  - Operation: Upsert
- **Target 2**: tgt_erphub_EMPLOYEE_SKILL
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EMPLOYEE_SKILL
  - Operation: Upsert

---

##### mt_WD_Worker_Qualifications

**Basic Information:**
- **Task Name**: mt_WD_Worker_Qualifications
- **Mapping Reference**: 3K9GErY1H8ykLrVi0RNxk9
- **Operation Types**: Insert

**Targets:**
- **Target 1**: tgt_WD_Worker_Certification
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Certification
  - Operation: Insert
- **Target 2**: tgt_WD_Worker_Education
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Education
  - Operation: Insert
- **Target 3**: tgt_WD_Worker_Language
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Language
  - Operation: Insert
- **Target 4**: tgt_WD_Worker_Skills
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Worker_Skills
  - Operation: Insert

---

##### mt_WORKDAY_UPDATE_TIMESTAMP_END

**Basic Information:**
- **Task Name**: mt_WORKDAY_UPDATE_TIMESTAMP_END
- **Mapping Reference**: idgVEgOhzkakW1mXIXsAYN
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_mapping_name
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: DUMMY_src_mapping_name
  - Schema: 
  - Filter: `mapping_name='$$mapping_name'`

**Targets:**
- **Target 1**: tgt_Workday_Timestamp_Control_table
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: LOAD_DATE_CONTROL
  - Operation: Upsert

---

##### mt_WORKDAY_UPDATE_TIMESTAMP_START

**Basic Information:**
- **Task Name**: mt_WORKDAY_UPDATE_TIMESTAMP_START
- **Mapping Reference**: ahhTvYbWjAKlVRNjWBOFUJ
- **Operation Types**: Insert, Upsert

**Sources:**
- **Source 1**: Source
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: DUMMY_Source
  - Schema: 
  - Filter: `mapping_name='$$mapping_name'`

**Targets:**
- **Target 1**: db_target
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: LOAD_DATE_CONTROL
  - Operation: Upsert
- **Target 2**: ff_target
  - Connection: fdtLkJfC7MshWQ81Nzv88G
  - Object: file_name
  - Operation: Insert

---

#### Connections Used

| Connection Name | Type |
|---|---|
| cn_File_Processor_Upload_Vector | Connection |
| ff_Vector | Connection |
| ff_workday_param | Connection |
| svc_DW_CORP | Connection |
| svc_DW_CORP_Apps | Connection |
| SVC_ERP_Hub | Connection |
| svc_ETL | Connection |
| svc_Workday_Connector_Recruiting_austincc | Connection |
| svc_Workday_Human_Resources_austincc | Connection |
| svc_Workday_Payroll_austincc | Connection |
| svc_WorkDay_Stage | Connection |

#### Data Templates

| Template Name | Type |
|---|---|
| m_WD_Worker_Qualifications | DTEMPLATE |

---

### Taskflow: tf_WD_WORK_SCHEDULE_CALENDARS

**Project Path**: `Explore/ERP Hub/TaskFlows`

#### Mapping Tasks (MTT)

##### mt_SCHEDULE_PATTERN_WEEK

**Basic Information:**
- **Task Name**: mt_SCHEDULE_PATTERN_WEEK
- **Mapping Reference**: 9vrdZFmKbamh4FWn3cPOqL
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_SCHEDULE_PATTERN_WEEK
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DUMMY_src_SCHEDULE_PATTERN_WEEK
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)`

**Targets:**
- **Target 1**: tgt_DW_CORP_SCHEDULE_PATTERN_WEEK
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: SCHEDULE_PATTERN_WEEK
  - Operation: Upsert
- **Target 2**: tgt_ERP_HUB_SCHEDULE_PATTERN_WEEK
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: SCHEDULE_PATTERN_WEEK
  - Operation: Upsert

---

##### mt_WORK_SCHEDULE_CALENDAR

**Basic Information:**
- **Task Name**: mt_WORK_SCHEDULE_CALENDAR
- **Mapping Reference**: 5kNH5u9hynleKSmV2H5hMh
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_SCHEDULE_PATTERN_WEEK
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DUMMY_src_SCHEDULE_PATTERN_WEEK
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)`

**Targets:**
- **Target 1**: tgt_DW_CORP_WORK_SCHEDULE_CALENDAR
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: WORK_SCHEDULE_CALENDAR
  - Operation: Upsert
- **Target 2**: tgt_ERP_HUB_WORK_SCHEDULE_CALENDAR
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: WORK_SCHEDULE_CALENDAR
  - Operation: Upsert

---

##### mt_WORKDAY_UPDATE_TIMESTAMP_END

**Basic Information:**
- **Task Name**: mt_WORKDAY_UPDATE_TIMESTAMP_END
- **Mapping Reference**: idgVEgOhzkakW1mXIXsAYN
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_mapping_name
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: DUMMY_src_mapping_name
  - Schema: 
  - Filter: `mapping_name='$$mapping_name'`

**Targets:**
- **Target 1**: tgt_Workday_Timestamp_Control_table
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: LOAD_DATE_CONTROL
  - Operation: Upsert

---

##### mt_WORKDAY_UPDATE_TIMESTAMP_START

**Basic Information:**
- **Task Name**: mt_WORKDAY_UPDATE_TIMESTAMP_START
- **Mapping Reference**: ahhTvYbWjAKlVRNjWBOFUJ
- **Operation Types**: Insert, Upsert

**Sources:**
- **Source 1**: Source
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: DUMMY_Source
  - Schema: 
  - Filter: `mapping_name='$$mapping_name'`

**Targets:**
- **Target 1**: db_target
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: LOAD_DATE_CONTROL
  - Operation: Upsert
- **Target 2**: ff_target
  - Connection: fdtLkJfC7MshWQ81Nzv88G
  - Object: file_name
  - Operation: Insert

---

##### mt_WORK_SCHEDULE_CALENDARS

**Basic Information:**
- **Task Name**: mt_WORK_SCHEDULE_CALENDARS
- **Mapping Reference**: 0pKYoq7bUgobx4Z9L57bk5
- **Operation Types**: Insert

**Targets:**
- **Target 1**: WD_Schedule_Pattern_Week
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Schedule_Pattern_Week
  - Operation: Insert
- **Target 2**: WD_work_schedule_calendars
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_work_schedule_calendars
  - Operation: Insert

---

#### Connections Used

| Connection Name | Type |
|---|---|
| cn_File_Processor_Upload_Vector | Connection |
| ff_Vector | Connection |
| ff_workday_param | Connection |
| svc_DW_CORP | Connection |
| svc_DW_CORP_Apps | Connection |
| SVC_ERP_Hub | Connection |
| svc_ETL | Connection |
| svc_Workday_Connector_Recruiting_austincc | Connection |
| svc_Workday_Human_Resources_austincc | Connection |
| svc_Workday_Payroll_austincc | Connection |
| svc_WorkDay_Stage | Connection |

#### Data Templates

| Template Name | Type |
|---|---|
| m_WORK_SCHEDULE_CALENDAR | DTEMPLATE |
| m_WORK_SCHEDULE_CALENDARS | DTEMPLATE |

---

### Taskflow: tf_WORKDAY_MASTER

**Project Path**: `Explore/ERP Hub/TaskFlows`

#### Connections Used

| Connection Name | Type |
|---|---|
| cn_File_Processor_Upload_Vector | Connection |
| ff_Vector | Connection |
| ff_workday_param | Connection |
| svc_DW_CORP | Connection |
| svc_DW_CORP_Apps | Connection |
| SVC_ERP_Hub | Connection |
| svc_ETL | Connection |
| svc_Workday_Connector_Recruiting_austincc | Connection |
| svc_Workday_Human_Resources_austincc | Connection |
| svc_Workday_Payroll_austincc | Connection |
| svc_WorkDay_Stage | Connection |

---

### Taskflow: tf_WD_POSITION

**Project Path**: `Explore/ERP Hub/WorkDay`

#### Mapping Tasks (MTT)

##### mt_ADDRESS_MASTER

**Basic Information:**
- **Task Name**: mt_ADDRESS_MASTER
- **Mapping Reference**: hDtRO3PK7MacLoPCwR10IZ
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_ADDRESS_MASTER
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_ADDRESS_MASTER
  - Schema: Workday_Stage
  - Filter: `wid is not null
	and  LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)
--where address like '50 Kilgraston Road&#xa;Bridge of Weir&#xa;Renfrewshire&#xa;PA11 3DP&#xa;United K...`

**Targets:**
- **Target 1**: tgt_ADDRESS_MASTER_dw_corp
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: ADDRESS_MASTER
  - Operation: Upsert
- **Target 2**: tgt_ADDRESS_MASTER_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: ADDRESS_MASTER
  - Operation: Upsert

---

##### mt_EMPLOYEE_ADDITIONAL_BENEFIT

**Basic Information:**
- **Task Name**: mt_EMPLOYEE_ADDITIONAL_BENEFIT
- **Mapping Reference**: 3qeykKKQ94bfUxHfLmJZa9
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_EMPLOYEE_ADDITIONAL_BENEFIT
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_EMPLOYEE_ADDITIONAL_BENEFIT
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)
)a
	where LEN(a.Worker_ID)>6`

**Targets:**
- **Target 1**: tgt_EMPLOYEE_ADDITIONAL_BENEFIT_dw_corp
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: EMPLOYEE_ADDITIONAL_BENEFIT
  - Operation: Upsert
- **Target 2**: tgt_EMPLOYEE_ADDITIONAL_BENEFIT_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EMPLOYEE_ADDITIONAL_BENEFIT
  - Operation: Upsert

---

##### mt_EMPLOYEE_BENEFIT_HEALTHCARE

**Basic Information:**
- **Task Name**: mt_EMPLOYEE_BENEFIT_HEALTHCARE
- **Mapping Reference**: 5jnjWlKt6degAKm94H2MeB
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_EMPLOYEE_BENEFIT_HEALTHCARE
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_EMPLOYEE_BENEFIT_HEALTHCARE
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)
) a
where a.EMPLOYEE_ID > 6`

**Targets:**
- **Target 1**: tgt_DW_CORP_EMPLOYEE_BENEFIT_HEALTHCARE
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: EMPLOYEE_BENEFIT_HEALTHCARE
  - Operation: Upsert
- **Target 2**: tgt_erphub_EMPLOYEE_BENEFIT_HEALTHCARE
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EMPLOYEE_BENEFIT_HEALTHCARE
  - Operation: Upsert

---

##### mt_EMPLOYEE_BENEFIT_INSURANCE

**Basic Information:**
- **Task Name**: mt_EMPLOYEE_BENEFIT_INSURANCE
- **Mapping Reference**: 9PZsELDdL48l8vop98lsIJ
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_EMPLOYEE_BENEFIT_INSURANCE
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_EMPLOYEE_BENEFIT_INSURANCE
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)
) a
where a.Worker_ID > 6`

**Targets:**
- **Target 1**: tgt_EMPLOYEE_BENEFIT_INSURANCE_dw_corp
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: EMPLOYEE_BENEFIT_INSURANCE
  - Operation: Upsert
- **Target 2**: tgt_EMPLOYEE_BENEFIT_INSURANCE_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EMPLOYEE_BENEFIT_INSURANCE
  - Operation: Upsert

---

##### mt_EMPLOYEE_BENEFIT_RETIREMENT_SAVINGS

**Basic Information:**
- **Task Name**: mt_EMPLOYEE_BENEFIT_RETIREMENT_SAVINGS
- **Mapping Reference**: 4iqgBoqmuwJiKQyzBN2JSe
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_EMPLOYEE_WORK_SCHEDULE_ASSIGNMENT
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_EMPLOYEE_WORK_SCHEDULE_ASSIGNMENT
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)
) a
where a.EMPLOYEE_ID > 6`

**Targets:**
- **Target 1**: tgt_DW_CORP_EMPLOYEE_BENEFIT_RETIREMENT_SAVINGS
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: EMPLOYEE_BENEFIT_RETIREMENT_SAVINGS
  - Operation: Upsert
- **Target 2**: tgt_erphub_EMPLOYEE_BENEFIT_RETIREMENT_SAVINGS
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EMPLOYEE_BENEFIT_RETIREMENT_SAVINGS
  - Operation: Upsert

---

##### mt_EMPLOYEE_EDUCATION

**Basic Information:**
- **Task Name**: mt_EMPLOYEE_EDUCATION
- **Mapping Reference**: fB6gJ2iBHqohk5ff0XGlo7
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_EMPLOYEE_EDUCATION
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_EMPLOYEE_EDUCATION
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)
 and Worker_ID is NOT null and patindex('%[0-9]%',Worker_ID )<2 
 and  LEN(SUBSTRING(Worker_ID, PATINDEX('%[0-9]%', Worker_I...`

**Targets:**
- **Target 1**: tgt_DW_CORP_EMPLOYEE_EDUCATION
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: EMPLOYEE_EDUCATION
  - Operation: Upsert
- **Target 2**: tgt_erphub_EMPLOYEE_EDUCATION
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EMPLOYEE_EDUCATION
  - Operation: Upsert

---

##### mt_EMPLOYEE_EMPLOYMENT

**Basic Information:**
- **Task Name**: mt_EMPLOYEE_EMPLOYMENT
- **Mapping Reference**: 1cJJ8mNvuIGbs8TtmUYmG8
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_WD_Worker
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_WD_Worker
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)and
patindex('%[0-9]%',Worker_ID )<2 and LEN(Worker_ID)>6

) a where active_rec=1`

**Targets:**
- **Target 1**: tgt_DW_CORP_WORKER_EMPLOYMENT
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: EMPLOYEE_EMPLOYMENT
  - Operation: Upsert
- **Target 2**: tgt_erphub_WORKER_EMPLOYMENT
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EMPLOYEE_EMPLOYMENT
  - Operation: Upsert

---

##### mt_EMPLOYEE_MANAGER

**Basic Information:**
- **Task Name**: mt_EMPLOYEE_MANAGER
- **Mapping Reference**: 2ZQUMlJG5Jzc2XKKt2PRSV
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_WD_WD_Worker_Manager
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_WD_WD_Worker_Manager
  - Schema: Workday_Stage
  - Filter: `len(SUBSTRING(FK_Worker, PATINDEX('%[0-9]%', FK_Worker), PATINDEX('%[0-9][^0-9]%', FK_Worker + 't') - PATINDEX('%[0-9]%', FK_Worker) + 1))>6
  and LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GET...`

**Targets:**
- **Target 1**: tgt_DW_CORP_EMPLOYEE_MANAGER
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: EMPLOYEE_MANAGER
  - Operation: Upsert
- **Target 2**: tgt_erphub_EMPLOYEE_MANAGER
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EMPLOYEE_MANAGER
  - Operation: Upsert

---

##### mt_EMPLOYEE_ORGANIZATION

**Basic Information:**
- **Task Name**: mt_EMPLOYEE_ORGANIZATION
- **Mapping Reference**: lOT05QQ3VK6lGns9D6Pjka
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_EMPLOYEE_ORGANIZATION
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_EMPLOYEE_ORGANIZATION
  - Schema: Workday_Stage
  - Filter: `len(SUBSTRING(FK_Worker, PATINDEX('%[0-9]%', FK_Worker), PATINDEX('%[0-9][^0-9]%', FK_Worker + 't') - PATINDEX('%[0-9]%', FK_Worker) + 1))>6 and
LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDA...`

**Targets:**
- **Target 1**: tgt_EMPLOYEE_ORGANIZATION_dw_corp
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: EMPLOYEE_ORGANIZATION
  - Operation: Upsert
- **Target 2**: tgt_EMPLOYEE_ORGANIZATION_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EMPLOYEE_ORGANIZATION
  - Operation: Upsert

---

##### mt_EMPLOYEE_SKILL

**Basic Information:**
- **Task Name**: mt_EMPLOYEE_SKILL
- **Mapping Reference**: 3FxpHslL67jlAn0QCnvmwH
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_EMPLOYEE_SKILL
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_EMPLOYEE_SKILL
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime) and 
 Worker_ID is NOT null and patindex('%[0-9]%',Worker_ID )<2 
 and  LEN(SUBSTRING(Worker_ID, PATINDEX('%[0-9]%', Worker_...`

**Targets:**
- **Target 1**: tgt_DW_CORP_EMPLOYEE_SKILL
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: EMPLOYEE_SKILL
  - Operation: Upsert
- **Target 2**: tgt_erphub_EMPLOYEE_SKILL
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: EMPLOYEE_SKILL
  - Operation: Upsert

---

##### mt_JOB_PROFILE

**Basic Information:**
- **Task Name**: mt_JOB_PROFILE
- **Mapping Reference**: 89Pjq6n1WU0kx7vM8CWMk0
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_JOB_PROFILE
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_JOB_PROFILE
  - Schema: WORKDAY_STAGE

**Targets:**
- **Target 1**: tgt_DW_CORP_JOB_PROFILE
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: JOB_PROFILE
  - Operation: Upsert
- **Target 2**: tgt_erphub_JOB_PROFILE
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: JOB_PROFILE
  - Operation: Upsert

---

##### mt_ORGANIZATION

**Basic Information:**
- **Task Name**: mt_ORGANIZATION
- **Mapping Reference**: eBSH22fp9kDipn6P3PQwy2
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: Source
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_Source
  - Schema: 
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)`

**Targets:**
- **Target 1**: Target
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: ORGANIZATION
  - Operation: Upsert
- **Target 2**: Target1
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: ORGANIZATION
  - Operation: Upsert

---

##### mt_PAYROLL_RESULT_LINE

**Basic Information:**
- **Task Name**: mt_PAYROLL_RESULT_LINE
- **Mapping Reference**: 3ghWqq6SJJ3b24iSdNXQcK
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_SCHEDULE_PATTERN_WEEK
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DUMMY_src_SCHEDULE_PATTERN_WEEK
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime) and
LEN(SUBSTRING(worker_employee_id, PATINDEX('%[0-9]%', worker_employee_id), PATINDEX('%[0-9][^0-9]%', worker_employee_id ...`

**Targets:**
- **Target 1**: tgt_DW_CORP_PAYROLL_RESULT_LINE
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: PAYROLL_RESULT_LINE
  - Operation: Upsert
- **Target 2**: tgt_ERP_HUB_PAYROLL_RESULT_LINE1
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PAYROLL_RESULT_LINE
  - Operation: Upsert

**Lookups:**
- **Lookup 1**: lkp_organization
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: ORGANIZATION
  - Cache Type: Cached

---

##### mt_PERSON_ADDRESS

**Basic Information:**
- **Task Name**: mt_PERSON_ADDRESS
- **Mapping Reference**: g7rDalP6xcgcxOo2yd0Rwc
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_PERSON_ADDRESS
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_PERSON_ADDRESS
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)`

**Targets:**
- **Target 1**: Tgt_PERSON_ADDRESS_dw_corp
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: PERSON_ADDRESS
  - Operation: Upsert
- **Target 2**: Tgt_PERSON_ADDRESS_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_ADDRESS
  - Operation: Upsert

**Lookups:**
- **Lookup 1**: LKP_ERP_HUB_ADDRESS_MASTER
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: ADDRESS_MASTER
  - Cache Type: Cached

---

##### mt_PERSON_EMAIL

**Basic Information:**
- **Task Name**: mt_PERSON_EMAIL
- **Mapping Reference**: a5okIzDoP9ZewcUdNe0vm4
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_PERSON_EMAIL
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_PERSON_EMAIL
  - Schema: 
  - Filter: `patindex('%[0-9]%',FK_Worker )<2
--and LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)`

**Targets:**
- **Target 1**: tgt_PERSON_EMAIL_dw_corp
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: PERSON_EMAIL
  - Operation: Upsert
- **Target 2**: tgt_PERSON_EMAIL_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_EMAIL
  - Operation: Upsert

---

##### mt_PERSON_PHONE

**Basic Information:**
- **Task Name**: mt_PERSON_PHONE
- **Mapping Reference**: 7nVmsX2JQijdnXwmSfRD2u
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_PERSON_PHONE
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_PERSON_PHONE
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)
  )A
  )B where B.row_num=1`

**Targets:**
- **Target 1**: tgt_PERSON_PHONE_dw_corp
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: PERSON_PHONE
  - Operation: Upsert
- **Target 2**: tgt_PERSON_PHONE_erp_hub
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON_PHONE
  - Operation: Upsert

---

##### mt_PERSON_STEP_1

**Basic Information:**
- **Task Name**: mt_PERSON_STEP_1
- **Mapping Reference**: 4Mk3RjWr3pddIoZcNFcuwi
- **Operation Types**: Update

**Sources:**
- **Source 1**: SRC_Workdaystage_Worker
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_SRC_Workdaystage_Worker
  - Schema: 
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)
--where worker_id in ('0001258', '0001295', '0001315', '0001335', '0001487', '0001549')

) a where active_rec=1
and --LEN(a....`

**Targets:**
- **Target 1**: DW_CORP_UPD_PERSON_ID
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON
  - Operation: Update
- **Target 2**: ERP_HUB_UPD_PERSON_ID
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON
  - Operation: Update

**Lookups:**
- **Lookup 1**: Lkp_ERPHUB_Person_by_Personid
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON
  - Cache Type: Cached

---

##### mt_PERSON_STEP_2

**Basic Information:**
- **Task Name**: mt_PERSON_STEP_2
- **Mapping Reference**: 5pxY0w88YSphpfv8xWzocH
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: SRC_Workdaystage_Worker
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_SRC_Workdaystage_Worker
  - Schema: 
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)
--where worker_id in ('0001258', '0001295', '0001315', '0001335', '0001487', '0001549')

) a where active_rec=1
and --LEN(a....`

**Targets:**
- **Target 1**: DW_CORP_Upsert_by_ERP_ID
  - Connection: j7wVfWT172slzuVgNfk3ga
  - Object: PERSON
  - Operation: Upsert
- **Target 2**: ERP_HUB_Upsert_by_ERP_ID
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON
  - Operation: Upsert

**Lookups:**
- **Lookup 1**: Lkp_ERPHUB_Person_by_Personid
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: PERSON
  - Cache Type: Cached

---

##### mt_SCHEDULE_PATTERN_WEEK

**Basic Information:**
- **Task Name**: mt_SCHEDULE_PATTERN_WEEK
- **Mapping Reference**: 9vrdZFmKbamh4FWn3cPOqL
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_SCHEDULE_PATTERN_WEEK
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DUMMY_src_SCHEDULE_PATTERN_WEEK
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)`

**Targets:**
- **Target 1**: tgt_DW_CORP_SCHEDULE_PATTERN_WEEK
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: SCHEDULE_PATTERN_WEEK
  - Operation: Upsert
- **Target 2**: tgt_ERP_HUB_SCHEDULE_PATTERN_WEEK
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: SCHEDULE_PATTERN_WEEK
  - Operation: Upsert

---

##### mt_WD_Position

**Basic Information:**
- **Task Name**: mt_WD_Position
- **Mapping Reference**: a6PvJnWOY4RlAT92HKV4cH
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_WD_Position
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: DUMMY_src_WD_Position
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)`

**Targets:**
- **Target 1**: tgt_DW_CORP_WD_Position
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: WD_POSITION
  - Operation: Upsert
- **Target 2**: tgt_erphub_WD_Position
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: WD_POSITION
  - Operation: Upsert

---

##### mt_WORK_SCHEDULE_CALENDAR

**Basic Information:**
- **Task Name**: mt_WORK_SCHEDULE_CALENDAR
- **Mapping Reference**: 5kNH5u9hynleKSmV2H5hMh
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_SCHEDULE_PATTERN_WEEK
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DUMMY_src_SCHEDULE_PATTERN_WEEK
  - Schema: Workday_Stage
  - Filter: `LOAD_DATE>=DATEADD(mi, DATEDIFF(mi, GETUTCDATE(), GETDATE()), $LastRunTime)`

**Targets:**
- **Target 1**: tgt_DW_CORP_WORK_SCHEDULE_CALENDAR
  - Connection: 4EppssBY3AqcpkiZuEMCMQ
  - Object: WORK_SCHEDULE_CALENDAR
  - Operation: Upsert
- **Target 2**: tgt_ERP_HUB_WORK_SCHEDULE_CALENDAR
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: WORK_SCHEDULE_CALENDAR
  - Operation: Upsert

---

##### mt_WD_POSITION

**Basic Information:**
- **Task Name**: mt_WD_POSITION
- **Mapping Reference**: 8X0U5jgGbQTjsIVmAj7moc
- **Operation Types**: Insert

**Targets:**
- **Target 1**: WD_Position
  - Connection: 8gxdIT5zg8jlcFvOKx5bUq
  - Object: WD_Position
  - Operation: Insert

---

##### mt_WORKDAY_UPDATE_TIMESTAMP_END

**Basic Information:**
- **Task Name**: mt_WORKDAY_UPDATE_TIMESTAMP_END
- **Mapping Reference**: idgVEgOhzkakW1mXIXsAYN
- **Operation Types**: Upsert

**Sources:**
- **Source 1**: src_mapping_name
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: DUMMY_src_mapping_name
  - Schema: 
  - Filter: `mapping_name='$$mapping_name'`

**Targets:**
- **Target 1**: tgt_Workday_Timestamp_Control_table
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: LOAD_DATE_CONTROL
  - Operation: Upsert

---

##### mt_WORKDAY_UPDATE_TIMESTAMP_START

**Basic Information:**
- **Task Name**: mt_WORKDAY_UPDATE_TIMESTAMP_START
- **Mapping Reference**: ahhTvYbWjAKlVRNjWBOFUJ
- **Operation Types**: Insert, Upsert

**Sources:**
- **Source 1**: Source
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: DUMMY_Source
  - Schema: 
  - Filter: `mapping_name='$$mapping_name'`

**Targets:**
- **Target 1**: db_target
  - Connection: 7ERaoZJP1PJfABgVBiKlU4
  - Object: LOAD_DATE_CONTROL
  - Operation: Upsert
- **Target 2**: ff_target
  - Connection: fdtLkJfC7MshWQ81Nzv88G
  - Object: file_name
  - Operation: Insert

---

#### Connections Used

| Connection Name | Type |
|---|---|
| cn_File_Processor_Upload_Vector | Connection |
| ff_Vector | Connection |
| ff_workday_param | Connection |
| svc_DW_CORP | Connection |
| svc_DW_CORP_Apps | Connection |
| SVC_ERP_Hub | Connection |
| svc_ETL | Connection |
| svc_Workday_Connector_Recruiting_austincc | Connection |
| svc_Workday_Human_Resources_austincc | Connection |
| svc_Workday_Payroll_austincc | Connection |
| svc_WorkDay_Stage | Connection |

#### Data Templates

| Template Name | Type |
|---|---|
| m_ADDRESS_MASTER | DTEMPLATE |
| m_EMPLOYEE_ADDITIONAL_BENEFIT | DTEMPLATE |
| m_EMPLOYEE_BENEFIT_HEALTHCARE | DTEMPLATE |
| m_EMPLOYEE_BENEFIT_INSURANCE | DTEMPLATE |
| m_EMPLOYEE_BENEFIT_RETIREMENT_SAVINGS | DTEMPLATE |
| m_EMPLOYEE_EDUCATION | DTEMPLATE |
| m_EMPLOYEE_EMPLOYMENT | DTEMPLATE |
| m_EMPLOYEE_MANAGER | DTEMPLATE |
| m_EMPLOYEE_ORGANIZATION | DTEMPLATE |
| m_EMPLOYEE_SKILL | DTEMPLATE |
| m_JOB_PROFILE | DTEMPLATE |
| m_ORGANIZATION | DTEMPLATE |
| m_PAYROLL_RESULT_LINE | DTEMPLATE |
| m_PERSON_ADDRESS | DTEMPLATE |
| m_PERSON_EMAIL | DTEMPLATE |
| m_PERSON_PHONE | DTEMPLATE |
| m_PERSON_STEP_1 | DTEMPLATE |
| m_PERSON_STEP_2 | DTEMPLATE |
| m_SCHEDULE_PATTERN_WEEK | DTEMPLATE |
| m_WD_Position | DTEMPLATE |
| m_WORK_SCHEDULE_CALENDAR | DTEMPLATE |
| m_WD_POSITION | DTEMPLATE |

---

### Taskflow: tf_Vector_Daily

**Project Path**: `Explore/OutBound_Data/Vector`

#### Mapping Tasks (MTT)

##### mt_Vector_files_preprocessing

**Basic Information:**
- **Task Name**: mt_Vector_files_preprocessing
- **Mapping Reference**: 88vhl9pJHrkf2SomdYG7co
- **Operation Types**: Insert

**Sources:**
- **Source 1**: dummy_source
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DUMMY_dummy_source
  - Schema: 

**Targets:**
- **Target 1**: tgt_dummy_ff
  - Connection: kv1Oc7IlHwLljjjRVTc02I
  - Object: dummy.csv
  - Operation: Insert

---

##### mt_Vector_SFTP

**Basic Information:**
- **Task Name**: mt_Vector_SFTP
- **Mapping Reference**: 9apLvjaN9kAhYjeVtdSWG6
- **Operation Types**: Insert

**Sources:**
- **Source 1**: src_ff_local_Vector
  - Connection: 5UVYYHSrKyPc5huXfgKD26
  - Object: SFTP_PUT
  - Schema: 

**Targets:**
- **Target 1**: tgt_dummy_ff
  - Connection: kv1Oc7IlHwLljjjRVTc02I
  - Object: Dummy_Vector_SFTP.csv
  - Operation: Insert

---

##### mt_Vector_student

**Basic Information:**
- **Task Name**: mt_Vector_student
- **Mapping Reference**: 1nSIzs2dFSJdfub7ap5o0N
- **Operation Types**: Insert

**Sources:**
- **Source 1**: Src_Vector_Student
  - Connection: 7GJWeSZ3GgRjnalVEKpdg4
  - Object: DUMMY_Src_Vector_Student
  - Schema: erp_hub
  - Filter: `(STC.CURRENT_STATUS = 'A'  OR STC.CURRENT_STATUS = 'N'
OR (STC.CURRENT_STATUS = 'D' AND STC.CURRENT_STATUS_DATE > CS.FIRST_CENSUS_DATE)
OR (STC.CURRENT_STATUS = 'W' AND STC.CURRENT_STATUS_DATE > CS.FI...`

**Targets:**
- **Target 1**: Tgt_Vector_Student
  - Connection: kv1Oc7IlHwLljjjRVTc02I
  - Object: Vector_student.csv
  - Operation: Insert

---

#### Connections Used

| Connection Name | Type |
|---|---|
| cn_File_Processor_Upload_Vector | Connection |
| ff_Vector | Connection |
| ff_workday_param | Connection |
| svc_DW_CORP | Connection |
| svc_DW_CORP_Apps | Connection |
| SVC_ERP_Hub | Connection |
| svc_ETL | Connection |
| svc_Workday_Connector_Recruiting_austincc | Connection |
| svc_Workday_Human_Resources_austincc | Connection |
| svc_Workday_Payroll_austincc | Connection |
| svc_WorkDay_Stage | Connection |

#### Data Templates

| Template Name | Type |
|---|---|
| m_Vector_files_preprocessing | DTEMPLATE |
| m_Vector_SFTP | DTEMPLATE |
| m_Vector_student | DTEMPLATE |

---

## Cross-Taskflow Analysis

### Shared Connections

| Connection | Used by Taskflows | Usage Count |
|---|---|---|
| cn_File_Processor_Upload_Vector | tf_WD_ACADEMIC_APPOINTEE, tf_WD_JOB_PROFILES, tf_WD_LOCATIONS, tf_WD_ORGANIZATIONS, tf_WD_WORKER, tf_WD_WORKER_COMPENSATION_DATA_PLUS_BENEFIT_ENROLLMENTS_ELIGIBILITY, tf_WD_WORKER_PAYROLL_RESULT_LINE, tf_WD_Worker_Qualifications, tf_WD_WORK_SCHEDULE_CALENDARS, tf_WORKDAY_MASTER, tf_WD_POSITION, tf_Vector_Daily | 12 |
| ff_Vector | tf_WD_ACADEMIC_APPOINTEE, tf_WD_JOB_PROFILES, tf_WD_LOCATIONS, tf_WD_ORGANIZATIONS, tf_WD_WORKER, tf_WD_WORKER_COMPENSATION_DATA_PLUS_BENEFIT_ENROLLMENTS_ELIGIBILITY, tf_WD_WORKER_PAYROLL_RESULT_LINE, tf_WD_Worker_Qualifications, tf_WD_WORK_SCHEDULE_CALENDARS, tf_WORKDAY_MASTER, tf_WD_POSITION, tf_Vector_Daily | 12 |
| ff_workday_param | tf_WD_ACADEMIC_APPOINTEE, tf_WD_JOB_PROFILES, tf_WD_LOCATIONS, tf_WD_ORGANIZATIONS, tf_WD_WORKER, tf_WD_WORKER_COMPENSATION_DATA_PLUS_BENEFIT_ENROLLMENTS_ELIGIBILITY, tf_WD_WORKER_PAYROLL_RESULT_LINE, tf_WD_Worker_Qualifications, tf_WD_WORK_SCHEDULE_CALENDARS, tf_WORKDAY_MASTER, tf_WD_POSITION, tf_Vector_Daily | 12 |
| svc_DW_CORP | tf_WD_ACADEMIC_APPOINTEE, tf_WD_JOB_PROFILES, tf_WD_LOCATIONS, tf_WD_ORGANIZATIONS, tf_WD_WORKER, tf_WD_WORKER_COMPENSATION_DATA_PLUS_BENEFIT_ENROLLMENTS_ELIGIBILITY, tf_WD_WORKER_PAYROLL_RESULT_LINE, tf_WD_Worker_Qualifications, tf_WD_WORK_SCHEDULE_CALENDARS, tf_WORKDAY_MASTER, tf_WD_POSITION, tf_Vector_Daily | 12 |
| svc_DW_CORP_Apps | tf_WD_ACADEMIC_APPOINTEE, tf_WD_JOB_PROFILES, tf_WD_LOCATIONS, tf_WD_ORGANIZATIONS, tf_WD_WORKER, tf_WD_WORKER_COMPENSATION_DATA_PLUS_BENEFIT_ENROLLMENTS_ELIGIBILITY, tf_WD_WORKER_PAYROLL_RESULT_LINE, tf_WD_Worker_Qualifications, tf_WD_WORK_SCHEDULE_CALENDARS, tf_WORKDAY_MASTER, tf_WD_POSITION, tf_Vector_Daily | 12 |
| SVC_ERP_Hub | tf_WD_ACADEMIC_APPOINTEE, tf_WD_JOB_PROFILES, tf_WD_LOCATIONS, tf_WD_ORGANIZATIONS, tf_WD_WORKER, tf_WD_WORKER_COMPENSATION_DATA_PLUS_BENEFIT_ENROLLMENTS_ELIGIBILITY, tf_WD_WORKER_PAYROLL_RESULT_LINE, tf_WD_Worker_Qualifications, tf_WD_WORK_SCHEDULE_CALENDARS, tf_WORKDAY_MASTER, tf_WD_POSITION, tf_Vector_Daily | 12 |
| svc_ETL | tf_WD_ACADEMIC_APPOINTEE, tf_WD_JOB_PROFILES, tf_WD_LOCATIONS, tf_WD_ORGANIZATIONS, tf_WD_WORKER, tf_WD_WORKER_COMPENSATION_DATA_PLUS_BENEFIT_ENROLLMENTS_ELIGIBILITY, tf_WD_WORKER_PAYROLL_RESULT_LINE, tf_WD_Worker_Qualifications, tf_WD_WORK_SCHEDULE_CALENDARS, tf_WORKDAY_MASTER, tf_WD_POSITION, tf_Vector_Daily | 12 |
| svc_Workday_Connector_Recruiting_austincc | tf_WD_ACADEMIC_APPOINTEE, tf_WD_JOB_PROFILES, tf_WD_LOCATIONS, tf_WD_ORGANIZATIONS, tf_WD_WORKER, tf_WD_WORKER_COMPENSATION_DATA_PLUS_BENEFIT_ENROLLMENTS_ELIGIBILITY, tf_WD_WORKER_PAYROLL_RESULT_LINE, tf_WD_Worker_Qualifications, tf_WD_WORK_SCHEDULE_CALENDARS, tf_WORKDAY_MASTER, tf_WD_POSITION, tf_Vector_Daily | 12 |
| svc_Workday_Human_Resources_austincc | tf_WD_ACADEMIC_APPOINTEE, tf_WD_JOB_PROFILES, tf_WD_LOCATIONS, tf_WD_ORGANIZATIONS, tf_WD_WORKER, tf_WD_WORKER_COMPENSATION_DATA_PLUS_BENEFIT_ENROLLMENTS_ELIGIBILITY, tf_WD_WORKER_PAYROLL_RESULT_LINE, tf_WD_Worker_Qualifications, tf_WD_WORK_SCHEDULE_CALENDARS, tf_WORKDAY_MASTER, tf_WD_POSITION, tf_Vector_Daily | 12 |
| svc_Workday_Payroll_austincc | tf_WD_ACADEMIC_APPOINTEE, tf_WD_JOB_PROFILES, tf_WD_LOCATIONS, tf_WD_ORGANIZATIONS, tf_WD_WORKER, tf_WD_WORKER_COMPENSATION_DATA_PLUS_BENEFIT_ENROLLMENTS_ELIGIBILITY, tf_WD_WORKER_PAYROLL_RESULT_LINE, tf_WD_Worker_Qualifications, tf_WD_WORK_SCHEDULE_CALENDARS, tf_WORKDAY_MASTER, tf_WD_POSITION, tf_Vector_Daily | 12 |
| svc_WorkDay_Stage | tf_WD_ACADEMIC_APPOINTEE, tf_WD_JOB_PROFILES, tf_WD_LOCATIONS, tf_WD_ORGANIZATIONS, tf_WD_WORKER, tf_WD_WORKER_COMPENSATION_DATA_PLUS_BENEFIT_ENROLLMENTS_ELIGIBILITY, tf_WD_WORKER_PAYROLL_RESULT_LINE, tf_WD_Worker_Qualifications, tf_WD_WORK_SCHEDULE_CALENDARS, tf_WORKDAY_MASTER, tf_WD_POSITION, tf_Vector_Daily | 12 |

---
*Report generated by IICS Job Analyzer - Multi-Taskflow Edition*