#!/usr/bin/env python3
"""
IICS Taskflow Analyzer
Comprehensive analysis tool for Informatica Intelligent Cloud Services (IICS) taskflow exports
"""

import json
import xml.etree.ElementTree as ET
import zipfile
import os
import pandas as pd
from pathlib import Path
from typing import Dict, List, Tuple, Any
import re
from collections import defaultdict
import networkx as nx
import matplotlib.pyplot as plt

class IICSTaskflowAnalyzer:
    def __init__(self, extracted_path: str):
        """Initialize the analyzer with the path to extracted taskflow files"""
        self.extracted_path = Path(extracted_path)
        self.metadata = {}
        self.taskflow_xml = None
        self.mtt_tasks = {}
        self.dtemplates = {}
        self.connections = {}
        self.dependency_graph = nx.DiGraph()
        self.task_execution_order = []
        # Mapping of mapping GUID (without @) -> human-readable mapping name from export
        self.mapping_id_to_name: Dict[str, str] = {}
        self.task_details = {}
        
    def load_export_metadata(self):
        """Load the main export metadata"""
        metadata_file = self.extracted_path / "exportMetadata.v2.json"
        if metadata_file.exists():
            with open(metadata_file, 'r') as f:
                self.metadata = json.load(f)
        print(f"✓ Loaded metadata for {len(self.metadata.get('exportedObjects', []))} objects")
        # Build a lookup index for mapping IDs to names from available artifacts
        self._build_mapping_name_index()

    def _build_mapping_name_index(self) -> None:
        """Build an index of mapping GUID -> mapping name from export artifacts.
        Priority:
        1) exportMetadata.v2.json exportedObjects with objectType containing 'Mapping'
        2) Any 'Contents of Export Package' CSV files within the extracted path
        If not found, the index remains empty and mapping names will be blank.
        """
        id_to_name: Dict[str, str] = {}

        # 1) From exportMetadata.v2.json — index ALL objects by GUID -> name
        exported_objects = self.metadata.get('exportedObjects', []) if isinstance(self.metadata, dict) else []
        for obj in exported_objects:
            try:
                guid = (obj.get('objectGuid') or obj.get('id') or '').replace('@', '')
                name = obj.get('objectName') or obj.get('name') or ''
                if guid and name and guid not in id_to_name:
                    id_to_name[guid] = name
            except Exception:
                # Be resilient to unexpected structures
                continue

        # 2) From any ContentsofExportPackage_*.csv files within extracted path
        try:
            for csv_path in self.extracted_path.rglob('ContentsofExportPackage_*.csv'):
                try:
                    import csv
                    with csv_path.open(newline='', encoding='utf-8') as f:
                        reader = csv.DictReader(f)
                        # Expect columns: objectPath,objectName,objectType,id
                        for row in reader:
                            # Many exports omit Mapping objects; mappingId often appears as id of a DTEMPLATE
                            guid = (row.get('id') or '').replace('@', '')
                            name = row.get('objectName') or ''
                            if guid and name and guid not in id_to_name:
                                id_to_name[guid] = name
                except Exception:
                    # Skip malformed CSVs but continue others
                    pass
        except Exception:
            # rglob might fail in some environments; ignore gracefully
            pass

        self.mapping_id_to_name = id_to_name
        
    def analyze_taskflow_xml(self):
        """Analyze the main taskflow XML file"""
        taskflow_files = list(self.extracted_path.glob("**/*.TASKFLOW.xml"))
        if not taskflow_files:
            print("❌ No taskflow XML files found")
            return
            
        taskflow_file = taskflow_files[0]
        print(f"📄 Analyzing taskflow: {taskflow_file.name}")
        
        tree = ET.parse(taskflow_file)
        self.taskflow_xml = tree.getroot()
        
        # Extract task execution order and dependencies
        self._extract_task_dependencies()
        
    def _extract_task_dependencies(self):
        """Extract task dependencies from the taskflow XML"""
        if self.taskflow_xml is None:
            return
            
        # Find all services (tasks) in the taskflow
        services = self.taskflow_xml.findall(".//service")
        links = self.taskflow_xml.findall(".//link")
        
        task_order = []
        task_details = {}
        
        for service in services:
            title = service.find("title")
            if title is not None:
                task_name = title.text
                task_order.append(task_name)
                
                # Extract GUID and other details
                guid_param = service.find(".//parameter[@name='GUID']")
                guid = guid_param.get('updatable') if guid_param is not None else None
                
                task_details[task_name] = {
                    'guid': guid,
                    'service_name': service.find("serviceName").text if service.find("serviceName") is not None else None
                }
                
        self.task_execution_order = task_order
        self.task_details = task_details
        
        print(f"✓ Found {len(task_order)} tasks in execution order")
        
    def extract_mtt_tasks(self):
        """Extract and analyze MTT (Mapping Task Template) files"""
        mtt_files = list(self.extracted_path.glob("**/*.MTT.zip"))
        
        for mtt_file in mtt_files:
            task_name = mtt_file.stem.replace('.MTT', '')
            print(f"📋 Analyzing MTT: {task_name}")
            
            try:
                with zipfile.ZipFile(mtt_file, 'r') as zip_ref:
                    # Extract to temporary directory
                    temp_dir = self.extracted_path / f"temp_{task_name}"
                    temp_dir.mkdir(exist_ok=True)
                    zip_ref.extractall(temp_dir)
                    
                    # Read mtTask.json
                    mt_task_file = temp_dir / "mtTask.json"
                    if mt_task_file.exists():
                        with open(mt_task_file, 'r') as f:
                            mtt_data = json.load(f)
                            # MTT JSON is a list with a single dictionary
                            if isinstance(mtt_data, list) and len(mtt_data) > 0:
                                self.mtt_tasks[task_name] = mtt_data[0]
                            else:
                                self.mtt_tasks[task_name] = mtt_data
                    
                    # Clean up temporary directory
                    import shutil
                    if temp_dir.exists():
                        shutil.rmtree(temp_dir)
                            
            except Exception as e:
                print(f"❌ Error processing {mtt_file}: {e}")
                
        print(f"✓ Extracted {len(self.mtt_tasks)} MTT tasks")
        
    def extract_dtemplates(self):
        """Extract and analyze DTEMPLATE files"""
        dtemplate_files = list(self.extracted_path.glob("**/*.DTEMPLATE.zip"))
        
        for dtemplate_file in dtemplate_files:
            template_name = dtemplate_file.stem.replace('.DTEMPLATE', '')
            print(f"📋 Analyzing DTEMPLATE: {template_name}")
            
            try:
                with zipfile.ZipFile(dtemplate_file, 'r') as zip_ref:
                    # List contents to understand structure
                    file_list = zip_ref.namelist()
                    self.dtemplates[template_name] = {
                        'files': file_list,
                        'path': str(dtemplate_file)
                    }
                    
            except Exception as e:
                print(f"❌ Error processing {dtemplate_file}: {e}")
                
        print(f"✓ Found {len(self.dtemplates)} data templates")
        
    def analyze_connections(self):
        """Analyze connection objects"""
        connection_files = list(self.extracted_path.glob("**/*.Connection.zip"))
        
        for conn_file in connection_files:
            conn_name = conn_file.stem.replace('.Connection', '')
            print(f"🔗 Analyzing Connection: {conn_name}")
            
            try:
                with zipfile.ZipFile(conn_file, 'r') as zip_ref:
                    file_list = zip_ref.namelist()
                    self.connections[conn_name] = {
                        'files': file_list,
                        'path': str(conn_file)
                    }
                    
            except Exception as e:
                print(f"❌ Error processing {conn_file}: {e}")
                
        print(f"✓ Found {len(self.connections)} connections")
        
    def build_dependency_graph(self):
        """Build a dependency graph of the taskflow components"""
        # Add nodes for all components
        for task_name in self.task_execution_order:
            self.dependency_graph.add_node(task_name, type='MTT')
            
        for template_name in self.dtemplates:
            self.dependency_graph.add_node(template_name, type='DTEMPLATE')
            
        for conn_name in self.connections:
            self.dependency_graph.add_node(conn_name, type='Connection')
            
        # Add edges based on execution order
        for i in range(len(self.task_execution_order) - 1):
            current_task = self.task_execution_order[i]
            next_task = self.task_execution_order[i + 1]
            self.dependency_graph.add_edge(current_task, next_task, type='execution_order')
            
        print(f"✓ Built dependency graph with {self.dependency_graph.number_of_nodes()} nodes and {self.dependency_graph.number_of_edges()} edges")
        
    def generate_summary_report(self):
        """Generate a comprehensive summary report"""
        print("\n" + "="*80)
        print("IICS TASKFLOW ANALYSIS SUMMARY")
        print("="*80)
        
        if self.metadata:
            print(f"📦 Export Package: {self.metadata.get('name', 'Unknown')}")
            print(f"🏢 Source Organization: {self.metadata.get('sourceOrgName', 'Unknown')}")
            print(f"📊 Total Objects: {len(self.metadata.get('exportedObjects', []))}")
            
        print(f"\n📋 TASK EXECUTION ORDER:")
        for i, task in enumerate(self.task_execution_order, 1):
            print(f"  {i:2d}. {task}")
            
        print(f"\n🔗 CONNECTIONS ({len(self.connections)}):")
        for conn_name in self.connections:
            print(f"  • {conn_name}")
            
        print(f"\n📄 DATA TEMPLATES ({len(self.dtemplates)}):")
        for template_name in self.dtemplates:
            print(f"  • {template_name}")
            
        # Analyze object types
        object_types = defaultdict(int)
        for obj in self.metadata.get('exportedObjects', []):
            object_types[obj['objectType']] += 1
            
        print(f"\n📈 OBJECT TYPE BREAKDOWN:")
        for obj_type, count in sorted(object_types.items()):
            print(f"  • {obj_type}: {count}")
            
    def export_to_csv(self, output_file: str = "taskflow_analysis.csv"):
        """Export analysis results to CSV"""
        data = []
        
        for obj in self.metadata.get('exportedObjects', []):
            row = {
                'Object_Name': obj['objectName'],
                'Object_Type': obj['objectType'],
                'Path': obj['path'],
                'GUID': obj['objectGuid'],
                'Description': obj.get('metadata', {}).get('additionalInfo', {}).get('description', ''),
                'Document_State': obj.get('metadata', {}).get('additionalInfo', {}).get('documentState', '')
            }
            
            # Add execution order for MTT tasks
            if obj['objectName'] in self.task_execution_order:
                row['Execution_Order'] = self.task_execution_order.index(obj['objectName']) + 1
            else:
                row['Execution_Order'] = None
                
            data.append(row)
            
        df = pd.DataFrame(data)
        df.to_csv(output_file, index=False)
        print(f"✓ Exported analysis to {output_file}")
        
    def _extract_transformation_details(self, mtt_data: dict) -> dict:
        """Extract detailed transformation information from MTT data"""
        details = {
            'task_name': mtt_data.get('name', 'Unknown'),
            'mapping_name': '',
            'sources': [],
            'targets': [],
            'lookups': [],
            'transformations': [],
            'session_properties': {},
            'operation_types': set()
        }
        
        # Extract mapping reference; try to resolve real mapping name from export
        mapping_id = mtt_data.get('mappingId', '')
        task_name = mtt_data.get('name', 'Unknown')
        
        if mapping_id:
            details['mapping_id'] = mapping_id.replace('@', '')
            # Resolve mapping name from index if available; otherwise leave blank
            details['mapping_name'] = self.mapping_id_to_name.get(details['mapping_id'], '')
        else:
            details['mapping_id'] = ''
            details['mapping_name'] = ''
            
        # Process parameters to find sources, targets, and lookups
        parameters = mtt_data.get('parameters', [])
        
        for param in parameters:
            param_type = param.get('type', '')
            param_name = param.get('name', '')
            param_label = param.get('label', '')
            
            if param_type == 'EXTENDED_SOURCE':
                source_info = {
                    'name': param_label,
                    'connection_id': param.get('sourceConnectionId', '').replace('@', ''),
                    'object_name': param.get('extendedObject', {}).get('object', {}).get('name', ''),
                    'schema': param.get('extendedObject', {}).get('object', {}).get('dbSchema', ''),
                    'filter': param.get('extendedObject', {}).get('advancedFilterExpression', ''),
                    'read_pattern': 'Extended Source with Filter',
                    'source_type': 'Extended Table',
                    'sql_query': ''
                }
                details['sources'].append(source_info)
                
            elif param_type == 'SOURCE':
                # Handle regular SOURCE parameters (including SQL queries)
                custom_query = param.get('customQuery', '')
                source_object = param.get('sourceObject', '')
                
                source_info = {
                    'name': param_label,
                    'connection_id': param.get('sourceConnectionId', '').replace('@', ''),
                    'object_name': source_object,
                    'schema': self._extract_schema_from_query(custom_query) if custom_query else '',
                    'filter': self._extract_filter_from_query(custom_query) if custom_query else '',
                    'read_pattern': 'SQL Query' if custom_query else 'Direct Table Access',
                    'source_type': 'SQL Query' if custom_query else 'Direct Table',
                    'sql_query': custom_query,
                    'is_rest_source': param.get('isRESTModernSource', False)
                }
                details['sources'].append(source_info)
                
            elif param_type == 'TARGET':
                operation_type = param.get('operationType', 'Unknown')
                details['operation_types'].add(operation_type)
                
                target_info = {
                    'name': param_label,
                    'connection_id': param.get('targetConnectionId', '').replace('@', ''),
                    'object_name': param.get('targetObject', ''),
                    'schema': param.get('dbSchema', ''),
                    'operation_type': operation_type,
                    'update_columns': param.get('targetUpdateColumns', []),
                    'write_pattern': f'{operation_type} Operation'
                }
                details['targets'].append(target_info)
                
            elif param_type == 'LOOKUP':
                lookup_info = {
                    'name': param_label,
                    'connection_id': param.get('lookupConnectionId', '').replace('@', ''),
                    'object_name': param.get('lookupObject', ''),
                    'schema': param.get('dbSchema', ''),
                    'cache_enabled': param.get('runtimeAttrs', {}).get('Lookup caching enabled', 'false'),
                    'cache_type': 'Cached' if param.get('uiProperties', {}).get('isCachedLookup') == 'true' else 'Uncached'
                }
                details['lookups'].append(lookup_info)
        
        # Extract session properties
        session_props = mtt_data.get('sessionPropertiesList', [])
        for prop in session_props:
            prop_name = prop.get('name', '')
            prop_value = prop.get('value', '')
            details['session_properties'][prop_name] = prop_value
            
        return details
    
    def _extract_schema_from_query(self, sql_query: str) -> str:
        """Extract schema/database name from SQL query using regex"""
        if not sql_query:
            return ''
        
        # Look for patterns like "schema.table" or "database.dbo.table"
        import re
        patterns = [
            r'FROM\s+([a-zA-Z_][a-zA-Z0-9_]*)\.[a-zA-Z_][a-zA-Z0-9_]*\.[a-zA-Z_][a-zA-Z0-9_]*',  # database.schema.table
            r'FROM\s+([a-zA-Z_][a-zA-Z0-9_]*)\.[a-zA-Z_][a-zA-Z0-9_]*',  # schema.table
            r'JOIN\s+([a-zA-Z_][a-zA-Z0-9_]*)\.[a-zA-Z_][a-zA-Z0-9_]*'   # JOIN schema.table
        ]
        
        for pattern in patterns:
            match = re.search(pattern, sql_query, re.IGNORECASE)
            if match:
                return match.group(1)
        
        return ''
    
    def _extract_filter_from_query(self, sql_query: str) -> str:
        """Extract WHERE clause from SQL query"""
        if not sql_query:
            return ''
        
        import re
        # Extract WHERE clause (simplified)
        where_match = re.search(r'WHERE\s+(.+?)(?:\s+ORDER\s+BY|\s+GROUP\s+BY|\s*$)', sql_query, re.IGNORECASE | re.DOTALL)
        if where_match:
            where_clause = where_match.group(1).strip()
            # Limit length for readability
            if len(where_clause) > 200:
                where_clause = where_clause[:200] + '...'
            return where_clause
        
        return ''
    
    def _generate_mapping_name(self, task_name: str, mapping_id: str) -> str:
        """Generate a human-readable mapping name from task name and mapping ID"""
        # Remove common prefixes and suffixes from task name
        mapping_name = task_name
        
        # Remove 'mt_' prefix if present
        if mapping_name.startswith('mt_'):
            mapping_name = mapping_name[3:]
        
        # Remove common suffixes
        suffixes_to_remove = ['_soft_delete', '_delete', '_update', '_insert', '_load', '_extract']
        for suffix in suffixes_to_remove:
            if mapping_name.endswith(suffix):
                mapping_name = mapping_name[:-len(suffix)]
                break
        
        # Convert to proper case and add 'm_' prefix
        mapping_name = f"m_{mapping_name}"
        
        return mapping_name
    
    def _extract_tables_from_query(self, sql_query: str) -> List[str]:
        """Extract table names from SQL query"""
        if not sql_query:
            return []
        
        import re
        tables = []
        
        # Patterns to match table references
        patterns = [
            r'FROM\s+(?:[a-zA-Z_][a-zA-Z0-9_]*\.)?(?:[a-zA-Z_][a-zA-Z0-9_]*\.)?([a-zA-Z_][a-zA-Z0-9_]*)',
            r'JOIN\s+(?:[a-zA-Z_][a-zA-Z0-9_]*\.)?(?:[a-zA-Z_][a-zA-Z0-9_]*\.)?([a-zA-Z_][a-zA-Z0-9_]*)',
            r'UPDATE\s+(?:[a-zA-Z_][a-zA-Z0-9_]*\.)?(?:[a-zA-Z_][a-zA-Z0-9_]*\.)?([a-zA-Z_][a-zA-Z0-9_]*)',
            r'INSERT\s+INTO\s+(?:[a-zA-Z_][a-zA-Z0-9_]*\.)?(?:[a-zA-Z_][a-zA-Z0-9_]*\.)?([a-zA-Z_][a-zA-Z0-9_]*)'
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, sql_query, re.IGNORECASE)
            tables.extend(matches)
        
        return list(set(tables))  # Remove duplicates
        
    def generate_detailed_markdown_report(self, output_file: str = "detailed_taskflow_report.md"):
        """Generate a comprehensive markdown report with transformation details"""
        
        # Extract detailed information from MTT tasks
        detailed_mappings = {}
        connection_details = {}
        
        # Get connection names from metadata
        for obj in self.metadata.get('exportedObjects', []):
            if obj['objectType'] == 'Connection':
                connection_details[obj['objectGuid']] = {
                    'name': obj['objectName'],
                    'path': obj['path']
                }
        
        # Process each MTT task for detailed analysis
        for task_name, mtt_data in self.mtt_tasks.items():
            detailed_mappings[task_name] = self._extract_transformation_details(mtt_data)
            
        # Generate markdown content
        md_content = self._generate_markdown_content(detailed_mappings, connection_details)
        
        # Write to file
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(md_content)
            
        print(f"✓ Generated detailed markdown report: {output_file}")
        
    def _generate_markdown_content(self, detailed_mappings: dict, connection_details: dict) -> str:
        """Generate the markdown content for the detailed report"""
        
        md = []
        md.append("# IICS Taskflow Detailed Analysis Report")
        md.append("")
        md.append("## Overview")
        md.append("")
        
        if self.metadata:
            md.append(f"- **Package Name**: {self.metadata.get('name', 'Unknown')}")
            md.append(f"- **Source Organization**: {self.metadata.get('sourceOrgName', 'Unknown')}")
            md.append(f"- **Total Objects**: {len(self.metadata.get('exportedObjects', []))}")
            md.append(f"- **Analysis Date**: {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        md.append("")
        md.append("## Connection Summary")
        md.append("")
        md.append("| Connection Name | Type | Path |")
        md.append("|---|---|---|")
        
        for conn_name, conn_info in self.connections.items():
            md.append(f"| {conn_name} | Connection | {conn_info.get('path', 'N/A')} |")
        
        md.append("")
        md.append("## Mapping Tasks Analysis")
        md.append("")
        
        for task_name, details in detailed_mappings.items():
            md.append(f"### {task_name}")
            md.append("")
            
            # Basic Information
            md.append("#### Basic Information")
            md.append(f"- **Task Name**: {details['task_name']}")
            md.append(f"- **Mapping Reference**: {details['mapping_name']}")
            md.append(f"- **Operation Types**: {', '.join(details['operation_types']) if details['operation_types'] else 'N/A'}")
            md.append("")
            
            # Source Details
            if details['sources']:
                md.append("#### Source Details")
                md.append("")
                for i, source in enumerate(details['sources'], 1):
                    md.append(f"**Source {i}: {source['name']}**")
                    md.append(f"- **Connection**: {source['connection_id']}")
                    md.append(f"- **Object**: {source['object_name']}")
                    md.append(f"- **Schema**: {source['schema']}")
                    md.append(f"- **Read Pattern**: {source['read_pattern']}")
                    if source['filter']:
                        md.append(f"- **Filter Condition**: `{source['filter']}`")
                    md.append("")
            
            # Target Details
            if details['targets']:
                md.append("#### Target Details")
                md.append("")
                for i, target in enumerate(details['targets'], 1):
                    md.append(f"**Target {i}: {target['name']}**")
                    md.append(f"- **Connection**: {target['connection_id']}")
                    md.append(f"- **Object**: {target['object_name']}")
                    md.append(f"- **Schema**: {target['schema']}")
                    md.append(f"- **Write Pattern**: {target['write_pattern']}")
                    md.append(f"- **Operation Type**: {target['operation_type']}")
                    if target['update_columns']:
                        md.append(f"- **Update Columns**: {', '.join(target['update_columns'])}")
                    md.append("")
            
            # Lookup Details
            if details['lookups']:
                md.append("#### Lookup Details")
                md.append("")
                for i, lookup in enumerate(details['lookups'], 1):
                    md.append(f"**Lookup {i}: {lookup['name']}**")
                    md.append(f"- **Connection**: {lookup['connection_id']}")
                    md.append(f"- **Object**: {lookup['object_name']}")
                    md.append(f"- **Schema**: {lookup['schema']}")
                    md.append(f"- **Cache Type**: {lookup['cache_type']}")
                    md.append(f"- **Cache Enabled**: {lookup['cache_enabled']}")
                    md.append("")
            
            # Session Properties
            if details['session_properties']:
                md.append("#### Session Properties")
                md.append("")
                md.append("| Property | Value |")
                md.append("|---|---|")
                for prop_name, prop_value in details['session_properties'].items():
                    md.append(f"| {prop_name} | {prop_value} |")
                md.append("")
            
            # Data Flow Summary
            md.append("#### Data Flow Summary")
            md.append("")
            if details['sources'] and details['targets']:
                md.append("```")
                md.append("Data Flow:")
                for source in details['sources']:
                    md.append(f"  📥 {source['connection_id']}.{source['object_name']}")
                    if source['filter']:
                        md.append(f"     └─ Filter: {source['filter']}")
                
                if details['lookups']:
                    md.append("     ↓")
                    md.append("  🔍 Lookups:")
                    for lookup in details['lookups']:
                        md.append(f"     ├─ {lookup['connection_id']}.{lookup['object_name']} ({lookup['cache_type']})")
                
                md.append("     ↓")
                md.append("  📤 Targets:")
                for target in details['targets']:
                    md.append(f"     ├─ {target['connection_id']}.{target['object_name']} ({target['operation_type']})")
                md.append("```")
            md.append("")
            md.append("---")
            md.append("")
        
        # Summary Statistics
        md.append("## Summary Statistics")
        md.append("")
        
        total_sources = sum(len(details['sources']) for details in detailed_mappings.values())
        total_targets = sum(len(details['targets']) for details in detailed_mappings.values())
        total_lookups = sum(len(details['lookups']) for details in detailed_mappings.values())
        
        all_operations = set()
        for details in detailed_mappings.values():
            all_operations.update(details['operation_types'])
        
        md.append(f"- **Total Mapping Tasks**: {len(detailed_mappings)}")
        md.append(f"- **Total Sources**: {total_sources}")
        md.append(f"- **Total Targets**: {total_targets}")
        md.append(f"- **Total Lookups**: {total_lookups}")
        md.append(f"- **Operation Types Used**: {', '.join(sorted(all_operations))}")
        md.append("")
        
        # Connection Usage Analysis
        connection_usage = defaultdict(int)
        for details in detailed_mappings.values():
            for source in details['sources']:
                connection_usage[source['connection_id']] += 1
            for target in details['targets']:
                connection_usage[target['connection_id']] += 1
            for lookup in details['lookups']:
                connection_usage[lookup['connection_id']] += 1
        
        md.append("## Connection Usage Analysis")
        md.append("")
        md.append("| Connection | Usage Count | Usage Type |")
        md.append("|---|---|---|")
        
        for conn_id, count in sorted(connection_usage.items(), key=lambda x: x[1], reverse=True):
            md.append(f"| {conn_id} | {count} | Mixed (Source/Target/Lookup) |")
        
        md.append("")
        md.append("---")
        md.append("*Report generated by IICS Taskflow Analyzer*")
        
        return "\n".join(md)
        
    def visualize_dependency_graph(self, output_file: str = "taskflow_dependencies.png"):
        """Create a visualization of the dependency graph"""
        if self.dependency_graph.number_of_nodes() == 0:
            print("❌ No dependency graph to visualize")
            return
            
        plt.figure(figsize=(15, 10))
        
        # Create layout
        pos = nx.spring_layout(self.dependency_graph, k=3, iterations=50)
        
        # Color nodes by type
        node_colors = []
        for node in self.dependency_graph.nodes():
            node_type = self.dependency_graph.nodes[node].get('type', 'unknown')
            if node_type == 'MTT':
                node_colors.append('#FF6B6B')  # Red for mapping tasks
            elif node_type == 'DTEMPLATE':
                node_colors.append('#4ECDC4')  # Teal for data templates
            elif node_type == 'Connection':
                node_colors.append('#45B7D1')  # Blue for connections
            else:
                node_colors.append('#96CEB4')  # Green for others
                
        # Draw the graph
        nx.draw(self.dependency_graph, pos, 
                node_color=node_colors,
                node_size=2000,
                font_size=8,
                font_weight='bold',
                arrows=True,
                edge_color='gray',
                alpha=0.7)
        
        # Add labels
        nx.draw_networkx_labels(self.dependency_graph, pos, font_size=6)
        
        plt.title("IICS Taskflow Dependency Graph", size=16, fontweight='bold')
        plt.legend(['MTT Tasks', 'Data Templates', 'Connections'], 
                  loc='upper right',
                  bbox_to_anchor=(1.15, 1))
        
        plt.tight_layout()
        plt.savefig(output_file, dpi=300, bbox_inches='tight')
        print(f"✓ Saved dependency graph to {output_file}")
        
    def run_full_analysis(self):
        """Run the complete analysis workflow"""
        print("🚀 Starting IICS Taskflow Analysis...")
        print("-" * 50)
        
        self.load_export_metadata()
        self.analyze_taskflow_xml()
        self.extract_mtt_tasks()
        self.extract_dtemplates()
        self.analyze_connections()
        self.build_dependency_graph()
        
        self.generate_summary_report()
        self.export_to_csv()
        self.generate_detailed_markdown_report()
        #self.visualize_dependency_graph()
        
        print("\n✅ Analysis completed successfully!")

def main():
    """Main function to run the analyzer"""
    # Path to extracted taskflow files
    extracted_path = "taskflows/extracted"
    
    if not os.path.exists(extracted_path):
        print(f"❌ Extracted path not found: {extracted_path}")
        print("Please run the unzip script first.")
        return
        
    analyzer = IICSTaskflowAnalyzer(extracted_path)
    analyzer.run_full_analysis()

if __name__ == "__main__":
    main()