#!/usr/bin/env python3
import sys
sys.path.append('.')
from iics_taskflow_analyzer import IICSTaskflowAnalyzer

analyzer = IICSTaskflowAnalyzer('.')

# Test the updated method
test_cases = [
    ('mt_SA_ACYR_soft_delete', '1kWbGz8UUuQgVbrmsG96uk'),
    ('mt_Vector_student', '1nSIzs2dFSJdfub7ap5o0N'),
    ('mt_WD_JOB_PROFILES', 'lAZA7RWpr4HlpA8nd1CYMg'),
    ('mt_WORKDAY_UPDATE_TIMESTAMP_START', 'ahhTvYbWjAKlVRNjWBOFUJ')
]

print('Updated mapping names (no suffix):')
print('=' * 50)

for task_name, mapping_id in test_cases:
    result = analyzer._generate_mapping_name(task_name, mapping_id)
    print(f'{task_name:<35} -> {result}')
    
print('\nClean, simple mapping names - no suffixes!')
