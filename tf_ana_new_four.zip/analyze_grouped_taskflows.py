#!/usr/bin/env python3
"""
Enhanced IICS Grouped Taskflow Analyzer
Streamlined workflow for analyzing job exports containing multiple taskflows
"""

import os
import sys
import zipfile
from pathlib import Path
from iics_job_analyzer import IICSJobAnalyzer

def extract_and_analyze_job(job_zip_path: str, output_dir: str = None):
    """
    Extract and analyze a grouped taskflow job export
    
    Args:
        job_zip_path: Path to the job export ZIP file
        output_dir: Optional output directory for reports
    """
    job_path = Path(job_zip_path)
    
    if not job_path.exists():
        print(f"Job export file not found: {job_zip_path}")
        return False
    
    # Extract the job export
    extracted_dir = job_path.parent / f"{job_path.stem}_extracted"
    
    print(f"Extracting job export: {job_path.name}")
    print(f"Extract location: {extracted_dir}")
    
    try:
        with zipfile.ZipFile(job_path, 'r') as zip_ref:
            zip_ref.extractall(extracted_dir)
        print("Job export extracted successfully")
    except Exception as e:
        print(f"Error extracting job export: {e}")
        return False
    
    # Analyze the extracted job
    try:
        print("\nStarting job analysis...")
        analyzer = IICSJobAnalyzer(str(extracted_dir))
        analyzer.run_job_analysis()
        
        # Move reports to output directory if specified
        if output_dir:
            output_path = Path(output_dir)
            output_path.mkdir(exist_ok=True)
            
            # Move generated files


            # Generated files are already job-prefixed; move them as-is
            for report_file in [f"{job_path.stem}_job_analysis_report.md",
                                f"{job_path.stem}_job_analysis.csv",
                                f"{job_path.stem}_comprehensive_mapping_reference.csv",
                                f"{job_path.stem}_taskflow_mappings.json"]:
                if Path(report_file).exists():
                    dest_file = output_path / report_file
                    # Remove destination file if it exists
                    if dest_file.exists():
                        dest_file.unlink()
                    Path(report_file).rename(dest_file)
                    print(f"Moved {report_file} to {dest_file}")
        
        return True
        
    except Exception as e:
        print(f"Error during job analysis: {e}")
        return False

def generate_executive_summary(job_zip_path: str):
    """Generate an executive summary of the job analysis"""
    job_path = Path(job_zip_path)
    extracted_dir = job_path.parent / f"{job_path.stem}_extracted"
    
    if not extracted_dir.exists():
        print("Extracted directory not found. Please run analysis first.")
        return
    
    analyzer = IICSJobAnalyzer(str(extracted_dir))
    analyzer.load_export_metadata()
    analyzer.analyze_job_structure()
    
    # Generate executive summary
    summary = []
    summary.append("# Executive Summary - IICS Job Analysis")
    summary.append(f"**Job Export**: {job_path.name}")
    summary.append(f"**Analysis Date**: {analyzer.metadata.get('name', 'Unknown')}")
    summary.append("")
    
    # Job-level statistics
    total_objects = len(analyzer.metadata.get('exportedObjects', []))
    summary.append("## High-Level Statistics")
    summary.append(f"- **Total Objects in Export**: {total_objects}")
    summary.append(f"- **Number of Taskflows**: {len(analyzer.taskflows)}")
    summary.append("")
    
    # Taskflow breakdown
    summary.append("## Taskflow Breakdown")
    summary.append("| Taskflow | Project Path | MTT Tasks | Estimated Complexity |")
    summary.append("|---|---|---|---|")
    
    for taskflow_name, taskflow_info in analyzer.taskflows.items():
        analysis = analyzer.analyze_taskflow_details(taskflow_name)
        mtt_count = analysis['summary']['total_mtt_tasks']
        
        # Determine complexity
        if mtt_count == 0:
            complexity = "Empty"
        elif mtt_count <= 5:
            complexity = "Simple"
        elif mtt_count <= 25:
            complexity = "Moderate"
        elif mtt_count <= 50:
            complexity = "Complex"
        else:
            complexity = "Very Complex"
        
        summary.append(f"| {taskflow_name} | {analysis['project_path']} | {mtt_count} | {complexity} |")
    
    summary.append("")
    
    # Shared resources analysis
    summary.append("## Shared Resources Analysis")
    all_connections = set()
    for taskflow_name in analyzer.taskflows:
        analysis = analyzer.analyze_taskflow_details(taskflow_name)
        all_connections.update(analysis['connections'])
    
    summary.append(f"- **Unique Connections Used**: {len(all_connections)}")
    summary.append(f"- **Connection Sharing**: {'High' if len(all_connections) < len(analyzer.taskflows) * 2 else 'Moderate'}")
    summary.append("")
    
    # Recommendations
    summary.append("## Recommendations")
    
    # Check for potential optimization opportunities
    large_taskflows = [name for name, info in analyzer.taskflows.items() 
                      if analyzer.analyze_taskflow_details(name)['summary']['total_mtt_tasks'] > 50]
    
    if large_taskflows:
        summary.append("### Large Taskflows Identified")
        summary.append("The following taskflows contain many MTT tasks and might benefit from modularization:")
        for tf_name in large_taskflows:
            analysis = analyzer.analyze_taskflow_details(tf_name)
            summary.append(f"- **{tf_name}**: {analysis['summary']['total_mtt_tasks']} MTT tasks")
        summary.append("")
    
    # Check for empty taskflows
    empty_taskflows = [name for name, info in analyzer.taskflows.items() 
                      if analyzer.analyze_taskflow_details(name)['summary']['total_mtt_tasks'] == 0]
    
    if empty_taskflows:
        summary.append("### Empty Taskflows")
        summary.append("The following taskflows contain no MTT tasks and may need review:")
        for tf_name in empty_taskflows:
            summary.append(f"- **{tf_name}**")
        summary.append("")
    
    summary.append("---")
    summary.append("*Generated by Enhanced IICS Grouped Taskflow Analyzer*")
    
    # Write summary
    summary_file = f"{job_path.stem}_executive_summary.md"
    with open(summary_file, 'w', encoding='utf-8') as f:
        f.write('\n'.join(summary))
    
    print(f"Executive summary generated: {summary_file}")

def main():
    """Main function"""
    if len(sys.argv) < 2:
        print("Usage: python analyze_grouped_taskflows.py <job_export.zip> [output_dir]")
        print("\nExample:")
        print("  python analyze_grouped_taskflows.py taskflows/job-1754455542236.zip")
        print("  python analyze_grouped_taskflows.py taskflows/job-1754455542236.zip ./analysis_output")
        return
    
    job_zip_path = sys.argv[1]
    output_dir = sys.argv[2] if len(sys.argv) > 2 else None
    
    print("Enhanced IICS Grouped Taskflow Analyzer")
    print("=" * 60)
    
    # Extract and analyze
    success = extract_and_analyze_job(job_zip_path, output_dir)
    
    if success:
        print("\nGenerating executive summary...")
        generate_executive_summary(job_zip_path)
        
        print("\nAnalysis completed successfully!")
        print("\nGenerated Reports:")
        print("- Detailed Analysis: job_analysis_report.md")
        print("- Summary CSV: job_analysis.csv")
        print("- Comprehensive Reference: comprehensive_mapping_reference.csv")
        print("- Executive Summary: *_executive_summary.md")
        
        if output_dir:
            print(f"- Reports moved to: {output_dir}")
    else:
        print("\nAnalysis failed. Please check the error messages above.")

if __name__ == "__main__":
    main()